"""Artificial probabilities only; no research scores in these tests."""
import importlib
import numpy as np
import pytest
import torch
from torch.utils.data import DataLoader,TensorDataset


def api():return importlib.import_module('support.federated.cpm')


def loader(labels=(0,0,1)):
    p=torch.tensor([[.9,.1],[.5,.5],[.2,.8]],dtype=torch.float64)
    return DataLoader(TensorDataset(p.log(),torch.tensor(labels)),batch_size=2,shuffle=False,
                      generator=torch.Generator().manual_seed(0))


def test_true_class_rows_and_unequal_support():
    model=torch.nn.Identity();model.train();rng=torch.get_rng_state().clone()
    matrix=api().class_probability_matrix(model,loader(),2)
    np.testing.assert_allclose(matrix,[[.7,.3],[.2,.8]],atol=1e-14)
    assert matrix.shape==(2,2) and matrix.dtype==np.float64
    assert model.training and torch.equal(rng,torch.get_rng_state())
    np.testing.assert_allclose(matrix.sum(axis=1),1)


@pytest.mark.parametrize('labels',[(0,0,0),(0,0,2),(0,0,-1)])
def test_missing_or_invalid_classes_fail(labels):
    with pytest.raises(ValueError):api().class_probability_matrix(torch.nn.Identity(),loader(labels),2)


def test_nonfinite_logits_fail_and_mixed_modes_restore():
    class Bad(torch.nn.Module):
        def __init__(self):super().__init__();self.child=torch.nn.Dropout()
        def forward(self,x):return x*float('nan')
    model=Bad();model.train();model.child.eval()
    with pytest.raises(ValueError):api().class_probability_matrix(model,loader(),2)
    assert model.training and not model.child.training
