"""Artificial result files test reporting integrity, never research conclusions."""
from pathlib import Path
import importlib,json,csv,yaml
import pytest


def records(tmp_path):
    entries=[]
    for condition in ['iid','dirichlet']:
        for seed in [42,43,44]:
            base=tmp_path/f'base_{condition}_{seed}';made=tmp_path/f'made_{condition}_{seed}'
            for directory,score,method in [(base,.5,'prepared_fedavg'),(made,1.,'prepared_fedmade_adapted')]:
                directory.mkdir();metrics={k:score for k in ['accuracy','balanced_accuracy','macro_f1','weighted_f1']};metrics['loss']=1-score
                (directory/'validation_metrics.json').write_text(json.dumps({'metrics':metrics}))
                verification={'testing_only':False,'test_scored':False,'initial_state_sha256':'same','rounds':2,'train_rows':4,'client_rows':{'c':4},'validation_rows':4,'aggregation_verified':True,'reloaded_validation_exact':True}
                (directory/'verification.json').write_text(json.dumps(verification))
                metadata={'seed':seed,'evaluation_role':'validation','workflow':method,'federated_inputs':{'bundle_sha256':f'{condition}_{seed}','contract':{'classes':2}},'paired_fedavg_run':str(base)}
                (directory/'metadata.json').write_text(json.dumps(metadata))
                with (directory/'validation_per_class.csv').open('w',newline='') as f:
                    w=csv.writer(f);w.writerow(['class_id','class_name','support','precision','recall','f1'])
                    for i in [0,1]:w.writerow([i,f'class{i}',2,score,score,score])
            entries.append({'condition':condition,'seed':seed,'run_path':str(made)})
    summary=tmp_path/'summary.json';summary.write_text(json.dumps({'runs':entries}));return summary,entries


def test_paired_means_and_every_class_retained(tmp_path):
    summary,entries=records(tmp_path)
    r=importlib.import_module('support.compare_fedmade').compare(summary,tmp_path/'out')
    assert len(r['pairs'])==6 and r['conditions']['iid']['macro_f1']['mean_delta']==.5
    with (tmp_path/'out/per_class_comparison.csv').open() as f:assert len(list(csv.DictReader(f)))==4
    with pytest.raises(FileExistsError):importlib.import_module('support.compare_fedmade').compare(summary,tmp_path/'out')


@pytest.mark.parametrize('damage',['seed','initialization','support','testing_only'])
def test_unmatched_or_testing_inputs_rejected(tmp_path,damage):
    summary,entries=records(tmp_path);p=Path(entries[0]['run_path'])
    if damage=='seed':
        f=p/'metadata.json';v=json.loads(f.read_text());v['seed']=99
    elif damage=='support':
        f=p/'verification.json';v=json.loads(f.read_text());v['validation_rows']=5
    else:
        f=p/'verification.json';v=json.loads(f.read_text());v['initial_state_sha256']='different' if damage=='initialization' else 'same'
        if damage=='testing_only':v['testing_only']=True
    f.write_text(json.dumps(v))
    with pytest.raises(ValueError):importlib.import_module('support.compare_fedmade').compare(summary,tmp_path/'out')
