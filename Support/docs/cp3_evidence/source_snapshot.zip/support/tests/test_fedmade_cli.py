"""Entry-point routing without launching research training."""
from pathlib import Path
import sys
import pytest
import main


def test_explicit_fedmade_route(monkeypatch,capsys,tmp_path):
    calls=[]
    monkeypatch.setattr(main,'run_fedmade',lambda p:calls.append(p) or tmp_path)
    monkeypatch.setattr(sys,'argv',['main.py','--fedmade','--config','example.yaml'])
    main.main();assert calls==[Path('example.yaml')]
    assert 'adapted FedMADE' in capsys.readouterr().out


@pytest.mark.parametrize('args',[['--fedmade'],['--fedmade','--federated']])
def test_no_missing_config_or_ambiguous_workflow(monkeypatch,args):
    monkeypatch.setattr(sys,'argv',['main.py',*args])
    with pytest.raises(SystemExit) as error:main.main()
    assert error.value.code==2
