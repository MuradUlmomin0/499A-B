"""Strict method settings; no training or real-data access."""
import copy,importlib
from pathlib import Path
import pytest,yaml


def value():
    v=yaml.safe_load(Path('support/configs/cp2_v1/iid_seed42.yaml').read_text())
    v['federated']['aggregation']='fedmade'
    v['fedmade']={'auxiliary_manifest_path':'aux.manifest.json','auxiliary_evidence_path':'aux.ids.json',
        'reference_run_path':None,'eps':.5,'min_samples':1,'solver':'nnls','norm':'frobenius','maxiter':10000}
    return v


def test_explicit_method_and_literal_paths(tmp_path):
    api=importlib.import_module('support.utils.fedmade_config');v=value();p=tmp_path/'run.yaml';p.write_text(yaml.safe_dump(v))
    c=api.load_fedmade_config(p)
    assert c['federated']['aggregation']=='fedmade'
    assert c['fedmade']['auxiliary_manifest_path']==str(tmp_path/'aux.manifest.json')
    from support.utils.training_config import validate_training_config
    with pytest.raises(ValueError):validate_training_config(v)


@pytest.mark.parametrize('key,bad',[('eps',0),('eps',float('nan')),('min_samples',5),('solver','adam'),('norm','spectral'),('maxiter',0)])
def test_unapproved_or_invalid_method_settings_fail(key,bad):
    v=value();v['fedmade'][key]=bad
    with pytest.raises(ValueError):importlib.import_module('support.utils.fedmade_config').validate_fedmade_config(v)


def test_cuda_not_silently_verified_as_cpu():
    v=value();v['experiment']['device']='cuda'
    with pytest.raises(ValueError,match='CPU'):importlib.import_module('support.utils.fedmade_config').validate_fedmade_config(v)
