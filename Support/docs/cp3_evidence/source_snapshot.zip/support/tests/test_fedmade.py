"""Analytic mathematical examples, not research results."""
import importlib
from collections import OrderedDict
import numpy as np
import pytest
import torch
from support.federated.types import ClientResult


def api():return importlib.import_module('support.federated.fedmade')


def test_analytic_cluster_weights_and_no_premature_simplex():
    p=np.array([[[1.,0.],[1.,0.]],[[0.,1.],[0.,1.]]])
    alpha,residual,kkt=api().solve_cluster_weights(p)
    np.testing.assert_allclose(alpha,[.5,.5],atol=1e-12);assert residual==pytest.approx(1.)
    assert kkt<1e-8
    # Identical-class probabilities with imperfect diagonal can require alpha sum !=1.
    q=np.array([[[.9,.1],[.4,.6]]])
    a,_,_=api().solve_cluster_weights(q)
    expected=np.trace(q[0])/np.square(q[0]).sum()
    assert a[0]==pytest.approx(expected) and a[0]!=pytest.approx(1.)


def test_perfect_cluster_receives_mass_and_shared_members_equal():
    cpms=np.array([np.eye(2),np.eye(2),np.full((2,2),.5)])
    labels,clusters=api().cluster_cpms(cpms,.5)
    assert labels.tolist()==[0,0,1]
    np.testing.assert_allclose(clusters,[np.eye(2),np.full((2,2),.5)])
    alpha,_,_=api().solve_cluster_weights(clusters)
    np.testing.assert_allclose(alpha,[1.,0.],atol=1e-12)
    np.testing.assert_allclose(api().client_weights(labels,alpha),[.5,.5,0.],atol=1e-12)


def test_single_cluster_equal_weights_not_training_size():
    labels,p=api().cluster_cpms(np.array([np.eye(2),np.eye(2)]),.5)
    a,_,_=api().solve_cluster_weights(p)
    np.testing.assert_allclose(api().client_weights(labels,a),[.5,.5])


@pytest.mark.parametrize('bad',[np.ones((2,2)),np.array([[[1.,1.],[0.,0.]]]),np.full((1,2,2),np.nan)])
def test_invalid_cpms_rejected(bad):
    with pytest.raises(ValueError):api().cluster_cpms(bad,.5)


def test_zero_objective_coefficients_fail_instead_of_fallback():
    a,_,_=api().solve_cluster_weights(np.array([[[0.,1.],[1.,0.]]]))
    with pytest.raises(ValueError,match='zero'):api().client_weights(np.array([0]),a)


def result(name,n,value):
    s=OrderedDict(w=torch.tensor([value],dtype=torch.float32))
    return ClientResult(name,1,n,s,s,{'train_loss':0.})


def test_aggregator_weighted_equation_and_no_input_alias(monkeypatch):
    module=api();matrices=iter([np.eye(2),np.eye(2)])
    monkeypatch.setattr(module,'class_probability_matrix',lambda *a,**k:next(matrices))
    # A minimal inference model has the same state key/shape as the contributions.
    class Model(torch.nn.Module):
        def __init__(self):super().__init__();self.w=torch.nn.Parameter(torch.zeros(1))
    data=torch.utils.data.TensorDataset(torch.ones(2,1),torch.tensor([0,1]))
    agg=module.FedMADEAggregator(Model,data,2,eps=.5)
    a,b=result('a',100,4),result('b',300,10)
    state,weights=agg.aggregate([a,b])
    assert state['w'].item()==7 and weights=={'a':.5,'b':.5}
    state['w'].zero_();assert a.state['w'].item()==4
    assert agg.last_diagnostics['cluster_count']==1


def test_invalid_clients_fail_before_auxiliary_inference():
    data=torch.utils.data.TensorDataset(torch.ones(2,1),torch.tensor([0,1]))
    agg=api().FedMADEAggregator(lambda:torch.nn.Linear(1,2),data,2)
    for items in [[],[result('a',0,1)],[result('a',1,1),result('a',2,3)]]:
        with pytest.raises(ValueError):agg.aggregate(items)


def test_nnls_iteration_failure_propagates(monkeypatch):
    def fail(*args,**kwargs):raise RuntimeError('Maximum iterations reached')
    monkeypatch.setattr(api(),'nnls',fail)
    with pytest.raises(RuntimeError,match='iterations'):api().solve_cluster_weights(np.eye(2)[None])


def test_zero_mass_and_nonfinite_weights_rejected():
    for a in [np.array([0.]),np.array([float('nan')]),np.array([-1.])]:
        with pytest.raises(ValueError):api().client_weights(np.array([0]),a)


def test_aggregator_constructor_preserves_global_rng():
    torch.manual_seed(123);before=torch.get_rng_state().clone()
    data=torch.utils.data.TensorDataset(torch.ones(2,1),torch.tensor([0,1]))
    api().FedMADEAggregator(lambda:torch.nn.Linear(1,2),data,2)
    assert torch.equal(before,torch.get_rng_state())
