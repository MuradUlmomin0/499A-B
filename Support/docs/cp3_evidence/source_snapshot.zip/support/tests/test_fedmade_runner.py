"""Tiny artificial-data integration; these metrics are testing-only."""
import importlib,json
from pathlib import Path
import pytest,yaml
from support.tests.test_research_export import fixture
from support.data.research_export import export_research


def inputs(tmp_path):
    raw,c,s=fixture(tmp_path);root=tmp_path/'prepared';export_research(raw,c,s,root)
    cfg={'schema_version':1,'experiment':{'name':'test_fedmade','seed':42,'device':'cpu','deterministic':True,'output_dir':str(tmp_path/'results')},
      'dataset':{'bundle_path':str(root/'iid_seed42/federated_bundle.json')},'initialization':{'mode':'random','artifact_path':None},
      'federated':{'aggregation':'fedmade','rounds':2,'participation_rate':1.},'training':{'optimizer':'adam','learning_rate':.001,'local_epochs':1,'batch_size':2},
      'selection':{'policy':'final_round'},'fedmade':{'auxiliary_manifest_path':str(root/'auxiliary.manifest.json'),'auxiliary_evidence_path':str(root/'auxiliary.ids.json'),
      'reference_run_path':None,'eps':.5,'min_samples':1,'solver':'nnls','norm':'frobenius','maxiter':10000}}
    path=tmp_path/'run.yaml';path.write_text(yaml.safe_dump(cfg));return path,root


def test_tiny_training_diagnostics_and_exact_reload(tmp_path):
    config,root=inputs(tmp_path);api=importlib.import_module('support.fedmade_runner')
    path=api.run_verified(config)
    v=json.loads((path/'verification.json').read_text())
    assert v['testing_only'] and not v['test_scored'] and v['reloaded_validation_exact']
    assert v['rounds']==2 and v['cpm_and_equations_verified']
    assert len(list((path/'fedmade_diagnostics').glob('*.npz')))==2
    assert (path/'model_artifact.pt').exists()


def test_wrong_auxiliary_role_and_contract_rejected_before_training(tmp_path):
    config,root=inputs(tmp_path);v=yaml.safe_load(config.read_text());v['fedmade']['auxiliary_manifest_path']=str(root/'validation.manifest.json');config.write_text(yaml.safe_dump(v))
    with pytest.raises(ValueError):importlib.import_module('support.fedmade_runner').run_fedmade(config)
    assert not (tmp_path/'results').exists()


def test_auxiliary_train_record_overlap_rejected(tmp_path):
    config,root=inputs(tmp_path);p=root/'auxiliary.ids.json';ev=json.loads(p.read_text());ev['record_ids'][0]='Dataset/train.csv:row:0';p.write_text(json.dumps(ev))
    # Even when a producer updates its own report, cross-role checks must catch it.
    from support.data.latest_audit import source_hash
    report=json.loads((root/'preparation_report.json').read_text());report['files']['auxiliary.ids.json']=source_hash(p);(root/'preparation_report.json').write_text(json.dumps(report))
    with pytest.raises(ValueError,match='overlap'):importlib.import_module('support.fedmade_runner').run_fedmade(config)
    assert not (tmp_path/'results').exists()


def test_incomplete_export_and_no_preflight_fail_closed(tmp_path):
    config,root=inputs(tmp_path);(root/'preparation_report.json').unlink()
    api=importlib.import_module('support.fedmade_runner')
    with pytest.raises(ValueError,match='completed preparation'):api.run_fedmade(config)
    with pytest.raises(ValueError,match='preflight'):api.run_matrix(tmp_path/'missing_configs',tmp_path/'matrix')
    assert not (tmp_path/'results').exists()


@pytest.mark.parametrize('damage',['training','seed','initialization','rounds','bundle'])
def test_paired_baseline_rejects_changed_controls(tmp_path,damage):
    config,root=inputs(tmp_path)
    from support.utils.fedmade_config import load_fedmade_config
    api=importlib.import_module('support.fedmade_runner');cfg=load_fedmade_config(config)
    bundle,*_=api.load_inputs(cfg);baseline={k:v for k,v in cfg.items() if k!='fedmade'}
    baseline['federated']={**baseline['federated'],'aggregation':'fedavg'}
    reference=tmp_path/'baseline';reference.mkdir();(reference/'config.yaml').write_text(yaml.safe_dump(baseline))
    (reference/'metadata.json').write_text(json.dumps({'workflow':'prepared_fedavg','federated_inputs':{'bundle_sha256':bundle.sha256}}))
    (reference/'verification.json').write_text(json.dumps({'test_scored':False,'rounds':2}))
    cfg['fedmade']['reference_run_path']=str(reference)
    if damage=='training':cfg['training']={**cfg['training'],'learning_rate':.02}
    if damage=='seed':cfg['experiment']={**cfg['experiment'],'seed':43}
    if damage=='initialization':cfg['initialization']={'mode':'artifact','artifact_path':'unused.pt'}
    if damage=='rounds':cfg['federated']={**cfg['federated'],'rounds':3}
    if damage=='bundle':
        from dataclasses import replace
        bundle=replace(bundle,path=Path('other.json'))
    with pytest.raises(ValueError,match='Unmatched'):api.paired_reference(cfg,bundle,False)


@pytest.mark.parametrize('damage',['cpm','alpha','json_weight','logged_weight','local_state','aggregated_state'])
def test_tampered_round_evidence_is_rejected(tmp_path,damage):
    import numpy as np,torch,csv
    config,root=inputs(tmp_path);api=importlib.import_module('support.fedmade_runner');path=api.run_fedmade(config)
    prefix=path/'fedmade_diagnostics/round_001'
    if damage in ['cpm','alpha']:
        file=prefix.with_suffix('.npz')
        with np.load(file) as a:values={k:a[k] for k in a.files}
        if damage=='cpm':values['cpms'][0,0]=[.5,.5]
        else:values['alpha'][0]+=.1
        np.savez(file,**values)
    elif damage=='json_weight':
        file=prefix.with_suffix('.json');v=json.loads(file.read_text());v['client_weights']['client_000']=.1;file.write_text(json.dumps(v))
    elif damage=='logged_weight':
        file=path/'aggregation_weights.csv'
        with file.open() as f:rows=list(csv.DictReader(f))
        rows[0]['weight']='0.1'
        with file.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    else:
        file=prefix.with_suffix('.pt');v=torch.load(file,weights_only=True)
        state=v['client_states']['client_000'] if damage=='local_state' else v['aggregated_state']
        state[next(iter(state))].add_(.1);torch.save(v,file)
    with pytest.raises(ValueError):importlib.import_module('support.fedmade_verification').verify_run(path)


def test_two_tiny_runs_reproduce_weights_and_cpms(tmp_path):
    import numpy as np
    config,_=inputs(tmp_path);api=importlib.import_module('support.fedmade_runner')
    a=api.run_verified(config);b=api.run_verified(config)
    assert json.loads((a/'verification.json').read_text())['final_state_sha256']==json.loads((b/'verification.json').read_text())['final_state_sha256']
    with np.load(a/'fedmade_diagnostics/round_002.npz') as aa,np.load(b/'fedmade_diagnostics/round_002.npz') as bb:
        for k in aa.files:assert np.array_equal(aa[k],bb[k])


def test_history_update_matches_preceding_global_state(tmp_path):
    import torch
    config,_=inputs(tmp_path);api=importlib.import_module('support.fedmade_runner');path=api.run_fedmade(config)
    file=path/'checkpoint.pt';v=torch.load(file,weights_only=True);update=v['history']['client_000'][1]
    update[next(iter(update))].add_(.1);torch.save(v,file)
    with pytest.raises(ValueError,match='update'):importlib.import_module('support.fedmade_verification').verify_run(path)
