"""Artificial test inputs only: no poisoning research conclusions."""
from pathlib import Path
import random
import numpy as np
import pytest
import torch
from torch.utils.data import TensorDataset
from support.attacks.label_poison import LabelPoisonView,PoisonedClient,select_malicious
from support.federated.client import FederatedClient
from support.models.factory import create_model
from support.federated_runner import _state_sha256


def attack(**extra):return dict(enabled=True,target_class=1,destination_class=0,malicious_clients=2,start_round=4,end_round=20,selection_seed_offset=5005,**extra)


def test_selection_is_fixed_private_and_order_independent():
    ids=[f'client_{i:03}' for i in range(10)];state=random.getstate()
    assert select_malicious(ids,42,2)==['client_008','client_003']
    assert select_malicious(ids[::-1],42,2)==select_malicious(ids,42,2)
    assert select_malicious(ids,42,0)==[] and random.getstate()==state


@pytest.mark.parametrize('ids,count',[([],1),(['a','a'],1),(['a'],2),(['a'],-1),(['a'],True)])
def test_bad_selection_rejected(ids,count):
    with pytest.raises(ValueError):select_malicious(ids,42,count)


def test_lazy_labels_features_and_source_immutable():
    x=torch.arange(12,dtype=torch.float32).reshape(4,3);y=torch.tensor([0,1,2,1]);base=TensorDataset(x,y)
    before=y.clone();view=LabelPoisonView(base,1,0,3)
    observed=[view[i] for i in range(4)]
    assert [int(v[1]) for v in observed]==[0,0,2,0]
    assert torch.equal(y,before)
    assert all(v[0].data_ptr()==x[i].data_ptr() for i,v in enumerate(observed))
    np.testing.assert_array_equal(view.observed_labels,[0,0,2,0]);np.testing.assert_array_equal(view.access_counts,[1]*4)


@pytest.mark.parametrize('target,destination',[(1,1),(-1,0),(3,0)])
def test_invalid_label_mapping_rejected(target,destination):
    with pytest.raises(ValueError):LabelPoisonView(TensorDataset(torch.ones(2,1),torch.tensor([0,1])),target,destination,3)


def setup_client():
    torch.manual_seed(42);factory=lambda:create_model(dict(type='mlp',input_dim=2,num_classes=2,hidden_dims=[3]))
    data=TensorDataset(torch.tensor([[1.,0.],[0.,1.],[1.,1.],[0.,0.]]),torch.tensor([0,1,1,0]))
    return FederatedClient('a',factory,data,dict(optimizer='adam',learning_rate=.01,local_epochs=1,batch_size=2)),factory


def test_zero_attack_is_exact_no_extra_payload(tmp_path):
    a,factory=setup_client();b,_=setup_client();global_state=factory().state_dict()
    spec=attack();spec.update(enabled=False,malicious_clients=0)
    wrapper=PoisonedClient(b,spec,False,2,tmp_path)
    a.receive_global(global_state);wrapper.receive_global(global_state)
    left,right=a.train(4),wrapper.train(4)
    assert _state_sha256(left.state)==_state_sha256(right.state) and left.metrics==right.metrics
    assert set(right.metrics)=={'train_loss'} and not list(tmp_path.glob('*.npz'))


def test_active_round_schedule_and_saved_actual_labels(tmp_path):
    client,factory=setup_client();source=client.train_dataset;before=source.tensors[1].clone()
    wrapper=PoisonedClient(client,attack(),True,2,tmp_path)
    for rnd in [3,4,20,21]:
        wrapper.receive_global(factory().state_dict());wrapper.train(rnd)
        event=wrapper.events[-1];active=rnd in [4,20]
        assert event['active_attack']==active and event['flipped_unique_rows']==(2 if active else 0)
        assert client.train_dataset is source and torch.equal(before,source.tensors[1])
        if active:
            with np.load(tmp_path/event['audit_file'],allow_pickle=False) as a:
                np.testing.assert_array_equal(a['observed_labels'],[0,0,0,0]);np.testing.assert_array_equal(a['access_counts'],[1]*4)
