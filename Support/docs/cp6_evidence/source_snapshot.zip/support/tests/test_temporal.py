"""Analytical temporal-trust tests; artificial values are not research results."""
from collections import OrderedDict
import numpy as np
import pytest
import torch
from support.federated.types import ClientResult
from support.federated.temporal import (TemporalTrustAggregator, thresholds, decisions,
    blend_mixture, mahalanobis, DEFAULTS)


def result(client, value, rnd=1, count=1):
    state=OrderedDict(w=torch.tensor([value],dtype=torch.float32))
    return ClientResult(client,rnd,count,state,OrderedDict(w=state['w'].clone()),{})


def test_thresholds_and_decision_boundaries():
    assert thresholds(np.array([[1.,2.,3.],[1.,2.,3.]]))==pytest.approx([1.,2.,3.])
    trust,status,ratios=decisions(np.array([[1.,2.,3.],[1.5,2.,3.],[2.,2.,3.],[2.01,2.,3.]]),np.array([1.,2.,3.]))
    assert trust.tolist()==[1.,.5,.5,0.]
    assert status.tolist()==['accept','downweight','downweight','reject']
    assert ratios.tolist()==pytest.approx([1.,1.5,2.,2.01])
    assert thresholds(np.zeros((20,3))).tolist()==[1e-8]*3


def test_component_alignment_and_diagonal_distance():
    old={'means':np.array([[0.,0.],[10.,10.]]),'variances':np.array([[1.,1.],[4.,4.]]),'weights':np.array([.7,.3])}
    new={'means':np.array([[12.,10.],[2.,0.]]),'variances':np.array([[9.,9.],[2.,2.]]),'weights':np.array([.4,.6])}
    mix=blend_mixture(old,new,.8)
    np.testing.assert_allclose(mix['means'],[[.4,0.],[10.4,10.]])
    np.testing.assert_allclose(mix['variances'],[[1.2,1.2],[5.,5.]])
    np.testing.assert_allclose(mix['weights'],[.68,.32])
    md,labels=mahalanobis(np.array([[0.,0.],[12.,10.]]),old)
    np.testing.assert_allclose(md,[0.,1.]);assert labels.tolist()==[0,1]


def test_warmup_sample_weighted_and_rng_unchanged(tmp_path):
    state=np.random.get_state();torch_state=torch.get_rng_state().clone()
    tmp_path=tmp_path/'diagnostics'
    a=TemporalTrustAggregator(diagnostic_dir=tmp_path)
    combined,weights=a.aggregate([result('A',1,count=100),result('B',3,count=300)])
    assert combined['w'].item()==2.5 and weights=={'A':.25,'B':.75}
    assert a.last['phase']=='warmup' and a.last['round_id']==1
    assert np.array_equal(np.random.get_state()[1],state[1]);assert torch.equal(torch.get_rng_state(),torch_state)
    assert (tmp_path/'projection.npy').exists() and (tmp_path/'round_001.json').exists()


def test_degenerate_and_gaps_do_not_invent_trajectory():
    a=TemporalTrustAggregator()
    for rnd in range(1,5):
        a.aggregate([result('A',0,rnd),result('B',0,rnd)])
        assert a.last['phase']=='warmup' and all(r['md'] is None for r in a.last['clients'])
    a.aggregate([result('A',1,5),result('B',2,5)])
    assert all(r['trajectory'] is None for r in a.last['clients'])
    a.aggregate([result('A',1,7),result('B',2,7)])
    assert all(r['trajectory'] is None for r in a.last['clients'])


@pytest.mark.parametrize('damage',['empty','duplicate','mixed','count','nan','schema','old_round'])
def test_invalid_observations_rejected(damage):
    a=TemporalTrustAggregator();rows=[result('A',1),result('B',2)]
    if damage=='empty':rows=[]
    elif damage=='duplicate':rows[1].client_id='A'
    elif damage=='mixed':rows[1].round_id=2
    elif damage=='count':rows[0].sample_count=0
    elif damage=='nan':rows[0].update['w'][0]=float('nan')
    elif damage=='schema':rows[0].update=OrderedDict(x=torch.ones(2))
    else:a.aggregate(rows)
    with pytest.raises(ValueError):a.aggregate(rows)


def test_history_bounds_and_repeat():
    a,b=TemporalTrustAggregator(),TemporalTrustAggregator()
    for rnd in range(1,9):
        rows=[result(str(i),float(i+1)+rnd*.01,rnd) for i in range(10)]
        aa,aw=a.aggregate(rows);bb,bw=b.aggregate(rows)
        assert aw==bw and torch.equal(aa['w'],bb['w'])
        assert a.last==b.last
    assert len(a.observations)<=5 and len(a.calibration)<=5
    assert a.last['phase']=='scored'
    assert all(np.isfinite(r['md']) for r in a.last['clients'])


def test_scored_aggregation_uses_sample_count_times_trust(monkeypatch):
    import support.federated.temporal as module
    a=TemporalTrustAggregator()
    for rnd in range(1,4):a.aggregate([result(str(i),.5+i*.001,rnd,100) for i in range(10)])
    monkeypatch.setattr(module,'thresholds',lambda x:np.ones(x.shape[1]))
    monkeypatch.setattr(module,'mahalanobis',lambda x,m:(np.zeros(len(x)),np.zeros(len(x),dtype=int)))
    a.previous_md={}  # Isolate the norm decision; no consecutive MD is available.
    rows=[result(str(i),[.5,1.5,2.5][i] if i<3 else .5,4,300 if i==1 else 100) for i in range(10)]
    state,weights=a.aggregate(rows)
    assert weights['0']==pytest.approx(100/950) and weights['1']==pytest.approx(150/950) and weights['2']==0
    assert state['w'].item()==pytest.approx((.5*800+1.5*150)/950)
    assert [r['decision'] for r in a.last['clients'][:3]]==['accept','downweight','reject']


def test_all_rejected_stops_and_preserves_failure_evidence(tmp_path,monkeypatch):
    import support.federated.temporal as module
    a=TemporalTrustAggregator(diagnostic_dir=tmp_path/'scores')
    for rnd in range(1,4):a.aggregate([result(str(i),.5+i*.001,rnd) for i in range(10)])
    monkeypatch.setattr(module,'thresholds',lambda x:np.ones(x.shape[1]))
    monkeypatch.setattr(module,'mahalanobis',lambda x,m:(np.zeros(len(x)),np.zeros(len(x),dtype=int)))
    with pytest.raises(ValueError,match='Every client rejected'):a.aggregate([result(str(i),3+i*.001,4) for i in range(10)])
    assert (tmp_path/'scores/failure_004.json').exists() and a.last_round==3


def test_failed_em_stops_without_fallback(monkeypatch):
    import support.federated.temporal as module
    class Unconverged:
        converged_=False
        def __init__(self,**kw):pass
        def fit(self,pool):return self
    monkeypatch.setattr(module,'GaussianMixture',Unconverged)
    with pytest.raises(ValueError,match='converge'):TemporalTrustAggregator().aggregate([result('a',1),result('b',2)])


def test_partial_participation_and_calibration_delay():
    a=TemporalTrustAggregator()
    for rnd in range(1,7):
        a.aggregate([result(str(rnd%2),1+rnd*.01,rnd)])
        assert a.last['phase']=='warmup' and a.last['clients'][0]['trajectory'] is None
    assert a.last['reason']=='insufficient_prior_calibration'


def test_independent_audit_matches_scored_rounds_and_prior_only_limits():
    from support.temporal_verification import audit_scores,_equal_numbers
    a=TemporalTrustAggregator();observations=[];history=[];mix=None;prior_md={}
    for rnd in range(1,9):
        rows=[result(str(i),float(i+1)+rnd*.01,rnd) for i in range(10)]
        a.aggregate(rows)
        calc,mix,z,prior_md=audit_scores(rows,rnd,a.projection,mix,observations,history,prior_md)
        assert _equal_numbers(calc,a.last)
        if rnd==4:
            prior=[r['norm'] for _,rr in history for r in rr]
            assert calc['thresholds']['norm']==pytest.approx(np.mean(prior)+3*np.std(prior))
            assert calc['phase']=='scored'
        observations.append((rnd,z));history.append((rnd,calc['clients']))
