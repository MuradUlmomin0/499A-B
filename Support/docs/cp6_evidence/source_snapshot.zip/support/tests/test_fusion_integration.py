import importlib,json
import pytest,torch,yaml
from support.tests.test_poisoning_config import config_file as poison_config
from support.federated.temporal import DEFAULTS


def config_file(tmp_path,lam=.5,enabled=True):
    p=poison_config(tmp_path,'fedmade',enabled);v=yaml.safe_load(p.read_text())
    base=yaml.safe_load(open(v['baseline_config_path']).read());base.pop('fedmade');base['federated']['aggregation']='temporal';base['temporal']={**DEFAULTS,'reference_run_path':None}
    temporal=tmp_path/'temporal.yaml';temporal.write_text(yaml.safe_dump(base))
    v.update(method='fusion',temporal_config_path=str(temporal),lambda_value=lam,endpoint_reference_run_path=None)
    p.write_text(yaml.safe_dump(v));return p


@pytest.mark.parametrize('lam',[0,.5,1])
def test_fusion_runs_both_and_verifies_repeat(tmp_path,lam):
    p=config_file(tmp_path,lam);api=importlib.import_module('support.fusion_runner')
    a=api.run_verified(p);b=api.run_verified(p)
    av=json.loads((a/'verification.json').read_text());bv=json.loads((b/'verification.json').read_text())
    assert av['both_components_verified'] and av['delivered_labels_verified'] and not av['test_scored']
    assert av['final_state_sha256']==bv['final_state_sha256']
    assert len(list((a/'fusion_diagnostics').glob('*.json')))==2
    assert len(list((a/'temporal_diagnostics').glob('*.json')))==2
    assert len(list((a/'fedmade_diagnostics').glob('*.json')))==2


@pytest.mark.parametrize('field,value',[('lambda_value',True),('lambda_value',float('nan')),('lambda_value',-.1),('extra',1)])
def test_strict_fusion_config(tmp_path,field,value):
    p=config_file(tmp_path);v=yaml.safe_load(p.read_text());v[field]=value;p.write_text(yaml.safe_dump(v))
    with pytest.raises(ValueError):importlib.import_module('support.utils.fusion_config').load_fusion_config(p)


def test_mismatched_component_training_rejected(tmp_path):
    p=config_file(tmp_path);v=yaml.safe_load(p.read_text());t=v['temporal_config_path'];base=yaml.safe_load(open(t).read());base['training']['learning_rate']=.002;open(t,'w').write(yaml.safe_dump(base))
    with pytest.raises(ValueError):importlib.import_module('support.utils.fusion_config').load_fusion_config(p)


@pytest.mark.parametrize('damage',['fusion','class','temporal','labels','history'])
def test_fusion_corruption_rejected(tmp_path,damage):
    p=importlib.import_module('support.fusion_runner').run_fusion(config_file(tmp_path))
    if damage in ['fusion','class','temporal']:
        directory={'fusion':'fusion_diagnostics','class':'fedmade_diagnostics','temporal':'temporal_diagnostics'}[damage]
        f=next((p/directory).glob('*.json'));v=json.loads(f.read_text());v['round_id']=999;f.write_text(json.dumps(v))
    elif damage=='history':
        f=p/'checkpoint.pt';v=torch.load(f,weights_only=True);state=v['history']['client_000'][1];state[next(iter(state))].add_(1);torch.save(v,f)
    else:
        import numpy as np
        f=next((p/'label_audits').glob('*.npz'))
        with np.load(f) as a:v={k:a[k] for k in a.files}
        v['observed_labels'][0]=99;np.savez(f,**v)
    with pytest.raises(ValueError):importlib.import_module('support.fusion_verification').verify_run(p)


def test_actual_components_preserve_rng_streams(tmp_path):
    import random,numpy as np
    from support.fusion_runner import load_inputs,make_aggregator
    from support.utils.fusion_config import load_fusion_config
    from support.models.factory import create_model
    from support.federated.types import ClientResult
    from support.utils.parameters import clone_state
    c=load_fusion_config(config_file(tmp_path));bundle,aux=load_inputs(c);factory=lambda:create_model(bundle.contract.model_config())
    model=factory();state=clone_state(model.state_dict());results=[ClientResult(p.client_id,1,len(p.data.dataset),state,{k:torch.zeros_like(v) for k,v in state.items()},{}) for p in bundle.clients]
    py=random.getstate();npstate=np.random.get_state();ts=torch.get_rng_state().clone()
    aggregator=make_aggregator(c,bundle,aux,factory,tmp_path)
    aggregator.aggregate(results)
    assert random.getstate()==py and np.array_equal(np.random.get_state()[1],npstate[1]) and torch.equal(torch.get_rng_state(),ts)


def test_matrix_plan_has_four_controls_twelve_primary_one_repeat():
    from support.fusion_experiments import case_order
    cases=case_order()
    assert len(cases)==17 and sum(c['control'] for c in cases)==4
    assert all(c['control'] for c in cases[:4]) and sum(c['repeat'] for c in cases)==1
    primary=[c for c in cases if not c['control'] and not c['repeat']]
    assert len(primary)==12 and all(c['lambda_value']==.5 for c in primary)


@pytest.mark.parametrize('damage',['artifact','config','metadata'])
def test_cached_run_binds_all_artifacts_and_case(tmp_path,damage,monkeypatch):
    from support.fusion_experiments import artifact_hashes,check_cached
    # Matrix rejects testing-only research entries separately; exercise cache integrity here.
    monkeypatch.setattr('support.fusion_experiments._checked',lambda path,control:None)
    from support.data.latest_audit import source_hash
    config=config_file(tmp_path);api=importlib.import_module('support.fusion_runner');p=api.run_verified(config)
    case=dict(name='tiny',control=False,repeat=False,lambda_value=.5,seed=42,condition='tiny',attacked=True)
    manifest=tmp_path/'artifacts.json';manifest.write_text(json.dumps(artifact_hashes(p)))
    entry={**case,'run_path':str(p),'config_sha256':source_hash(config),'verification_sha256':source_hash(p/'verification.json'),'artifact_manifest_sha256':source_hash(manifest)}
    check_cached(entry,case,config,manifest)
    if damage=='artifact':(p/'validation_metrics.json').write_text('{}')
    elif damage=='config':
        v=yaml.safe_load((p/'config.yaml').read_text());v['lambda_value']=0;(p/'config.yaml').write_text(yaml.safe_dump(v))
    else:entry['seed']=99
    with pytest.raises(ValueError):check_cached(entry,case,config,manifest)


def test_incomplete_freeze_inventory_rejected(tmp_path,monkeypatch):
    from support import fusion_experiments as api
    directory=tmp_path/'configs';directory.mkdir();evidence=tmp_path/'support/docs/cp6_evidence';evidence.mkdir(parents=True)
    (evidence/'frozen_manifest.json').write_text(json.dumps(dict(protocol_version='cp6_equal_blend_v1',config_directory=str(directory),user_approved=True,test_scored=False,code_sha256={})))
    monkeypatch.setattr(api,'REPOSITORY',tmp_path)
    monkeypatch.setattr(api,'required_inventory',lambda d:dict(code_sha256={str(tmp_path/'required.py')}))
    with pytest.raises(ValueError,match='inventory'):api.guard(directory)


def test_cached_repeat_relation_rechecked(tmp_path):
    from support.fusion_experiments import check_repeat
    paths=[tmp_path/'original',tmp_path/'repeat']
    for i,p in enumerate(paths):
        p.mkdir();(p/'verification.json').write_text(json.dumps(dict(final_state_sha256=str(i))));(p/'validation_metrics.json').write_text('{}')
    with pytest.raises(ValueError,match='repeat'):
        check_repeat([dict(name='fused_poisoned_dirichlet_seed42',repeat=False,run_path=str(paths[0])),dict(name='repeat',repeat=True,run_path=str(paths[1]))])


@pytest.mark.parametrize('damage',['lambda','attack','clean_reference','endpoint_reference'])
def test_case_scientific_identity_bound(damage):
    from pathlib import Path
    from support.fusion_experiments import case_order,validate_case,REPOSITORY
    from support.utils.fusion_config import load_fusion_config
    case=case_order()[0];cfg=load_fusion_config(REPOSITORY/'support/configs/cp6_v1'/(case['name']+'.yaml'))
    validate_case(cfg,case)
    if damage=='lambda':cfg['lambda_value']=1
    elif damage=='attack':cfg['attack']['target_class']=17
    elif damage=='clean_reference':cfg['reference_clean_run_path']='/tmp/other'
    else:cfg['endpoint_reference_run_path']='/tmp/other'
    with pytest.raises(ValueError):validate_case(cfg,case)
