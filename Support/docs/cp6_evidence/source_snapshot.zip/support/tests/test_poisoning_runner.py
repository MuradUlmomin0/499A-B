import importlib,json
import numpy as np
import pytest,torch,yaml
from support.tests.test_poisoning_config import config_file


@pytest.mark.parametrize('method',['fedavg','fedmade','temporal'])
def test_all_methods_tiny_attacks_and_repeat(tmp_path,method):
    config=config_file(tmp_path,method);api=importlib.import_module('support.poisoning_runner')
    a=api.run_verified(config);b=api.run_verified(config)
    av=json.loads((a/'verification.json').read_text());bv=json.loads((b/'verification.json').read_text())
    assert av['testing_only'] and not av['test_scored'] and av['delivered_labels_verified'] and av['aggregation_verified']
    assert av['flipped_unique_rows_per_active_round']==2
    assert av['final_state_sha256']==bv['final_state_sha256']
    events=json.loads((a/'attack_ground_truth.json').read_text())
    assert sum(r['active_attack'] for r in events['events'])==1


@pytest.mark.parametrize('damage',['labels','visits','event','weights','history','local_state','source'])
def test_corrupted_evidence_rejected(tmp_path,damage):
    config=config_file(tmp_path);api=importlib.import_module('support.poisoning_runner');p=api.run_poisoning(config)
    if damage in ['labels','visits']:
        f=next((p/'label_audits').glob('*.npz'))
        with np.load(f) as a:v={k:a[k] for k in a.files}
        v['observed_labels' if damage=='labels' else 'access_counts'][0]=99;np.savez(f,**v)
    elif damage=='event':
        f=p/'attack_ground_truth.json';v=json.loads(f.read_text());v['events'][-1]['flipped_unique_rows']=999;f.write_text(json.dumps(v))
    elif damage=='weights':
        f=p/'aggregation_evidence/round_001.pt';v=torch.load(f,weights_only=True);v['weights'][next(iter(v['weights']))]=float('nan');torch.save(v,f)
    elif damage in ['history','local_state']:
        f=p/'checkpoint.pt' if damage=='history' else p/'aggregation_evidence/round_001.pt';v=torch.load(f,weights_only=True)
        state=v['history']['client_000'][1] if damage=='history' else v['client_states']['client_000'];state[next(iter(state))].add_(.1);torch.save(v,f)
    else:
        meta=json.loads((p/'metadata.json').read_text());f=meta['federated_inputs']['clients'][0]['data_path']
        with np.load(f) as a:v={k:a[k] for k in a.files}
        v['labels'][0]=1-v['labels'][0];np.savez(f,**v)
    with pytest.raises(ValueError):importlib.import_module('support.poisoning_verification').verify_run(p)


@pytest.mark.parametrize('method',['fedavg','fedmade','temporal'])
def test_tiny_zero_attack_matches_original_method(tmp_path,method):
    config=config_file(tmp_path,method,enabled=False);outer=yaml.safe_load(config.read_text());base=outer['baseline_config_path']
    api=importlib.import_module('support.poisoning_runner');poison=api.run_verified(config)
    if method=='fedavg':clean=importlib.import_module('support.federated_runner').run_federated(base)
    else:clean=importlib.import_module(f'support.{method}_runner').run_verified(base)
    left=torch.load(poison/'checkpoint.pt',weights_only=True)['model_state'];right=torch.load(clean/'checkpoint.pt',weights_only=True)['model_state']
    assert all(torch.equal(left[k],right[k]) for k in left)
    assert json.loads((poison/'validation_metrics.json').read_text())==json.loads((clean/'validation_metrics.json').read_text())
