import copy
import pytest
from support.tests.test_fedmade_runner import inputs
from support.federated.temporal import DEFAULTS
from support.utils.temporal_config import load_temporal_config,validate_temporal_config
import yaml


def configuration(tmp_path):
    path,_=inputs(tmp_path);v=yaml.safe_load(path.read_text());v.pop('fedmade')
    v['federated']['aggregation']='temporal';v['temporal']={**DEFAULTS,'reference_run_path':None}
    path.write_text(yaml.safe_dump(v));return path


def test_configuration_and_resolved_paths(tmp_path):
    p=configuration(tmp_path);v=load_temporal_config(p)
    assert v['temporal']['window']==5 and v['federated']['aggregation']=='temporal'


@pytest.mark.parametrize('field,value',[('window',4),('components',3),('forgetting',.9),('warmup_rounds',0),('downweight',.9),('projection_dim',True),('extra',1)])
def test_cannot_silently_change_frozen_method(tmp_path,field,value):
    p=configuration(tmp_path);v=yaml.safe_load(p.read_text());v['temporal'][field]=value
    with pytest.raises(ValueError):validate_temporal_config(v)


def test_gpu_and_artifact_initialization_rejected(tmp_path):
    p=configuration(tmp_path);v=yaml.safe_load(p.read_text())
    for section,field,value in [('experiment','device','cuda'),('initialization','mode','artifact')]:
        bad=copy.deepcopy(v);bad[section][field]=value
        with pytest.raises(ValueError):validate_temporal_config(bad)
