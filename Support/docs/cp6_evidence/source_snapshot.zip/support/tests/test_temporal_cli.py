from pathlib import Path
import sys
import pytest
import main


def test_explicit_temporal_route(monkeypatch,capsys,tmp_path):
    calls=[];monkeypatch.setattr(main,'run_temporal',lambda p:calls.append(p) or tmp_path)
    monkeypatch.setattr(sys,'argv',['main.py','--temporal','--config','example.yaml'])
    main.main();assert calls==[Path('example.yaml')]
    assert 'temporal' in capsys.readouterr().out


@pytest.mark.parametrize('args',[['--temporal'],['--temporal','--fedmade'],['--temporal','--federated']])
def test_explicit_config_and_unique_workflow(monkeypatch,args):
    monkeypatch.setattr(sys,'argv',['main.py',*args])
    with pytest.raises(SystemExit) as error:main.main()
    assert error.value.code==2
