"""Fabricated records exercise report arithmetic; not research evidence."""
import importlib,json
from pathlib import Path
import pytest


def test_effects_preserve_sign_and_target_confusion():
    api=importlib.import_module('support.poisoning_analysis')
    def metrics(recall,to_benign):
        return dict(accuracy=.8,balanced_accuracy=.7,macro_f1=.6,weighted_f1=.75,loss=.4,
          per_class=[dict(class_id=0,support=10,precision=.8,recall=.8,f1=.8),dict(class_id=1,support=10,precision=recall,recall=recall,f1=recall)],
          confusion_matrix=[[8,2],[to_benign,10-to_benign]])
    effect=api.metric_differences(metrics(.8,2),metrics(.6,4),1,0)
    assert effect['recall_degradation']==pytest.approx(.2)
    assert effect['delta_target_to_benign_rate']==pytest.approx(.2)
    assert api.metric_differences(metrics(.6,4),metrics(.8,2),1,0)['recall_degradation']==pytest.approx(-.2)


def test_fedavg_is_not_a_client_detector(tmp_path):
    p=tmp_path;truth=dict(selected_malicious=['a'],attack=dict(start_round=4,end_round=20))
    (p/'attack_ground_truth.json').write_text(json.dumps(truth))
    (p/'aggregation_weights.csv').write_text('round_id,client_id,sample_count,weight\n4,a,10,0.5\n4,b,10,0.5\n')
    (p/'client_class_counts.json').write_text(json.dumps({'a':[1,1],'b':[1,1]}))
    result=importlib.import_module('support.poisoning_analysis').client_penalties(p,'fedavg')
    assert result['attack_detection_available'] is False
    assert result['malicious_aggregation_mass_mean']==.5


def test_zero_control_failure_refuses_comparison(tmp_path):
    from support.poisoning_experiments import case_order
    entries=[{**c,'run_path':str(tmp_path)} for c in case_order()]
    (tmp_path/'progress.json').write_text(json.dumps(entries))
    (tmp_path/'verification.json').write_text(json.dumps(dict(testing_only=False,test_scored=False,delivered_labels_verified=True,aggregation_verified=True,reloaded_validation_exact=True,paired_controls_verified=True,zero_attack_matches_clean=False)))
    with pytest.raises(ValueError):importlib.import_module('support.poisoning_analysis').analyze(tmp_path/'progress.json',tmp_path/'out')


def test_complete_analysis_with_logger_yaml_and_all_cases(tmp_path):
    import csv,yaml
    from support.data.latest_audit import source_hash
    from support.evaluation.metrics import classification_metrics
    from support.poisoning_experiments import case_order
    entries=[]
    for case in case_order():
        clean=tmp_path/('clean_'+case['name']);p=tmp_path/case['name'];clean.mkdir();p.mkdir()
        truth=[0]*10+[1]*10
        before=classification_metrics(truth,[0]*8+[1]*2+[0]*2+[1]*8,2);before['loss']=.4
        after=classification_metrics(truth,[0]*8+[1]*2+[0]*4+[1]*6,2);after['loss']=.5
        common=dict(initial_state_sha256='same',rounds=4,train_rows=20,client_rows={'a':10,'b':10},validation_rows=20)
        verification=dict(**common,testing_only=False,test_scored=False,aggregation_verified=True,delivered_labels_verified=True,
            reloaded_validation_exact=True,paired_controls_verified=True,zero_attack_matches_clean=True if case['control'] else None)
        (p/'verification.json').write_text(json.dumps(verification));(clean/'verification.json').write_text(json.dumps(common))
        meta=dict(seed=case['seed'],evaluation_role='validation',federated_inputs=dict(bundle_sha256=case['condition']+str(case['seed']),contract=dict(class_names=['benign','target'])))
        (clean/'metadata.json').write_text(json.dumps(meta));(p/'metadata.json').write_text(json.dumps(dict(**meta,workflow='prepared_poisoning',method=case['method'],paired_clean_run=str(clean))))
        (clean/'validation_metrics.json').write_text(json.dumps(dict(metrics=before)));(p/'validation_metrics.json').write_text(json.dumps(dict(metrics=after)))
        (p/'config.yaml').write_text(yaml.safe_dump(dict(attack=dict(target_class=1,destination_class=0))))
        (p/'attack_ground_truth.json').write_text(json.dumps(dict(selected_malicious=['a'],attack=dict(start_round=4,end_round=20))))
        (p/'aggregation_weights.csv').write_text('round_id,client_id,sample_count,weight\n4,a,10,0.5\n4,b,10,0.5\n')
        (p/'client_class_counts.json').write_text(json.dumps(dict(a=[5,5],b=[5,5])))
        if case['method']=='temporal':
            (p/'temporal_diagnostics').mkdir();(p/'temporal_diagnostics/round_004.json').write_text(json.dumps(dict(phase='scored',clients=[dict(client_id=c,decision='accept') for c in ['a','b']])))
        entries.append(dict(**case,run_path=str(p),verification_sha256=source_hash(p/'verification.json')))
    index=tmp_path/'progress.json';index.write_text(json.dumps(entries))
    result=importlib.import_module('support.poisoning_analysis').analyze(index,tmp_path/'out')
    assert len(result['pairs'])==18
    assert result['means']['fedavg']['iid']['recall_degradation']['mean']==pytest.approx(.2)
    with (tmp_path/'out/paired_per_class.csv').open() as f:assert len(list(csv.DictReader(f)))==36
