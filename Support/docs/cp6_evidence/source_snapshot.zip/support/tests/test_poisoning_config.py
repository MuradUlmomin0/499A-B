import importlib
import pytest,yaml
from support.tests.test_fedmade_runner import inputs
from support.federated.temporal import DEFAULTS


def config_file(tmp_path,method='fedavg',enabled=True):
    base,_=inputs(tmp_path);v=yaml.safe_load(base.read_text())
    if method!='fedmade':v.pop('fedmade')
    v['federated']['aggregation']=method
    if method=='temporal':v['temporal']={**DEFAULTS,'reference_run_path':None}
    base.write_text(yaml.safe_dump(v));path=tmp_path/'poison.yaml'
    value=dict(schema_version=1,method=method,experiment=dict(name='test_poison',output_dir=str(tmp_path/'poison_results')),
        baseline_config_path=str(base),reference_clean_run_path=None,
        attack=dict(type='targeted_label',enabled=enabled,target_class=1,destination_class=0,malicious_clients=1 if enabled else 0,
                    start_round=2,end_round=2,selection_seed_offset=5005))
    path.write_text(yaml.safe_dump(value));return path


@pytest.mark.parametrize('method',['fedavg','fedmade','temporal'])
def test_all_method_configurations(tmp_path,method):
    p=config_file(tmp_path,method);v=importlib.import_module('support.utils.poisoning_config').load_poisoning_config(p)
    assert v['method']==method and v['_baseline']['federated']['aggregation']==method


@pytest.mark.parametrize('field,value',[('target_class',True),('target_class',0),('start_round',0),('end_round',3),('malicious_clients',-1),('selection_seed_offset',1),('enabled',0),('extra',1)])
def test_invalid_attack_settings(tmp_path,field,value):
    p=config_file(tmp_path);v=yaml.safe_load(p.read_text());v['attack'][field]=value;p.write_text(yaml.safe_dump(v))
    with pytest.raises(ValueError):importlib.import_module('support.utils.poisoning_config').load_poisoning_config(p)
