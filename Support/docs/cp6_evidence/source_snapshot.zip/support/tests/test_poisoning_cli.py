from pathlib import Path
import sys
import pytest,main


def test_poisoning_route(monkeypatch,capsys,tmp_path):
    seen=[];monkeypatch.setattr(main,'run_poisoning',lambda p:seen.append(p) or tmp_path)
    monkeypatch.setattr(sys,'argv',['main.py','--poisoning','--config','attack.yaml']);main.main()
    assert seen==[Path('attack.yaml')] and 'poisoning' in capsys.readouterr().out


@pytest.mark.parametrize('args',[['--poisoning'],['--poisoning','--temporal'],['--poisoning','--fedmade']])
def test_explicit_poison_config_and_unique_workflow(monkeypatch,args):
    monkeypatch.setattr(sys,'argv',['main.py',*args])
    with pytest.raises(SystemExit) as e:main.main()
    assert e.value.code==2
