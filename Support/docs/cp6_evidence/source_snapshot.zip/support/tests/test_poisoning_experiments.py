import importlib,json
from pathlib import Path
import pytest


def test_case_order_controls_then_pilots_then_remaining():
    cases=importlib.import_module('support.poisoning_experiments').case_order()
    assert len(cases)==21 and len(set(c['name'] for c in cases))==21
    assert all(c['control'] for c in cases[:3])
    assert all(c['condition']=='dirichlet' and c['seed']==42 for c in cases[3:6])
    assert not any(c['control'] for c in cases[3:])


def test_full_matrix_progress_and_resume_without_rerunning(tmp_path,monkeypatch):
    api=importlib.import_module('support.poisoning_experiments');cases=api.case_order();configs=tmp_path/'configs';configs.mkdir();runs=tmp_path/'runs';runs.mkdir()
    for c in cases:(configs/(c['name']+'.yaml')).write_text('placeholder')
    def load(p):return dict(experiment=dict(output_dir=str(runs),name=p.stem))
    monkeypatch.setattr(api,'load_poisoning_config',load);monkeypatch.setattr(api,'guard',lambda d:None)
    called=[]
    def worker(command,**kwargs):
        name=Path(command[-1]).stem;called.append(name);p=runs/(name+'_completed');p.mkdir()
        case=next(c for c in cases if c['name']==name)
        (p/'verification.json').write_text(json.dumps(dict(testing_only=False,test_scored=False,aggregation_verified=True,delivered_labels_verified=True,reloaded_validation_exact=True,paired_controls_verified=True,zero_attack_matches_clean=True if case['control'] else None)))
    monkeypatch.setattr(api.subprocess,'run',worker)
    entries=api.run_matrix(configs,tmp_path/'matrix')
    assert len(entries)==21 and len(called)==21
    assert len(json.loads((tmp_path/'matrix/progress.json').read_text()))==21
    entries=api.run_matrix(configs,tmp_path/'matrix',resume=True);assert len(entries)==21 and len(called)==21


def test_failed_zero_control_stops_before_attacks(tmp_path,monkeypatch):
    api=importlib.import_module('support.poisoning_experiments');configs=tmp_path/'configs';configs.mkdir();runs=tmp_path/'runs';runs.mkdir()
    for c in api.case_order():(configs/(c['name']+'.yaml')).write_text('placeholder')
    monkeypatch.setattr(api,'guard',lambda d:None)
    monkeypatch.setattr(api,'load_poisoning_config',lambda p:dict(experiment=dict(output_dir=str(runs),name=p.stem)))
    called=[]
    def worker(command,**kwargs):
        called.append(command);p=runs/(Path(command[-1]).stem+'_bad');p.mkdir();(p/'verification.json').write_text(json.dumps(dict(testing_only=False,test_scored=False,aggregation_verified=True,delivered_labels_verified=True,reloaded_validation_exact=True,paired_controls_verified=True,zero_attack_matches_clean=False)))
    monkeypatch.setattr(api.subprocess,'run',worker)
    with pytest.raises(ValueError):api.run_matrix(configs,tmp_path/'matrix')
    assert len(called)==1
