"""Artificial mathematical tests; values are not research results."""
from collections import OrderedDict
import numpy as np
import pytest
import torch
from support.federated.fusion import blend_weights,ProposedAggregator
from support.federated.types import ClientResult


def test_equal_blend_and_rescue():
    assert blend_weights({'a':0.,'b':1.},{'a':.8,'b':.2},.5)=={'a':.4,'b':.6}


@pytest.mark.parametrize('lam',[0.,1.])
def test_endpoints(lam):
    a={'a':.25,'b':.75};b={'a':.8,'b':.2}
    assert blend_weights(a,b,lam)==(a if lam else b)


@pytest.mark.parametrize('a,b,lam',[({'a':0.},{'a':1.},.5),({'a':1.},{'b':1.},.5),({'a':float('nan')},{'a':1.},.5),({'a':1.},{'a':1.},2.),({'a':-1.,'b':2.},{'a':.5,'b':.5},.5)])
def test_invalid_components_stop(a,b,lam):
    with pytest.raises(ValueError):blend_weights(a,b,lam)


def test_composition_uses_original_states_once(tmp_path):
    class Component:
        def __init__(self,w):self.w=w;self.calls=0
        def aggregate(self,results):self.calls+=1;return {},self.w
    t=Component({'a':.25,'b':.75});c=Component({'a':.8,'b':.2})
    results=[ClientResult(k,1,1,OrderedDict(w=torch.tensor([v])),OrderedDict(w=torch.tensor([v])),{}) for k,v in [('a',1.),('b',3.)]]
    state,weights=ProposedAggregator(t,c,.5,tmp_path/'fusion').aggregate(results)
    assert state['w'].item()==pytest.approx(.525+3*.475)
    assert weights=={'a':.525,'b':.475} and t.calls==c.calls==1


@pytest.mark.parametrize('lam',[0.,1.])
@pytest.mark.parametrize('failure',['exception','invalid'])
def test_endpoint_component_failure_saved_and_raised(tmp_path,lam,failure):
    class Component:
        def aggregate(self,results):
            if failure=='exception':raise RuntimeError('component failed')
            return {},{'a':float('nan')}
    class Valid:
        def aggregate(self,results):return {},{'a':1.}
    # Fail the component whose final blend coefficient is zero.
    t,c=(Component(),Valid()) if lam==0 else (Valid(),Component())
    results=[ClientResult('a',1,1,OrderedDict(w=torch.tensor([1.])),OrderedDict(w=torch.tensor([1.])),{})]
    with pytest.raises((ValueError,RuntimeError)):ProposedAggregator(t,c,lam,tmp_path/'fusion').aggregate(results)
    import json
    failure_record=json.loads((tmp_path/'fusion/failure_round_001.json').read_text())
    assert failure_record['round_id']==1 and failure_record['error']
    saved=torch.load(tmp_path/'fusion/failure_round_001.pt',weights_only=True)
    assert torch.equal(saved['client_states']['a']['w'],results[0].state['w'])


@pytest.mark.parametrize('lam',[0.,.5,1.])
def test_float64_sensitive_original_accumulation_and_endpoint_calls(lam):
    class Component:
        def __init__(self,w):self.w=w;self.calls=0
        def aggregate(self,results):self.calls+=1;return OrderedDict(w=torch.tensor([-999.])),self.w
    weights={'a':.25,'b':.5,'c':.25};t=Component(weights);c=Component(weights)
    values=[1e8,1.,-1e8]
    results=[ClientResult(k,1,1,OrderedDict(w=torch.tensor([v],dtype=torch.float32)),OrderedDict(w=torch.tensor([v],dtype=torch.float32)),{}) for k,v in zip(weights,values)]
    state,_=ProposedAggregator(t,c,lam).aggregate(results)
    assert state['w'].item()==.5 and t.calls==c.calls==1
