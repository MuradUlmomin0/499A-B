from pathlib import Path
import sys
import pytest,main


def test_fusion_route(monkeypatch,capsys,tmp_path):
    seen=[];monkeypatch.setattr(main,'run_fusion',lambda p:seen.append(p) or tmp_path)
    monkeypatch.setattr(sys,'argv',['main.py','--fusion','--config','fusion.yaml']);main.main()
    assert seen==[Path('fusion.yaml')] and 'Fusion' in capsys.readouterr().out


@pytest.mark.parametrize('args',[['--fusion'],['--fusion','--poisoning'],['--fusion','--temporal']])
def test_explicit_fusion_config(monkeypatch,args):
    monkeypatch.setattr(sys,'argv',['main.py',*args])
    with pytest.raises(SystemExit) as e:main.main()
    assert e.value.code==2
