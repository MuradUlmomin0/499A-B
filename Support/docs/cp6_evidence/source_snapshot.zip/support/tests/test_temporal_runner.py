"""Testing-only small prepared-data runs and corrupted evidence."""
import importlib
import json
import numpy as np
import pytest
import torch
from support.tests.test_temporal_config import configuration


def test_tiny_runner_exact_reload_and_repeat(tmp_path):
    config=configuration(tmp_path);api=importlib.import_module('support.temporal_runner')
    a=api.run_verified(config);b=api.run_verified(config)
    av=json.loads((a/'verification.json').read_text());bv=json.loads((b/'verification.json').read_text())
    assert av['testing_only'] and not av['test_scored'] and av['temporal_equations_verified']
    assert av['final_state_sha256']==bv['final_state_sha256']
    assert (a/'trust_scores.csv').exists() and (a/'honest_client_penalties.json').exists()
    with np.load(a/'temporal_diagnostics/round_002.npz') as aa,np.load(b/'temporal_diagnostics/round_002.npz') as bb:
        for k in aa.files:assert np.array_equal(aa[k],bb[k])


@pytest.mark.parametrize('damage',['projection','score','weight','local_state','global_state','history','threshold','trajectory','component','mixture','projected','logged_weight','logged_nan'])
def test_verification_catches_corruption(tmp_path,damage):
    config=configuration(tmp_path);api=importlib.import_module('support.temporal_runner');path=api.run_temporal(config)
    if damage in ['logged_weight','logged_nan']:
        import csv
        p=path/'aggregation_weights.csv'
        with p.open() as f:rows=list(csv.DictReader(f))
        rows[0]['weight']='nan' if damage=='logged_nan' else '.123'
        with p.open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    elif damage=='projection':
        p=path/'temporal_diagnostics/projection.npy';a=np.load(p);a[0,0]+=.1;np.save(p,a)
    elif damage in ['mixture','projected']:
        p=path/('temporal_diagnostics/round_002.npz' if damage=='mixture' else 'temporal_diagnostics/round_001.npz')
        with np.load(p) as a:values={k:a[k] for k in a.files}
        values['means' if damage=='mixture' else 'projected'][0,0]+=.1;np.savez(p,**values)
    elif damage in ['threshold','trajectory','component']:
        p=path/'temporal_diagnostics/round_001.json';a=json.loads(p.read_text())
        if damage=='threshold':a['thresholds']['norm']=1.
        else:a['clients'][0][damage]=99.
        p.write_text(json.dumps(a))
    elif damage in ['score','weight']:
        p=path/'temporal_diagnostics/round_001.json';a=json.loads(p.read_text());a['clients'][0]['norm' if damage=='score' else 'weight']+=.1;p.write_text(json.dumps(a))
    else:
        p=path/'checkpoint.pt' if damage=='history' else path/'temporal_diagnostics/round_001.pt';a=torch.load(p,weights_only=True)
        state=a['history']['client_000'][1] if damage=='history' else a['client_states']['client_000'] if damage=='local_state' else a['aggregated_state']
        state[next(iter(state))].add_(.1);torch.save(a,p)
    with pytest.raises(ValueError):importlib.import_module('support.temporal_verification').verify_run(path)


def test_missing_preparation_and_preflight_rejected(tmp_path):
    config=configuration(tmp_path);(tmp_path/'prepared/preparation_report.json').unlink()
    api=importlib.import_module('support.temporal_runner')
    with pytest.raises(ValueError):api.run_temporal(config)
    with pytest.raises(ValueError,match='preflight'):api.run_matrix(tmp_path/'missing',tmp_path/'matrix')


def test_direct_runner_records_single_thread_pools(tmp_path):
    config=configuration(tmp_path);api=importlib.import_module('support.temporal_runner');path=api.run_verified(config)
    meta=json.loads((path/'metadata.json').read_text())
    assert meta['numerical_threadpools'] and all(p['num_threads']==1 for p in meta['numerical_threadpools'])
    v=json.loads((path/'verification.json').read_text());assert len(v['projection_sha256'])==64


def test_changed_training_source_rejected(tmp_path):
    config=configuration(tmp_path);api=importlib.import_module('support.temporal_runner');path=api.run_temporal(config)
    meta=json.loads((path/'metadata.json').read_text());data=meta['federated_inputs']['clients'][0]['data_path']
    with np.load(data) as a:values={k:a[k] for k in a.files}
    values['labels'][0]=1-values['labels'][0];np.savez(data,**values)
    with pytest.raises(ValueError):importlib.import_module('support.temporal_verification').verify_run(path)


def test_matrix_progress_can_record_more_than_one_case(tmp_path,monkeypatch):
    api=importlib.import_module('support.temporal_runner')
    configs=tmp_path/'configs';configs.mkdir();results=tmp_path/'runs';results.mkdir()
    for condition in ['iid','dirichlet']:
        for seed in [42,43,44]:(configs/f'{condition}_seed{seed}.yaml').write_text('placeholder')
    from support.data.latest_audit import source_hash
    bundle=tmp_path/'bundle';bundle.write_text('identity')
    (configs/'preflight.json').write_text(json.dumps(dict(config_sha256=source_hash(configs/'iid_seed42.yaml'),bundle_sha256=source_hash(bundle),peak_process_rss_kib=1,training_performed=False)))
    monkeypatch.setattr(api,'load_temporal_config',lambda p:dict(experiment=dict(output_dir=str(results),name=p.stem),dataset=dict(bundle_path=str(bundle))))
    def worker(command,**kwargs):
        config=__import__('pathlib').Path(command[-1]);p=results/(config.stem+'_completed');p.mkdir();(p/'verification.json').write_text('{}')
    monkeypatch.setattr(api.subprocess,'run',worker)
    import support.research_runner
    monkeypatch.setattr(support.research_runner,'summarize_matrix',lambda entries,out:entries)
    entries=api.run_matrix(configs,tmp_path/'matrix')
    assert len(entries)==6 and len(json.loads((tmp_path/'matrix/progress.json').read_text()))==6
