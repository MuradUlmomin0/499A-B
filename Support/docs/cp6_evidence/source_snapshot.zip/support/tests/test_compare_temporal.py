"""Reporting-integrity tests use fabricated records, never research metrics."""
import csv
import importlib
import json
from pathlib import Path
import pytest
from support.tests.test_compare_fedmade import records


def temporal_records(tmp_path):
    summary,entries=records(tmp_path)
    for e in entries:
        p=Path(e['run_path'])/'metadata.json';v=json.loads(p.read_text());v['workflow']='prepared_temporal_adapted';p.write_text(json.dumps(v))
    return summary,entries


def test_paired_temporal_tables(tmp_path):
    summary,_=temporal_records(tmp_path)
    out=importlib.import_module('support.compare_temporal').compare(summary,tmp_path/'out')
    assert out['conditions']['dirichlet']['macro_f1']['temporal_mean']==1.
    assert out['conditions']['iid']['macro_f1']['mean_delta']==.5
    with (tmp_path/'out/paired_per_class.csv').open() as f:assert len(list(csv.DictReader(f)))==12


@pytest.mark.parametrize('damage',['seed','support','scope','test_scored','initial_state'])
def test_mismatched_pairs_rejected(tmp_path,damage):
    summary,entries=temporal_records(tmp_path);p=Path(entries[0]['run_path'])
    if damage in ['seed','scope']:
        p=p/'metadata.json';v=json.loads(p.read_text());v['seed' if damage=='seed' else 'workflow']=99 if damage=='seed' else 'prepared_fedmade_adapted'
    else:
        p=p/'verification.json';v=json.loads(p.read_text());v[{'support':'validation_rows','test_scored':'test_scored','initial_state':'initial_state_sha256'}[damage]]={'support':99,'test_scored':True,'initial_state':'different'}[damage]
    p.write_text(json.dumps(v))
    with pytest.raises(ValueError):importlib.import_module('support.compare_temporal').compare(summary,tmp_path/'out')
