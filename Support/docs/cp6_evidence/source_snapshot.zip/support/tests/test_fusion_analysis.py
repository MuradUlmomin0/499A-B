import csv,json
import pytest
from support.fusion_analysis import fusion_penalties


def test_temporal_rejection_is_separate_from_final_exclusion(tmp_path):
    (tmp_path/'temporal_diagnostics').mkdir()
    (tmp_path/'attack_ground_truth.json').write_text(json.dumps(dict(selected_malicious=['b'],attack=dict(start_round=4,end_round=20))))
    (tmp_path/'client_class_counts.json').write_text(json.dumps(dict(a=[1,1],b=[1,0])))
    with (tmp_path/'aggregation_weights.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['round_id','client_id','sample_count','weight']);w.writeheader()
        w.writerows([dict(round_id=4,client_id='a',sample_count=2,weight=.2),dict(round_id=4,client_id='b',sample_count=1,weight=.8)])
    (tmp_path/'temporal_diagnostics/round_004.json').write_text(json.dumps(dict(round_id=4,phase='scored',clients=[dict(client_id='a',decision='reject'),dict(client_id='b',decision='accept')])))
    result=fusion_penalties(tmp_path)
    assert result['honest']['rejection_rate']==1 and result['honest']['zero_weight_rate']==0
    assert result['honest']['weight_below_fedavg_rate']==1
    assert result['temporal_rejected_with_positive_fused_weight']==1
    assert not result['attack_detection_available'] and result['temporal_component_detection_available']
    assert result['malicious_aggregation_mass_mean']==.8
