# CP5 — controlled poisoning protocol draft

13 November 2026. **Approved by the user on 13 November 2026.**
This document records the pre-implementation specification.

## Recommended approach and alternative

Start with targeted label poisoning. It directly tests whether an attacker can
reduce detection of a less frequent class, without adding a second model or
changing the proposed fusion design. An optional second approach is a separate
sign-flip update attack for general model disruption; adding it would roughly
double the attacked-run matrix. Neither is automatically a stealth attack.

## Approved first attack

| Decision | Proposed setting |
|---|---|
| Attacker capability | Control training labels on its own client partition; cannot change features, sample counts or other clients |
| Knowledge | Own partition, broadcast model and public training protocol; no validation, test, server auxiliary records or other clients' updates |
| Objective | Reduce true DoS-HTTP_Flood recall by relabeling its local examples as BenignTraffic |
| Target | DoS-HTTP_Flood, class ID 18; 772 frozen training examples |
| Destination | BenignTraffic, class ID 1 |
| Corruption | All target examples on each selected malicious client during active attack rounds; all other labels unchanged |
| Malicious fraction | Two of ten clients (20%); fixed identities across rounds and matched methods |
| Selection | Python random.Random(experiment_seed + 5005).sample(sorted(client_ids), 2); independent of labels, detector scores and validation performance |
| Timing | Rounds 1–3 honest; poison rounds 4–20. This grants an explicitly clean warm-up and is a limited threat scenario |
| Training | Same one local epoch, Adam 0.001, batch 128, MLP, initialization, selection and final-round export as the frozen clean protocol |
| Upload | Actual resulting local model and its consistent local-minus-broadcast update; no update scaling or fabricated sample count |
| Source preservation | Lazy training-label view; original NPZ, manifests, preprocessing, labels on disk and all holdout/auxiliary roles unchanged |
| Defense access | Aggregators receive ordinary client results only; attacker identities and corruption counts belong in separate evaluator logs |
| Seeds/partitions | IID-style and Dirichlet alpha 0.5; seeds 42, 43, 44; same partitions and malicious identities across all three methods |
| Final test | Remains unscored |

The current server sees structured model parameters/updates. This protocol
simulates malicious client training in the local research framework; it does not
attack external services or devices.

## Target selection and support evidence

Clean validation results have already been inspected. This target choice is
therefore exploratory and must be disclosed, then frozen before attacked runs.
It is not a target chosen from an untouched evaluation set.

All seven lowest-support categories have zero recall in every one of the 18
clean CP2/CP3/CP4 models. DictionaryBruteForce also has zero recall in several
cases. DoS-HTTP_Flood has 772 training examples (0.1544% of 500,000) and nonzero
recall in all 18 clean models, approximately 63–83%. Thus recall degradation is
measurable without changing the existing training population or class weights.

A support-only audit of the proposed identity-selection rule found:

| Condition | Seed | Selected clients | Target rows on those clients |
|---|---:|---|---:|
| IID-style | 42 | client_008, client_003 | 77, 77 |
| IID-style | 43 | client_005, client_000 | 77, 77 |
| IID-style | 44 | client_000, client_004 | 77, 77 |
| Non-IID | 42 | client_008, client_003 | 157, 72 |
| Non-IID | 43 | client_005, client_000 | 29, 50 |
| Non-IID | 44 | client_000, client_004 | 88, 21 |

Both selected clients have target examples in every case; no replacement or
selection conditioned on target availability was necessary. The unequal number
of affected records is part of the frozen non-IID setting and must be reported.

## Implementation and execution sequence after approval

1. Write the final design and implementation plan, then mathematical/unit tests
   for label mapping, timing, fixed selection, source immutability and the zero
   attack case. Implement modular attack interfaces using existing clients.
2. Integrate the same attack schedule with FedAvg, adapted FedMADE and temporal
   trust. Keep their scoring mathematics and the original clean runners intact.
3. Run one real-data zero-attack replay per method, using non-IID seed 42; require
   exact matching with its frozen clean model and metrics.
4. Run the three non-IID seed 42 attacked cases first as a pilot. Check the actual
   poisoned-label counts and unchanged non-target examples independently.
5. If execution/verification succeeds, continue the remaining 15 attacked cases
   with the same frozen settings. The pilot is included in the 18-case matrix.
   Do not strengthen or retarget the attack automatically if it is ineffective;
   report a null result and seek review before any protocol change.
6. Compare each attacked model with its corresponding clean baseline. Save
   per-class metrics, target recall/F1 changes, target-to-benign confusion,
   global accuracy/macro F1 changes, client weights, temporal scores, and
   honest/malicious-client penalty rates where the method provides them.
7. Independently verify evidence, export models, write report/guide and update
   checkpoint status. Do not mark CP5 complete merely because attack code runs.

This is 18 attacked runs plus three real zero-attack controls, approximately
1.5–2.5 hours using prior per-case timings, excluding coding/testing and variation
in desktop load. Execute sequentially on CPU with one numerical thread and the
existing memory preflight guard for the 8 GB machine.

## Interpretation limits

A targeted label-flipping attack may be ineffective. Successful label changes do
not prove successful poisoning. Show the observed clean-to-attacked differences
for every method, seed and class, including improvements or unchanged scores.

The three clean warm-up rounds are an explicit assumption; this does not cover
attackers active from initialization. There is no parameter-similarity constraint,
no adaptive evasion optimizer and no concealment objective. Do not label this
stealth poisoning. The proposed temporal/class-utility fusion remains CP6 work.
