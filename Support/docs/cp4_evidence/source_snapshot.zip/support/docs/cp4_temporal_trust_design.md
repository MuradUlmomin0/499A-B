# CP4 — proposed temporal-trust baseline

Status: **Approved by the user on 12 November 2026; frozen before implementation.**
Date: 12 November 2026. No CP4 implementation or research run is complete.

## Purpose

Implement a SecureDyn-inspired temporal/update-space baseline within the
existing framework. Compare it with frozen CP2 FedAvg on the same six clean
cases. Characterize how often it penalizes honest, non-IID clients, including
clients holding rare classes. This is an inspired adaptation, not a full
SecureDyn-FL reproduction or a demonstrated poisoning defense.

## What the supplied paper specifies

Source: `SecureDyn_FL_Paper.pdf`, Section V-J, Phase 2, equations 24–26,
and Section VI, auditor training.

- Blend old and newly estimated GMM parameters using a forgetting factor.
- Compute Mahalanobis distance (MD) to the assigned component.
- Track consecutive-round distance variation: abs(MD[t] - MD[t-1]).
- Use update magnitude, MD and trajectory thresholds to accept, down-weight
  or reject updates.
- The MD threshold is described as k times the standard deviation of benign
  MD values. Auditor training also describes labeled benign/malicious updates.

The paper does not supply a complete executable specification for the history
window, forgetting factor, threshold calibration, moderate/severe boundaries,
component correspondence across rounds or trust-to-weight conversion. Our
benchmark has no labeled auditor-training updates. The legacy script uses
synthetic data and majority-cluster rejection; it is not a faithful substitute.

## Approaches considered

1. **Full paper reproduction:** requires additional auditor-training data and
   decisions about personalization, encryption and other paper components.
   This exceeds CP4 and the existing matched benchmark.
2. **Unsupervised temporal adaptation (recommended):** make all missing rules
   explicit, freeze them before runs, and use no attacker labels or validation
   performance to choose them. Measure honest-client penalties directly.

## Approved numeric specification

These are proposed engineering/research choices, not values reported by the
paper. None is selected from observed validation performance.

| Item | Proposed rule |
|---|---|
| Update | Structured local-minus-broadcast state, using existing parameter utilities |
| Low-dimensional representation | Fixed Gaussian random projection to 5 dimensions; entries N(0, 1/5), seed 1729, generated once per parameter schema; no per-round refitting or normalization |
| Magnitude | Euclidean norm of the original flattened update, before projection |
| GMM fitting window | Projected observations from the current and preceding four rounds; only actual participating clients |
| GMM | Two components, diagonal covariance, reg_covar=1e-6, one initialization, max_iter=200, tol=1e-3, fixed random_state=1729 |
| Incremental memory | Align new components to old means by minimum total squared distance, then blend weights, means and diagonal variances: 0.8 old + 0.2 new; recompute precision from blended variance |
| MD | Square root of the diagonal Mahalanobis quadratic form to the maximum-posterior component of the blended mixture |
| Trajectory | Absolute difference from the same client's immediately preceding round MD; unavailable across participation gaps |
| Warm-up | First three rounds use ordinary sample-weighted FedAvg while collecting evidence |
| Calibration history | Previous five rounds only, excluding current observations; all observed clients, without attacker/benign labels or selection by earlier acceptance |
| Thresholds | Separate mean + 3 population-standard-deviations for historical norm, MD and available trajectory; floor each at 1e-8 |
| Decision | Let s be the largest available current evidence/threshold ratio. s<=1: accept; 1<s<=2: down-weight; s>2: reject |
| Trust multiplier | Accept=1, down-weight=0.5, reject=0 |
| Aggregation | beta_i = n_i * trust_i / sum_j(n_j * trust_j), applied to local model states |
| Missing trajectory | Score available magnitude/MD only; record explicitly that trajectory is unavailable |
| Minimum calibration | At least 20 prior norm observations and 20 prior MD observations; otherwise whole-round warm-up FedAvg. Trajectory needs 20 prior valid consecutive-round differences; until then omit only trajectory |
| Degenerate fitting population | Fewer than two distinct projected observations: no GMM fit, FedAvg warm-up for that round; never label clients malicious |
| Mixture initialization | First successful fit is used directly without blending; fixed two components replaces the paper's BIC-based component-count selection |
| Skipped fitting round | Preserve the previous mixture; record norms but no MD or trajectory. Next valid fit blends with that mixture; trajectory comparisons cannot cross the missing round |
| Fit failure/non-convergence/non-finite state | Stop with a diagnostic, including an EM iteration-limit failure; no silent algorithm substitution |
| Every client rejected | Stop and preserve evidence; no silent uniform/FedAvg rescue |

The threshold rule deliberately differs from equation 26: it uses an unlabeled
historical mean plus three standard deviations rather than assuming access to
the standard deviation of known benign updates. The fixed projection, window,
diagonal covariance, component matching, decision bands and trust multipliers
are adaptations too. Updating diagonal variances by convex blending is a
declared parameter blend, not a claim of exact pooled-moment estimation.
Save the actual projection matrix and its hash for independent replay. Its
generation must use a private RNG and must not change model/training RNG state.

Historical evidence may be contaminated in later attacked runs. CP4 establishes
clean behavior only; it does not establish attack resistance or that statistical
outliers are attackers. All clients in CP4 are honest.

## Compatibility and evidence

Keep the common client/server interface and existing history storage. Add a
modular `TemporalTrustAggregator` with its own bounded scoring history. The
server's existing history is recorded after aggregation, so the scorer must
manage current observations explicitly. Do not change FedAvg or FedMADE.

Keep the CP1 data, partitions, MLP, six seed/condition pairs, initialization,
20 rounds, one local epoch, Adam 0.001, batch 128, full participation and
final-round export. Use CPU and one numerical thread on the 8 GB machine.
No final-test scoring, auxiliary class-utility input, poisoning, fusion,
encryption, pruning or personalization belongs in this checkpoint.

Save per-client per-round norms, MDs, trajectory values, calibration thresholds,
decisions, trust multipliers and final aggregation weights. Save projected
observations, mixture parameters, local states and aggregation evidence for
independent verification. Record warm-up and degenerate rounds separately.

Report both trust-based down-weighting and final weight relative to FedAvg:
normalization can increase another client's weight even when its trust is 0.5.
Report rejection/down-weight rates overall, by client and by presence of each
class. Identify the eight lowest-support classes from frozen training support
before running; do not tune the defense using their validation recall.

## Implementation and completion order

1. Approve/freeze this research specification and paper/adaptation mapping.
2. Implement scoring mathematics, history handling and analytical unit tests.
3. Implement aggregator, strict YAML settings and separate diagnostic logging;
   test boundary conditions, failures and tiny synthetic integration.
4. Add prepared-data runner and CLI using existing data validation/export
   infrastructure; verify initial-state and selection matching with CP2.
5. Run the complete test suite and an independent code review; fix failures.
6. Freeze code/configuration hashes; measure memory in preflight; run six clean
   cases sequentially and one full repeated case.
7. Independently verify scores, decisions, weights, weighted tensors, exports
   and evaluation. Compare all classes and honest-client penalty diagnostics.
8. Write the results report and beginner codebase guide; update README,
   `tsksdone.md` and checkpoint status with actual evidence.

Until these steps are completed, CP4 must remain pending.
