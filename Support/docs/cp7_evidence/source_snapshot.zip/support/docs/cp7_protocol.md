# CP7 final comparison protocol

Execution requested by the user after completion of CP6. This document records
the already agreed research conditions for the final comparison; it introduces
no new method, target, training setting, dataset or model selection rule.

Evaluate the final-round artifacts from CP2 (clean FedAvg), CP3 (clean adapted
FedMADE), CP4 (clean temporal trust), CP5 (poisoned versions of those methods),
and CP6 (clean/poisoned equal blend). Include four methods × two attack states ×
two partitions (IID-style, Dirichlet alpha 0.5) × three seeds (42/43/44):
**48 distinct saved models**. Exclude all endpoint controls, repeats and partial
attempts. No retraining, checkpoint selection or adjustment of lambda occurs.

Use every one of the 724,992 CP1 test records, its frozen 46-feature/34-class
contract and training-fitted preprocessing. Before the first prediction, bind
the exact 48-model registry, code, settings, historical verification evidence
and prepared files to a versioned SHA-256 freeze. Authenticate saved models
against historical completion evidence/archives. Require shared per-seed
initial states, client partitions, training budget and CP5 attack settings.
Previously verified source/group separation is authenticated; it cannot prove
device/capture independence.

Run inference sequentially on CPU with one numerical thread, batch 128,
evaluation mode and gradients disabled. Each model sees each test row once.
Save ordered class predictions and per-row cross-entropy losses; recompute
metrics from these saved arrays without running the model a second time.
Preserve completed cases on resume only after digest and identity checks.
Preserve partial attempts and never silently overwrite a result. On any invalid
input, mismatch or nonfinite result stop and save the failure.

Report every seed/class: accuracy, balanced accuracy, macro precision/recall/F1,
weighted F1, per-class precision/recall/F1/support, confusion matrices and loss.
For each of 24 paired cases report clean/attacked target recall and F1,
clean-minus-attacked degradation, target-to-benign errors and changes in global
metrics. Target 18 and benign destination 1 were frozen in CP5; target selection
was exploratory after clean validation inspection. Target-to-benign errors
include natural mistakes and are not automatically attack-success rates.

Summarize arithmetic mean and sample standard deviation across all three seeds,
matching earlier checkpoints. These are descriptive results, not confidence
intervals or significance claims. Include all 34 classes and the eight
lowest-training-support categories already identified in CP4. Preserve zero
recall, missing support, improvements and regressions. No thresholds or settings
may be chosen from the final test scores.

Reuse historical validation convergence, round/aggregation timing, measured
worker memory and evaluator-only client penalties explicitly. They describe the
training trajectories, not new test-time defense decisions. FedAvg has no
detector; class-only optimization zeros are exclusions; fused and temporal
component decisions remain distinct. Class-bearing client groups overlap.
Elapsed desktop timings cannot establish comparative efficiency.

The intended contribution is an empirical comparison of the approved simple
fusion, including negative findings. This stage does not establish novelty,
stealth resistance, physical-client independence or recovery of unlearned rare
classes. The final project packaging remains CP8.
