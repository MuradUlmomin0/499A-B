"""Small artificial fixtures verify CP7 software only, never research scores."""
import json
from pathlib import Path
from dataclasses import replace

import numpy as np
import pytest
import torch

from support.tests.test_prepared_evaluation import evaluation_fixture


def test_matrix_requires_all_48_unique_cases():
    from support.final_protocol import expected_cases, validate_cases
    cases = expected_cases()
    assert len(cases) == 48
    validate_cases(cases)
    for invalid in [cases[:-1], cases + [cases[0]], [cases[0]] * 48]:
        with pytest.raises(ValueError):
            validate_cases(invalid)


def test_hash_inventory_rejects_changed_or_empty_inputs(tmp_path):
    from support.final_protocol import authenticate, fingerprints
    p = tmp_path / 'source'
    p.write_text('original')
    inventory = fingerprints([p])
    authenticate(inventory)
    p.write_text('changed')
    with pytest.raises(ValueError, match='changed'):
        authenticate(inventory)
    with pytest.raises(ValueError):
        authenticate({})


@pytest.mark.parametrize('batch_size', [1, 2, 3, 8])
def test_single_pass_scores_and_offline_equations(evaluation_fixture, batch_size):
    from support.final_evaluation import score_model, metrics_from_evidence
    from support.evaluation.prepared import evaluate_prepared_data
    artifact, data = evaluation_fixture
    state = {k: v.clone() for k, v in artifact.model.state_dict().items()}
    reference = evaluate_prepared_data(artifact, data, expected_role='test', batch_size=batch_size)
    predictions, losses = score_model(artifact, data, batch_size=batch_size)
    assert predictions.tolist() == [0, 1, 0, 1, 0]
    metrics = metrics_from_evidence(data.dataset.tensors[1].numpy(), predictions, losses, artifact.contract.class_names)
    for key in ['accuracy', 'balanced_accuracy', 'macro_precision', 'macro_recall', 'macro_f1', 'weighted_f1', 'loss']:
        assert metrics[key] == pytest.approx(reference.metrics[key], abs=1e-12)
    assert metrics['confusion_matrix'] == reference.metrics['confusion_matrix']
    assert metrics['per_class'] == reference.metrics['per_class']
    assert all(torch.equal(v, state[k]) for k, v in artifact.model.state_dict().items())


@pytest.mark.parametrize('problem', ['negative_prediction', 'noninteger', 'nan_loss', 'negative_loss', 'wrong_length'])
def test_offline_metrics_reject_corrupt_arrays(problem):
    from support.final_evaluation import metrics_from_evidence
    truth = np.array([0, 1])
    pred = truth.copy()
    loss = np.ones(2)
    if problem == 'negative_prediction': pred[0] = -1
    if problem == 'noninteger': pred = pred.astype(float)
    if problem == 'nan_loss': loss[0] = np.nan
    if problem == 'negative_loss': loss[0] = -1
    if problem == 'wrong_length': pred = pred[:1]
    with pytest.raises(ValueError):
        metrics_from_evidence(truth, pred, loss, ('a', 'b'))


def test_scoring_rejects_validation_role(evaluation_fixture):
    from support.final_evaluation import score_model
    artifact, data = evaluation_fixture
    with pytest.raises(ValueError, match='test'):
        score_model(artifact, replace(data, manifest=replace(data.manifest, role='validation')), batch_size=2)


def test_summary_requires_three_seeds_and_retains_negative_damage():
    from support.final_analysis import summarize_pairs
    rows = [dict(method='fusion', condition='iid', seed=s, recall_degradation=x) for s, x in zip([42, 43, 44], [-.1, 0, .1])]
    summary = summarize_pairs(rows, methods=['fusion'], conditions=['iid'])
    assert summary[0]['recall_degradation_mean'] == pytest.approx(0)
    assert summary[0]['recall_degradation_sample_std'] == pytest.approx(.1)
    with pytest.raises(ValueError):
        summarize_pairs(rows[:2], methods=['fusion'], conditions=['iid'])


@pytest.fixture
def saved_case(evaluation_fixture, tmp_path):
    from support.final_protocol import fingerprints, write_new
    from support.final_evaluation import score_model, metrics_from_evidence
    from support.data.latest_audit import source_hash
    artifact, data = evaluation_fixture
    directory = tmp_path/'evaluated';directory.mkdir()
    freeze = tmp_path/'freeze.json';freeze.write_text('{}')
    case = dict(name='artificial',run_path=str(artifact.artifact_path.parent))
    # Match the real artifact filename expected by the result verifier.
    (artifact.artifact_path.parent/'model_artifact.pt').write_bytes(artifact.artifact_path.read_bytes())
    truth=data.dataset.tensors[1].numpy();np.save(tmp_path/'test_labels.npy',truth)
    pred,loss=score_model(artifact,data,batch_size=2)
    np.savez_compressed(directory/'predictions.npz',predictions=pred,losses=loss)
    record=dict(case=case,freeze_sha256=source_hash(freeze),model_sha256=source_hash(tmp_path/'model_artifact.pt'),
                evaluation_role='test',test_scored=True,training_performed=False,
                test_rows=5,metrics=metrics_from_evidence(truth,pred,loss,artifact.contract.class_names))
    write_new(directory/'result.json',record)
    write_new(directory/'artifacts.json',fingerprints([directory/'predictions.npz',directory/'result.json']))
    frozen=dict(test_manifest=str(data.manifest.manifest_path),test_rows=5)
    return directory,case,frozen,freeze


def test_offline_verify_requires_no_model_forward(saved_case,monkeypatch):
    from support.final_evaluation import verify_case
    def forbidden(*args,**kwargs):raise AssertionError('Offline verification forwarded a model')
    monkeypatch.setattr(torch.nn.Linear,'forward',forbidden)
    assert verify_case(*saved_case)['metrics']['accuracy']==.8


@pytest.mark.parametrize('corruption',['predictions','metrics','case','freeze','model','inventory'])
def test_saved_case_corruption_stops_verification(saved_case,corruption):
    from support.final_evaluation import verify_case
    from support.final_protocol import fingerprints
    directory,case,frozen,freeze=saved_case
    if corruption=='predictions':
        with np.load(directory/'predictions.npz') as z:loss=z['losses'].copy()
        np.savez_compressed(directory/'predictions.npz',predictions=np.zeros(5,dtype=int),losses=loss)
    if corruption in ['metrics','case']:
        r=json.loads((directory/'result.json').read_text())
        if corruption=='metrics':r['metrics']['accuracy']=.99
        else:r['case']['name']='other'
        (directory/'result.json').write_text(json.dumps(r))
    if corruption in ['metrics','predictions']:
        # Even a refreshed digest cannot hide evidence/metric disagreement.
        (directory/'artifacts.json').write_text(json.dumps(fingerprints([directory/'predictions.npz',directory/'result.json'])))
    if corruption=='freeze':freeze.write_text('{"changed":true}')
    if corruption=='model':(Path(case['run_path'])/'model_artifact.pt').write_bytes(b'changed')
    if corruption=='inventory':(directory/'artifacts.json').write_text('{}')
    with pytest.raises(ValueError):verify_case(directory,case,frozen,freeze)


def test_incomplete_freeze_inventory_rejected(tmp_path,monkeypatch):
    import support.final_protocol as protocol
    from support.final_protocol import expected_cases, load_freeze
    # Inventory completeness must fail even if supplied hashes are valid.
    p=tmp_path/'freeze.json'
    p.write_text(json.dumps(dict(schema_version=1,protocol='cp7_final_comparison_v1',cases=expected_cases(),
        test_rows=724992,batch_size=128,device='cpu',numerical_threads=1,training_performed=False,
        test_scored=False,model_selection='previously_frozen_final_round',source_sha256={},input_sha256={})))
    with pytest.raises(ValueError):load_freeze(p,full=False)


def test_completed_unindexed_attempt_is_recovered_without_forward(saved_case):
    from support.final_evaluation import find_completed_attempt
    directory,case,frozen,freeze=saved_case
    attempt=directory.parent/(case['name']+'_attempt1')
    directory.rename(attempt)
    from support.final_protocol import fingerprints
    (attempt/'artifacts.json').write_text(json.dumps(fingerprints([attempt/'predictions.npz',attempt/'result.json'])))
    assert find_completed_attempt(attempt.parent,case,frozen,freeze)==attempt


def test_corrupt_completed_unindexed_attempt_is_not_silently_retried(saved_case):
    from support.final_evaluation import find_completed_attempt
    directory,case,frozen,freeze=saved_case
    attempt=directory.parent/(case['name']+'_attempt1');directory.rename(attempt)
    with pytest.raises(ValueError):find_completed_attempt(attempt.parent,case,frozen,freeze)


def test_invalid_freeze_writes_failure_before_any_predictions(tmp_path):
    from support.final_evaluation import run_matrix
    freeze=tmp_path/'bad.json';freeze.write_text('{}')
    output=tmp_path/'matrix'
    with pytest.raises(ValueError):run_matrix(freeze,output)
    failures=list(tmp_path.glob('matrix_failure_*.json'))
    assert len(failures)==1 and not output.exists()
    assert json.loads(failures[0].read_text())['error']=='ValueError'
