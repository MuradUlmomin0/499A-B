"""End-to-end diagnostic recovery/validation with synthetic inputs only."""
import hashlib
import importlib
import json
from pathlib import Path
import sys
import zipfile

import pytest
import torch
import yaml

from support.models.stacking import PyTorchStackingClassifier


def api(): return importlib.import_module('support.stacking_runner')


def forbidden(*args,**kwargs): raise AssertionError('Model training is forbidden')


@pytest.fixture
def config(tmp_path,monkeypatch):
    torch.set_num_threads(1)
    model=PyTorchStackingClassifier(2,2).eval()
    with torch.no_grad():
        for p in model.parameters(): p.zero_()
        model.meta_model.output_layer.bias.copy_(torch.tensor([3.,-1.]))
    torch.save(model.state_dict(),tmp_path/'model.pth')
    (tmp_path/'notebook.ipynb').write_text('{}')
    with zipfile.ZipFile(tmp_path/'data.zip','w') as z:
        z.writestr('Dataset/train.csv','x,y,label\n1.0,10.0,a\n2.0,10.0,z\n3.0,10.0,a\n4.0,10.0,z\n')
        z.writestr('Dataset/validation.csv','x,y,label\n3.0,10.0,a\n2.0,10.0,z\n')
        z.writestr('Dataset/test.csv','DO NOT READ')
    digest=lambda name: hashlib.sha256((tmp_path/name).read_bytes()).hexdigest()
    value=dict(schema_version=1,mode='recover',archive_path='data.zip',
               archive_sha256=digest('data.zip'),checkpoint_path='model.pth',
               checkpoint_sha256=digest('model.pth'),notebook_path='notebook.ipynb',
               notebook_sha256=digest('notebook.ipynb'),output_dir='recovered',
               work_dir='scratch',expected_rows=4,chunk_rows=2)
    path=tmp_path/'recover.yaml'; path.write_text(yaml.safe_dump(value))
    monkeypatch.setattr(torch.optim.Optimizer,'__init__',forbidden)
    monkeypatch.setattr(torch.Tensor,'backward',forbidden)
    return path,value


def validation_config(path):
    value=yaml.safe_load(path.read_text())
    v=dict(schema_version=1,mode='validate',archive_path=value['archive_path'],
           archive_sha256=value['archive_sha256'],recovery_dir='recovered',
           output_dir='runs',limit=2,batch_size=1,chunk_rows=1,seed=42)
    p=path.parent/'validate.yaml';p.write_text(yaml.safe_dump(v));return p


def test_complete_recovery_prediction_metrics_and_logging(config):
    path,_=config
    recovered=api().run_stacking(path)
    assert (recovered/'recovery.json').exists()
    output=api().run_stacking(validation_config(path))
    summary=json.loads((output/'run_summary.json').read_text())
    metrics=json.loads((output/'validation_metrics.json').read_text())
    assert summary['status']=='completed' and summary['rows']==2
    assert summary['testing_only'] and summary['historical_preprocessing_verified'] is False
    assert metrics['metrics']['confusion_matrix']==[[1,0],[1,0]]
    assert metrics['metrics']['accuracy']==0.5
    assert metrics['metrics']['per_class'][1]['recall']==0.0
    assert (output/'predictions.csv').read_text().count('\n')==3
    assert (output/'config.yaml').exists() and (output/'metadata.json').exists()
    second=api().run_stacking(validation_config(path))
    assert second!=output
    assert (second/'predictions.csv').read_bytes()==(output/'predictions.csv').read_bytes()


@pytest.mark.parametrize('damage',['extra','bool_chunk','unknown_mode','duplicate'])
def test_invalid_configuration_fails_without_outputs(config,damage):
    p,v=config
    if damage=='extra': v['training']=True
    if damage=='bool_chunk': v['chunk_rows']=True
    if damage=='unknown_mode': v['mode']='train'
    p.write_text(yaml.safe_dump(v))
    if damage=='duplicate': p.write_text(p.read_text()+'mode: recover\n')
    with pytest.raises(ValueError): api().run_stacking(p)
    assert not (p.parent/'recovered').exists()


def test_validation_pins_archive_and_refuses_different_source(config):
    p,_=config;api().run_stacking(p)
    val=validation_config(p);v=yaml.safe_load(val.read_text());v['archive_sha256']='0'*64
    val.write_text(yaml.safe_dump(v))
    with pytest.raises(ValueError,match='SHA'): api().run_stacking(val)
    assert not (p.parent/'runs').exists()


def test_cli_routes_new_mode_without_touching_fedavg(config,monkeypatch,capsys):
    import main
    p,_=config
    monkeypatch.setattr(main,'run_dummy_test',forbidden)
    monkeypatch.setattr(main,'run_federated',forbidden)
    monkeypatch.setattr(sys,'argv',['main.py','--stacking','--config',str(p)])
    main.main()
    assert 'diagnostic' in capsys.readouterr().out.lower()
    assert (p.parent/'recovered/recovery.json').exists()


def test_cli_requires_explicit_config(monkeypatch,capsys):
    import main
    monkeypatch.setattr(sys,'argv',['main.py','--stacking'])
    with pytest.raises(SystemExit) as caught: main.main()
    assert caught.value.code==2
    assert 'requires --config' in capsys.readouterr().err
