import csv
import json
import pytest
import torch
from support.utils.experiment_logger import ExperimentLogger
from support.federated.types import ClientResult


def test_unique_run_and_finalization(tmp_path,config):
    a=ExperimentLogger(tmp_path,'test',config,{'testing_only':True})
    b=ExperimentLogger(tmp_path,'test',config,{'testing_only':True})
    assert a.path!=b.path
    a.log_round({'round_id':1,'selected_clients':['0']},[ClientResult('0',1,2,{}, {},{'train_loss':1.})],{'0':1.})
    a.finish({'accuracy':0.5},{'model_state':{'w':torch.tensor([1.])}})
    final=json.loads((a.path/'final_metrics.json').read_text())
    assert final['testing_only'] is True
    assert len(list(csv.DictReader((a.path/'aggregation_weights.csv').open())))==1
    saved=torch.load(a.path/'checkpoint.pt',weights_only=True)
    assert saved['testing_only'] is True
    assert saved['model_state']['w'].item()==1
    with pytest.raises(ValueError):
        a.finish({}, {})


def test_validation_logging_labels_outputs_without_mutating_inputs(tmp_path, config):
    metadata = {'testing_only': True, 'purpose': 'synthetic C verification'}
    logger = ExperimentLogger(tmp_path, 'prepared_fl', config, metadata, evaluation_role='validation')
    record = {'round_id': 1, 'selected_clients': ['a'], 'accuracy': 0.5}
    logger.log_round(record, [ClientResult('a', 1, 2, {}, {}, {'train_loss': 1.})], {'a': 1.})
    logger.finish({'accuracy': 0.5}, {'model_state': {'w': torch.tensor([1.])}})
    assert 'evaluation_role' not in record and 'evaluation_role' not in metadata
    assert not (logger.path / 'final_metrics.json').exists()
    assert json.loads((logger.path / 'validation_metrics.json').read_text())['evaluation_role'] == 'validation'
    with (logger.path / 'round_metrics.csv').open() as stream:
        assert list(csv.DictReader(stream))[0]['evaluation_role'] == 'validation'
    saved = torch.load(logger.path / 'checkpoint.pt', weights_only=True)
    assert saved['testing_only'] is True and saved['evaluation_role'] == 'validation'


@pytest.mark.parametrize('role,metadata', [
    ('test', {'testing_only': True}), ('validation', {}),
    ('validation', {'testing_only': 'false'}),
    ('validation', {'testing_only': True, 'evaluation_role': 'test'}),
    ('validation', {'testing_only': True, 'bad': float('nan')}),
])
def test_bad_fl_log_metadata_precedes_writes(tmp_path, config, role, metadata):
    destination = tmp_path / 'absent'
    with pytest.raises(ValueError):
        ExperimentLogger(destination, 'x', config, metadata, evaluation_role=role)
    assert not destination.exists()


def test_round_role_conflict_is_not_appended(tmp_path, config):
    logger = ExperimentLogger(tmp_path, 'x', config, {'testing_only': True}, evaluation_role='validation')
    path = logger.path / 'round_metrics.csv'
    before = path.read_bytes()
    with pytest.raises(ValueError, match='role'):
        logger.log_round({'round_id': 1, 'evaluation_role': 'test'}, [], {})
    assert path.read_bytes() == before
