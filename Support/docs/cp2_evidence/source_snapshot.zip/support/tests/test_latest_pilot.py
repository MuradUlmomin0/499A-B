"""Prepared real-pilot format and actual small FedAvg training integration."""
import importlib
import json
import hashlib
from pathlib import Path
import numpy as np
import pytest
import torch
import yaml
from support.data.federated_bundle import load_federated_bundle
from support.data.latest_audit import input_digest
from support.models.artifact import load_model_artifact
from support.federated_runner import run_federated


def api():return importlib.import_module('support.data.latest_pilot')


def sample_inputs():
    x=np.array([[float(i),10.] for i in range(32)],dtype=np.float32)
    y=np.arange(32,dtype=np.int64)%2
    train={'features':x,'labels':y,'ordinals':np.arange(32),'hashes':[input_digest(r) for r in x]}
    v=np.array([[100.,10.],[102.,10.],[104.,10.],[106.,10.]],dtype=np.float32)
    val={'features':v,'labels':np.array([0,1,0,1]),'ordinals':np.arange(4),'hashes':[input_digest(r) for r in v]}
    c={'feature_names':['f0','f1'],'class_names':['a','b'],'archive_sha256':'a'*64,
       'seed':42,'num_clients':2,'hidden_dims':[4]}
    return {'train':train,'validation':val},c


def test_train_only_scaling_roles_groups_and_existing_loaders(tmp_path):
    s,c=sample_inputs();report=api().export_latest_pilot(s,c,tmp_path)
    b=load_federated_bundle(tmp_path/'federated_bundle.json')
    assert b.contract.input_dim==2 and b.contract.num_classes==2 and len(b.clients)==2
    pp=json.loads((tmp_path/'preprocessing.json').read_text())
    assert pp['mean']==[15.5,10.]
    np.testing.assert_allclose(pp['scale'],[np.sqrt(85.25),1.])
    assert report['train_rows']==32 and report['validation_rows']==4
    assert report['test_scored'] is False and b.testing_only
    assert report['checked_roles']==['train','validation']
    assert report['prepared_train_validation_groups_disjoint'] is True
    np.testing.assert_allclose(b.validation.data.dataset.tensors[0][:,0],
                               (s['validation']['features'][:,0]-15.5)/np.sqrt(85.25),rtol=1e-6)
    namespaces={p.evidence.source_namespace for p in b.clients}
    assert namespaces=={'latest:sha256:'+'a'*64}
    assert sum(len(p.evidence.record_ids) for p in b.clients)==32
    assert all('Dataset/train.csv:row:' in rid for p in b.clients for rid in p.evidence.record_ids)


def test_duplicate_training_groups_stay_in_one_client(tmp_path):
    s,c=sample_inputs()
    s['train']['features'][1]=s['train']['features'][0]
    s['train']['hashes'][1]=s['train']['hashes'][0]
    api().export_latest_pilot(s,c,tmp_path)
    b=load_federated_bundle(tmp_path/'federated_bundle.json')
    ids=[set(p.evidence.record_ids) for p in b.clients]
    assert any({'Dataset/train.csv:row:0','Dataset/train.csv:row:1'}<=v for v in ids)


def test_final_input_overlap_is_excluded_and_counted(tmp_path):
    s,c=sample_inputs()
    s['validation']['features'][0]=s['train']['features'][0]
    s['validation']['features'][0,0]=np.nextafter(np.float32(0),np.float32(1))
    assert input_digest(s['validation']['features'][0])!=input_digest(s['train']['features'][0])
    report=api().export_latest_pilot(s,c,tmp_path)
    assert report['validation_rows']==3
    assert report['validation_final_input_overlap_rows_removed']==1
    b=load_federated_bundle(tmp_path/'federated_bundle.json')
    assert len(b.validation.data.dataset)==3
    assert b.validation.evidence.record_ids==tuple(f'Dataset/validation.csv:row:{i}' for i in [1,2,3])


def test_real_optimization_final_artifact_and_reload(tmp_path):
    torch.set_num_threads(1)
    s,c=sample_inputs();api().export_latest_pilot(s,c,tmp_path)
    config={'schema_version':1,'experiment':{'name':'latest_fixture','seed':42,'device':'cpu',
            'deterministic':True,'output_dir':str(tmp_path/'runs')},
            'dataset':{'bundle_path':str(tmp_path/'federated_bundle.json')},
            'initialization':{'mode':'random','artifact_path':None},
            'federated':{'aggregation':'fedavg','rounds':2,'participation_rate':1.},
            'training':{'optimizer':'adam','learning_rate':.01,'local_epochs':1,'batch_size':8},
            'selection':{'policy':'final_round'}}
    path=tmp_path/'train.yaml';path.write_text(yaml.safe_dump(config))
    out=run_federated(path)
    r=json.loads((out/'run_summary.json').read_text())
    assert r['training_completed'] and r['selected_round']==2
    art=load_model_artifact(out/'model_artifact.pt')
    assert art.training_completed and art.testing_only
    assert art.contract.class_names==('a','b')
    from support.models.factory import create_model
    from support.utils.reproducibility import seed_everything
    seed_everything(42,True)
    initial=create_model(art.contract.model_config()).state_dict()
    assert any(not torch.equal(initial[k],v) for k,v in art.model.state_dict().items())
    metrics=json.loads((out/'validation_metrics.json').read_text())['metrics']
    assert np.isfinite(metrics['loss']) and len(metrics['per_class'])==2


def runner_inputs(tmp_path):
    import zipfile
    archive=tmp_path/'source.zip'
    with zipfile.ZipFile(archive,'w') as z:
        for role,n,start in [('train',32,0),('validation',4,100),('test',4,200)]:
            z.writestr(f'Dataset/{role}.csv','f0,f1,label\n'+''.join(
                f'{start+i}.0,10.0,{"a" if i%2==0 else "b"}\n' for i in range(n)))
    c={'schema_version':1,'archive_path':str(archive),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
       'feature_names':['f0','f1'],'class_names':['a','b'],'expected_rows':{'train':32,'validation':4,'test':4},
       'seed':42,'chunk_rows':3,'train_per_class':16,'validation_per_class':4,'num_clients':2,
       'hidden_dims':[4],'output_dir':str(tmp_path/'prepared'),'work_dir':str(tmp_path/'work')}
    p=tmp_path/'prepare.yaml';p.write_text(yaml.safe_dump(c));return p,c


def test_audit_only_then_finish_and_overwrite_rejection(tmp_path):
    runner=importlib.import_module('support.latest_pilot_runner')
    p,c=runner_inputs(tmp_path)
    out=runner.prepare_latest(p,audit_only=True)
    assert (out/'split_audit.json').exists() and not (out/'run_summary.json').exists()
    assert not (out/'federated_bundle.json').exists()
    out2=runner.prepare_latest(p)
    assert out2==out and json.loads((out/'run_summary.json').read_text())['training_performed'] is False
    assert len(load_federated_bundle(out/'federated_bundle.json').clients)==2
    with pytest.raises(FileExistsError):runner.prepare_latest(p)


@pytest.mark.parametrize('bad',['duplicate','unsafe_chunk','same_output_work','bad_hash'])
def test_invalid_runner_configuration_and_source_do_not_publish(tmp_path,bad):
    runner=importlib.import_module('support.latest_pilot_runner')
    p,c=runner_inputs(tmp_path)
    if bad=='unsafe_chunk':c['chunk_rows']=True
    if bad=='same_output_work':c['work_dir']=c['output_dir']
    if bad=='bad_hash':c['archive_sha256']='0'*64
    p.write_text(yaml.safe_dump(c))
    if bad=='duplicate':p.write_text(p.read_text()+'seed: 7\n')
    with pytest.raises(ValueError):runner.prepare_latest(p)
    assert not (Path(c['output_dir'])/'run_summary.json').exists()


def test_audit_candidate_tampering_fails_before_export(tmp_path):
    runner=importlib.import_module('support.latest_pilot_runner')
    p,c=runner_inputs(tmp_path);out=runner.prepare_latest(p,audit_only=True)
    with (out/'candidates.npz').open('ab') as stream:stream.write(b'changed')
    with pytest.raises(ValueError,match='candidate'):runner.prepare_latest(p)
    assert not (out/'federated_bundle.json').exists()


def test_empty_validation_after_final_input_exclusion_fails(tmp_path):
    s,c=sample_inputs()
    s['validation']['features']=s['train']['features'][:4].copy()
    with pytest.raises(ValueError,match='No eligible validation'):
        api().export_latest_pilot(s,c,tmp_path)
    assert not (tmp_path/'federated_bundle.json').exists()
