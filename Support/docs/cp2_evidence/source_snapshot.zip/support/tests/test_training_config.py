"""Temporary YAML only; no model/dataset loading or optimizer execution."""
from copy import deepcopy
import yaml
import pytest

from support.utils.training_config import load_training_config, validate_training_config


@pytest.fixture
def settings():
    return {
        'schema_version': 1,
        'experiment': {'name': 'test', 'seed': 42, 'device': 'cpu', 'deterministic': True, 'output_dir': 'runs'},
        'dataset': {'bundle_path': 'bundle.json'},
        'initialization': {'mode': 'random', 'artifact_path': None},
        'federated': {'aggregation': 'fedavg', 'rounds': 2, 'participation_rate': 1.0},
        'training': {'optimizer': 'sgd', 'learning_rate': 0.01, 'local_epochs': 1, 'batch_size': 2},
        'selection': {'policy': 'final_round'},
    }


def test_paths_copy_and_no_artifact_io(settings, tmp_path, monkeypatch):
    source = tmp_path / 'settings.yaml'
    source.write_text(yaml.safe_dump(settings))
    config = load_training_config(source)
    assert config['dataset']['bundle_path'] == str(tmp_path / 'bundle.json')
    assert config['experiment']['output_dir'] == str(tmp_path / 'runs')
    assert config['initialization']['artifact_path'] is None
    assert not (tmp_path / 'runs').exists()
    copy = validate_training_config(settings)
    copy['experiment']['seed'] = 123
    assert settings['experiment']['seed'] == 42
    monkeypatch.chdir('/')
    assert load_training_config(source) == config


def test_warm_start_paths(settings, tmp_path):
    settings['initialization'] = {'mode': 'artifact', 'artifact_path': '../model.pt'}
    source = tmp_path / 'c.yaml'
    source.write_text(yaml.safe_dump(settings))
    assert load_training_config(source)['initialization']['artifact_path'] == str((tmp_path / '../model.pt').resolve())


@pytest.mark.parametrize('section,field,value', [
    ('experiment', 'name', '../x'), ('experiment', 'seed', True), ('experiment', 'seed', 2**32),
    ('experiment', 'device', 'automatic'), ('experiment', 'deterministic', 1),
    ('experiment', 'output_dir', ''), ('dataset', 'bundle_path', ' bad '),
    ('initialization', 'mode', 'guess'), ('initialization', 'artifact_path', 'x.pt'),
    ('federated', 'aggregation', 'fedmade'), ('federated', 'rounds', 0),
    ('federated', 'participation_rate', 1.1), ('federated', 'participation_rate', float('nan')),
    ('training', 'optimizer', 'other'), ('training', 'learning_rate', float('inf')),
    ('training', 'local_epochs', True), ('training', 'batch_size', -1),
    ('selection', 'policy', 'best_validation'),
])
def test_invalid_values(settings, section, field, value):
    settings[section][field] = value
    with pytest.raises(ValueError):
        validate_training_config(settings)


@pytest.mark.parametrize('key', ['experiment', 'dataset', 'initialization', 'federated', 'training', 'selection'])
def test_missing_and_extra_sections(settings, key):
    missing = deepcopy(settings)
    del missing[key]
    with pytest.raises(ValueError): validate_training_config(missing)
    settings[key]['unknown'] = 1
    with pytest.raises(ValueError): validate_training_config(settings)


def test_schema_and_warm_start_requirements(settings):
    settings['schema_version'] = True
    with pytest.raises(ValueError): validate_training_config(settings)
    settings['schema_version'] = 1
    settings['initialization'] = {'mode': 'artifact', 'artifact_path': None}
    with pytest.raises(ValueError): validate_training_config(settings)
    settings['test_manifest'] = 'must-not-be-in-training'
    with pytest.raises(ValueError): validate_training_config(settings)


@pytest.mark.parametrize('text', ['', '[]', 'schema_version: 1\nschema_version: 1', 'x: !!python/object:builtins.object {}',
                                  'schema_version: 1\n---\nschema_version: 1', 'x: ['])
def test_invalid_yaml_is_rejected(tmp_path, text):
    path = tmp_path / 'bad.yaml'
    path.write_text(text)
    with pytest.raises(ValueError): load_training_config(path)


def test_missing_file(tmp_path):
    with pytest.raises(FileNotFoundError): load_training_config(tmp_path / 'absent.yaml')
