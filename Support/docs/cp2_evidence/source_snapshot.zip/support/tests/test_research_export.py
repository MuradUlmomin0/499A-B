"""Artificial prepared arrays exercise CP1 contracts and final-input isolation."""
import importlib,json
from pathlib import Path
import numpy as np
import pytest
from support.data.latest_audit import source_hash
from support.data.federated_bundle import load_federated_bundle


def fixture(tmp_path):
    raw=tmp_path/'raw';raw.mkdir()
    values={'train':([0,0,2,4],[0,0,1,1]),'auxiliary':([1,3],[0,1]),
            'validation':([0,5,6],[0,0,1]),'test':([5,7,8],[0,0,1])}
    for role,(x,y) in values.items():
        for key,v in [('features',np.array(x,dtype=np.float32).reshape(-1,1)),('labels',np.array(y,dtype=np.int64)),('ordinals',np.arange(len(x),dtype=np.int64)+(10 if role=='auxiliary' else 0))]:np.save(raw/f'{role}_{key}.npy',v)
    selection={'archive_sha256':'1'*64,'testing_only':True,
               'files':{p.name:source_hash(p) for p in raw.glob('*.npy')}}
    (raw/'selection.json').write_text(json.dumps(selection))
    c={'feature_names':['f'],'class_names':['a','b'],'hidden_dims':[4]}
    s={'clients':1,'partition_and_training_seeds':[42],'dirichlet_alpha':.5,'auxiliary_groups_per_class':1}
    return raw,c,s


def test_scaler_fit_train_only_final_exclusions_and_bundle_compatible(tmp_path):
    raw,c,s=fixture(tmp_path);out=tmp_path/'out'
    r=importlib.import_module('support.data.research_export').export_research(raw,c,s,out)
    assert r['roles']['validation']['rows']==2 and r['roles']['test']['rows']==2
    assert r['roles']['validation']['final_input_exclusions']==1
    assert r['roles']['test']['final_input_exclusions']==1
    prep=json.loads((out/'preprocessing.json').read_text());assert prep['mean']==[1.5]
    bundle=load_federated_bundle(out/'iid_seed42/federated_bundle.json')
    assert len(bundle.clients)==1 and bundle.testing_only
    assert len(bundle.validation.data.dataset)==2
    assert (out/'test.manifest.json').exists() and (out/'auxiliary.manifest.json').exists()
    for path in out.glob('*_seed42/federated_bundle.json'):
        assert 'test' not in json.loads(path.read_text())
    with pytest.raises(FileExistsError):importlib.import_module('support.data.research_export').export_research(raw,c,s,out)


def test_input_tampering_stops_before_complete_report(tmp_path):
    raw,c,s=fixture(tmp_path);np.save(raw/'train_labels.npy',np.zeros(4,dtype=int))
    with pytest.raises(ValueError,match='hash'):
        importlib.import_module('support.data.research_export').export_research(raw,c,s,tmp_path/'out')


def test_mixed_transformed_labels_stop(tmp_path):
    raw,c,s=fixture(tmp_path);x=np.load(raw/'train_features.npy');x[-1]=0;np.save(raw/'train_features.npy',x)
    selection=json.loads((raw/'selection.json').read_text());selection['files']['train_features.npy']=source_hash(raw/'train_features.npy');(raw/'selection.json').write_text(json.dumps(selection))
    with pytest.raises(ValueError,match='label'):
        importlib.import_module('support.data.research_export').export_research(raw,c,s,tmp_path/'out')


def test_wrong_source_archive_binding_stops(tmp_path):
    raw,c,s=fixture(tmp_path);c['archive_sha256']='2'*64
    with pytest.raises(ValueError,match='archive'):
        importlib.import_module('support.data.research_export').export_research(raw,c,s,tmp_path/'out')


def test_auxiliary_collision_excluded_without_refill_if_classes_remain(tmp_path):
    raw,c,s=fixture(tmp_path);s['auxiliary_groups_per_class']=2
    for key,v in [('features',np.array([0,1,3,9],dtype=np.float32).reshape(-1,1)),('labels',np.array([0,0,1,1],dtype=np.int64)),('ordinals',np.arange(10,14,dtype=np.int64))]:np.save(raw/f'auxiliary_{key}.npy',v)
    selection=json.loads((raw/'selection.json').read_text());selection['files']={p.name:source_hash(p) for p in raw.glob('*.npy')};(raw/'selection.json').write_text(json.dumps(selection))
    r=importlib.import_module('support.data.research_export').export_research(raw,c,s,tmp_path/'out')
    assert r['roles']['auxiliary']['rows']==3
    assert r['roles']['auxiliary']['class_counts']==[1,2]
    assert r['roles']['auxiliary']['final_input_exclusions']==1
