"""Real orchestration/aggregation with controlled artificial updates, no training.

Optimizer construction and backward() are forbidden. Any training_completed flag
in these exported fixtures describes a simulated completed protocol, not an
actually fitted model or research result. Synthetic purpose status is retained.
"""
import csv
import json
import os
import random

import numpy as np
import pytest
import torch
import yaml

import support.federated_runner as runner
from support.federated.client import FederatedClient
from support.federated.types import ClientResult
from support.models.artifact import load_model_artifact, save_model_artifact
from support.models.factory import create_model
from support.utils.parameters import clone_state, extract_update


def rewrite(path, change):
    value = yaml.safe_load(path.read_text())
    change(value)
    path.write_text(yaml.safe_dump(value))


@pytest.fixture(autouse=True)
def controlled_updates(monkeypatch):
    python_state, numpy_state = random.getstate(), np.random.get_state()
    torch_state = torch.get_rng_state().clone()
    det, warn = torch.are_deterministic_algorithms_enabled(), torch.is_deterministic_algorithms_warn_only_enabled()
    cudnn = torch.backends.cudnn.deterministic, torch.backends.cudnn.benchmark
    workspace = os.environ.get('CUBLAS_WORKSPACE_CONFIG')
    monkeypatch.setattr(torch.cuda, 'is_available', lambda: False)
    monkeypatch.setattr(torch.cuda, 'manual_seed_all', lambda seed: None)
    def forbidden(*args, **kwargs):
        raise AssertionError('Optimizer/backpropagation forbidden in infrastructure verification')
    monkeypatch.setattr(torch.optim.Optimizer, '__init__', forbidden)
    monkeypatch.setattr(torch.Tensor, 'backward', forbidden)
    calls = []
    def update(self, round_id):
        assert self.global_state is not None
        before = clone_state(self.model.state_dict())
        calls.append({'id': self.client_id, 'round': round_id, 'before': before, 'count': len(self.train_dataset)})
        with torch.no_grad():
            for parameter in self.model.parameters():
                parameter.add_(1 if self.client_id == 'a' else 3)
        state = clone_state(self.model.state_dict())
        return ClientResult(self.client_id, round_id, len(self.train_dataset), state,
                            extract_update(state, self.global_state), {'train_loss': 1.0})
    monkeypatch.setattr(FederatedClient, 'train', update)
    try:
        yield calls
    finally:
        random.setstate(python_state)
        np.random.set_state(numpy_state)
        torch.set_rng_state(torch_state)
        torch.use_deterministic_algorithms(det, warn_only=warn)
        torch.backends.cudnn.deterministic, torch.backends.cudnn.benchmark = cudnn
        if workspace is None: os.environ.pop('CUBLAS_WORKSPACE_CONFIG', None)
        else: os.environ['CUBLAS_WORKSPACE_CONFIG'] = workspace


def test_complete_rounds_weighted_updates_export_and_sources(federated_config, controlled_updates):
    path, inputs = federated_config()
    source_bytes = {p: p.read_bytes() for p in inputs['bundle'].parent.iterdir()}
    directory = runner.run_federated(path)
    assert {p.name for p in directory.iterdir()} == {
        'config.yaml', 'metadata.json', 'round_metrics.csv', 'client_metrics.csv',
        'aggregation_weights.csv', 'validation_metrics.json', 'checkpoint.pt',
        'model_artifact.pt', 'run_summary.json',
    }
    assert len(controlled_updates) == 4
    first = controlled_updates[0]['before']
    for name in first:
        assert torch.equal(controlled_updates[1]['before'][name], first[name])
        assert torch.allclose(controlled_updates[2]['before'][name], first[name] + 2.5)
    artifact = load_model_artifact(directory / 'model_artifact.pt')
    assert artifact.testing_only is True and artifact.training_completed is True
    for name, value in first.items():
        assert torch.allclose(artifact.model.state_dict()[name], value + 5)
    with (directory / 'aggregation_weights.csv').open() as stream:
        rows = list(csv.DictReader(stream))
    assert len(rows) == 4
    for row in rows:
        assert float(row['weight']) == (0.25 if row['client_id'] == 'a' else 0.75)
    with (directory / 'round_metrics.csv').open() as stream:
        assert all(row['evaluation_role'] == 'validation' for row in csv.DictReader(stream))
    metadata = json.loads((directory / 'metadata.json').read_text())
    assert metadata['initialization']['model_state_sha256'] == runner._state_sha256(first)
    assert metadata['federated_inputs']['split_checks']['provenance_verified'] is False
    assert metadata['testing_only'] is True and metadata['selection_policy'] == 'final_round'
    summary = json.loads((directory / 'run_summary.json').read_text())
    assert summary['selected_round'] == 2 and summary['evaluation_role'] == 'validation'
    assert summary['model_artifact_sha256'] == artifact.artifact_sha256
    assert summary['resume_supported'] is False
    assert all(p.read_bytes() == content for p, content in source_bytes.items())


def test_warm_start_and_source_purpose_combination(federated_config, tmp_path):
    path, inputs = federated_config(testing_only=False)
    model = create_model(inputs['contract'].model_config())
    with torch.no_grad():
        for parameter in model.parameters(): parameter.zero_()
    warm_path = save_model_artifact(model, tmp_path / 'warm.pt', contract=inputs['contract'],
                                    model_name='artificial', training_completed=False, testing_only=True)
    rewrite(path, lambda d: d['initialization'].update(mode='artifact', artifact_path=str(warm_path)))
    directory = runner.run_federated(path)
    artifact = load_model_artifact(directory / 'model_artifact.pt')
    assert artifact.testing_only is True
    assert all(torch.allclose(p, torch.full_like(p, 5)) for p in artifact.model.parameters())
    metadata = json.loads((directory / 'metadata.json').read_text())
    assert metadata['initialization']['artifact_sha256'] == load_model_artifact(warm_path).artifact_sha256


def test_repeated_runs_and_final_test_label_independence(federated_config, tmp_path, monkeypatch):
    path, _ = federated_config()
    final_test = tmp_path / 'external_final_test.npz'
    final_test.write_bytes(b'original held-out labels')
    original = np.load
    def guarded(file, *args, **kwargs):
        assert str(file) != str(final_test), 'Final test file must never be opened by training'
        return original(file, *args, **kwargs)
    monkeypatch.setattr(np, 'load', guarded)
    first = runner.run_federated(path)
    final_test.write_bytes(b'completely changed held-out labels')
    second = runner.run_federated(path)
    assert first != second
    a, b = (load_model_artifact(d / 'model_artifact.pt') for d in (first, second))
    assert all(torch.equal(v, b.model.state_dict()[k]) for k, v in a.model.state_dict().items())
    assert json.loads((first / 'validation_metrics.json').read_text()) == json.loads((second / 'validation_metrics.json').read_text())


def test_final_round_export_does_not_select_best_validation(federated_config, controlled_updates, monkeypatch):
    import support.federated.server as server_module
    path, _ = federated_config()
    scores = iter([1.0, 0.0])
    monkeypatch.setattr(server_module, 'evaluate_model', lambda *args: {'accuracy': next(scores)})
    directory = runner.run_federated(path)
    artifact = load_model_artifact(directory / 'model_artifact.pt')
    first = controlled_updates[0]['before']
    assert all(torch.allclose(value, first[name] + 5) for name, value in artifact.model.state_dict().items())
    assert json.loads((directory / 'validation_metrics.json').read_text())['metrics']['accuracy'] == 0.0


def test_configurable_dimensions_and_partial_participation(federated_config):
    path, _ = federated_config(input_dim=4, num_classes=3)
    rewrite(path, lambda d: d['federated'].update(participation_rate=0.5))
    directory = runner.run_federated(path)
    model = load_model_artifact(directory / 'model_artifact.pt')
    assert model.contract.input_dim == 4 and model.contract.num_classes == 3
    with (directory / 'aggregation_weights.csv').open() as stream:
        rows = list(csv.DictReader(stream))
    assert len(rows) == 2 and all(float(row['weight']) == 1 for row in rows)


@pytest.mark.parametrize('problem', ['cuda', 'config', 'role', 'overlap', 'fingerprint', 'warm_contract'])
def test_invalid_inputs_precede_seeding_and_output(federated_config, tmp_path, monkeypatch, problem):
    from support.data.contract import ModelDataContract
    path, inputs = federated_config()
    if problem == 'cuda': rewrite(path, lambda d: d['experiment'].update(device='cuda'))
    elif problem == 'config': rewrite(path, lambda d: d.update(test_manifest='forbidden'))
    elif problem == 'warm_contract':
        contract = ModelDataContract('mlp', 3, 2, (2,), ('a', 'b', 'c'), ('c0', 'c1'), None)
        warm = save_model_artifact(create_model(contract.model_config()), tmp_path / 'wrong.pt',
                                   contract=contract, model_name='test', training_completed=False, testing_only=True)
        rewrite(path, lambda d: d['initialization'].update(mode='artifact', artifact_path=str(warm)))
    else:
        part = inputs['partitions']['validation']
        target = part['manifest'] if problem == 'role' else part['evidence']
        value = json.loads(target.read_text())
        if problem == 'role': value['role'] = 'test'
        elif problem == 'overlap': value['record_ids'][0] = 'a-0'
        else: value['data_sha256'] = '0' * 64
        target.write_text(json.dumps(value))
    def forbidden(*args, **kwargs): raise AssertionError('Invalid inputs must not seed execution')
    monkeypatch.setattr(runner, 'seed_everything', forbidden)
    with pytest.raises(ValueError): runner.run_federated(path)
    assert not (tmp_path / 'training_runs').exists()


@pytest.mark.parametrize('stage', ['client', 'export'])
def test_failures_leave_no_completed_summary(federated_config, tmp_path, monkeypatch, stage):
    path, _ = federated_config()
    def fail(*args, **kwargs): raise RuntimeError('simulated failure')
    if stage == 'client': monkeypatch.setattr(FederatedClient, 'train', fail)
    else: monkeypatch.setattr(runner, 'save_model_artifact', fail)
    with pytest.raises(RuntimeError, match='simulated'): runner.run_federated(path)
    assert not list((tmp_path / 'training_runs').glob('*/run_summary.json'))


def test_export_works_with_prepared_prediction_and_evaluation(federated_config, tmp_path):
    from support.prepared_runner import run_prepared
    path, inputs = federated_config()
    trained = runner.run_federated(path)
    for mode in ('predict', 'evaluate'):
        config = {
            'schema_version': 1, 'mode': mode,
            'experiment': {'name': mode, 'seed': 42, 'device': 'cpu', 'deterministic': True, 'output_dir': 'inference_runs'},
            'model': {'artifact_path': str(trained / 'model_artifact.pt')},
            'dataset': {'manifest_path': str(inputs['partitions']['validation']['manifest']), 'expected_role': 'validation'},
            'inference': {'batch_size': 2},
        }
        config_path = tmp_path / f'{mode}.yaml'
        config_path.write_text(yaml.safe_dump(config))
        directory = run_prepared(config_path)
        assert json.loads((directory / 'run_summary.json').read_text())['testing_only'] is True
