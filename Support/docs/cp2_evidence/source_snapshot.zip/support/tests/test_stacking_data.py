"""Recovery must match an independent full-fit reference, never heldout data."""
import hashlib
import importlib
import json
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
import torch
from support.models.stacking import PyTorchStackingClassifier
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import LabelEncoder, StandardScaler


def api(): return importlib.import_module('support.data.stacking')


def inputs(tmp_path, bad=None):
    train = pd.DataFrame({'x':[1., 2., np.nan, 4., 8., 10.],
                          'constant':[10.,10.,10.,10.,10.,10.],
                          'label':['z','a','z','a','z','a']})
    if bad == 'all_missing': train['x'] = np.nan
    if bad == 'infinite': train.loc[0,'x'] = np.inf
    archive=tmp_path/'data.zip'
    with zipfile.ZipFile(archive,'w') as z:
        z.writestr('Dataset/train.csv',train.to_csv(index=False))
        z.writestr('Dataset/validation.csv','x,constant,label\n1000.0,10.0,a\n,10.0,z\n')
        # Sentinel: reading/fitting this during recovery would fail.
        z.writestr('Dataset/test.csv','DO NOT READ THIS MEMBER')
    checkpoint=tmp_path/'input.pth'
    torch.save(PyTorchStackingClassifier(2,2).state_dict(),checkpoint)
    notebook=tmp_path/'input.ipynb'; notebook.write_text('{}')
    digest=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    kw=dict(archive=archive,output=tmp_path/'recovered',work_dir=tmp_path/'scratch',
            expected_rows=6,chunk_rows=2,archive_sha256=digest(archive),
            checkpoint_path=checkpoint,checkpoint_sha256=digest(checkpoint),
            notebook_path=notebook,notebook_sha256=digest(notebook))
    return train,kw


def test_training_only_recovery_matches_full_fit_and_transform(tmp_path):
    train,kw=inputs(tmp_path)
    path=api().recover_preprocessing(**kw)
    r=api().load_recovery(path)
    x=train[['x','constant']].to_numpy(dtype=np.float32)
    imp=SimpleImputer(strategy='median'); clean=imp.fit_transform(x)
    scaler=StandardScaler().fit(clean)
    np.testing.assert_array_equal(r['medians'],imp.statistics_)
    np.testing.assert_allclose(r['mean'],scaler.mean_,rtol=1e-13,atol=1e-13)
    np.testing.assert_allclose(r['var'],scaler.var_,rtol=1e-13,atol=1e-13)
    assert r['class_names'] == ['a','z']
    assert r['training_rows']==6 and r['scale'][1]==1.
    assert r['testing_only'] and r['status']=='reconstructed_unverified'
    pairs=list(api().iter_stacking_data(kw['archive'],r,chunk_rows=1,limit=2))
    assert all(x.flags.writeable and y.flags.writeable for x,y in pairs)
    actual=np.concatenate([p[0] for p in pairs])
    expected=scaler.transform(imp.transform(np.array([[1000.,10.],[np.nan,10.]],dtype=np.float32)))
    np.testing.assert_array_equal(actual,expected)
    assert np.concatenate([p[1] for p in pairs]).tolist()==[0,1]
    assert not list(kw['work_dir'].iterdir())


@pytest.mark.parametrize('bad', ['all_missing','infinite'])
def test_invalid_training_values_fail_without_complete_artifact(tmp_path,bad):
    _,kw=inputs(tmp_path,bad)
    with pytest.raises(ValueError): api().recover_preprocessing(**kw)
    assert not (kw['output']/'recovery.json').exists()
    assert not list(kw['work_dir'].iterdir())


def test_wrong_hash_rejected_before_output_creation(tmp_path):
    _,kw=inputs(tmp_path); kw['archive_sha256']='0'*64
    with pytest.raises(ValueError,match='SHA'): api().recover_preprocessing(**kw)
    assert not kw['output'].exists()


def test_wrong_row_count_and_existing_output_are_not_silently_accepted(tmp_path):
    _,kw=inputs(tmp_path); kw['expected_rows']=7
    with pytest.raises(ValueError,match='row count'): api().recover_preprocessing(**kw)
    assert not (kw['output']/'recovery.json').exists()
    sentinel=kw['output']/'mine.txt'; sentinel.write_text('keep')
    with pytest.raises(FileExistsError): api().recover_preprocessing(**kw)
    assert sentinel.read_text()=='keep'


def test_tampered_metadata_rejected(tmp_path):
    _,kw=inputs(tmp_path); path=api().recover_preprocessing(**kw)
    p=path/'recovery.json'; d=json.loads(p.read_text()); d['scale'][0]=0
    p.write_text(json.dumps(d))
    with pytest.raises(ValueError): api().load_recovery(path)


@pytest.mark.parametrize('change',['order','unknown_label'])
def test_validation_schema_and_label_drift_fail(tmp_path,change):
    _,kw=inputs(tmp_path); path=api().recover_preprocessing(**kw)
    r=api().load_recovery(path)
    changed=tmp_path/'changed.zip'
    value='constant,x,label\n10.0,1.0,a\n' if change=='order' else 'x,constant,label\n1.0,10.0,UNKNOWN\n'
    with zipfile.ZipFile(changed,'w') as z: z.writestr('Dataset/validation.csv',value)
    with pytest.raises(ValueError): list(api().iter_stacking_data(changed,r))


def test_test_partition_is_unavailable_to_diagnostic_inference(tmp_path):
    _,kw=inputs(tmp_path); r=api().load_recovery(api().recover_preprocessing(**kw))
    with pytest.raises(ValueError,match='validation'):
        list(api().iter_stacking_data(kw['archive'],r,member='Dataset/test.csv'))


def test_incompatible_weights_do_not_publish_recovery(tmp_path):
    _,kw=inputs(tmp_path)
    torch.save(PyTorchStackingClassifier(3,2).state_dict(),kw['checkpoint_path'])
    kw['checkpoint_sha256']=hashlib.sha256(kw['checkpoint_path'].read_bytes()).hexdigest()
    with pytest.raises(ValueError,match='tensor'):
        api().recover_preprocessing(**kw)
    assert not (kw['output']/'recovery.json').exists()
    assert not (kw['output']/'recovery.sha256').exists()
    assert (kw['output']/'failure.json').exists()


@pytest.mark.parametrize('kind', ['float_even','mixed','integer'])
def test_notebook_dtype_promotion_and_even_median(tmp_path,kind):
    _,kw=inputs(tmp_path)
    x=[1,2,4,8,16,32]
    other=[2,3,7,11,13,17]
    train=pd.DataFrame({'x':x,'constant':other,'label':['z','a','z','a','z','a']})
    if kind in ('float_even','mixed'):
        train['constant']=train['constant'].astype(float)+.25
    if kind=='float_even': train['x']=train['x'].astype(float)
    with zipfile.ZipFile(kw['archive'],'w') as z:
        z.writestr('Dataset/train.csv',train.to_csv(index=False))
        z.writestr('Dataset/validation.csv',train.iloc[:2].to_csv(index=False))
    kw['archive_sha256']=hashlib.sha256(kw['archive'].read_bytes()).hexdigest()
    r=api().load_recovery(api().recover_preprocessing(**kw))
    typed=train[['x','constant']].astype({'x':'float32' if kind=='float_even' else 'int32',
                                         'constant':'int32' if kind=='integer' else 'float32'})
    imp=SimpleImputer(strategy='median'); clean=imp.fit_transform(typed)
    scaler=StandardScaler().fit(clean)
    assert r['matrix_dtype']==('float32' if kind=='float_even' else 'float64')
    assert r['medians'][0]==6.0
    np.testing.assert_array_equal(r['medians'],imp.statistics_)
    np.testing.assert_allclose(r['mean'],scaler.mean_,rtol=1e-13)
    np.testing.assert_allclose(r['var'],scaler.var_,rtol=1e-13)
    actual=np.concatenate([x for x,y in api().iter_stacking_data(kw['archive'],r,limit=2)])
    expected=scaler.transform(imp.transform(typed.iloc[:2])).astype(np.float32)
    np.testing.assert_array_equal(actual,expected)
