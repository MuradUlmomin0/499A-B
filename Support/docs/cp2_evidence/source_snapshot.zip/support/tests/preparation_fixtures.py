"""Small synthetic archives for preparation checks; never research data."""
import csv
import hashlib
import io
from pathlib import Path
from zipfile import ZipFile
import yaml

CLASSES = ['Benign', 'DDoS', 'DoS', 'Mirai', 'Recon', 'Spoofing', 'Web-based', 'Brute Force']
FOLDERS = ['Benign_Final', 'DDoS-TCP_Flood', 'DoS-UDP_Flood', 'Mirai-greip_flood',
           'Recon-PortScan', 'DNS_Spoofing', 'XSS', 'DictionaryBruteForce']


def make_inputs(tmp_path, *, count=24, additions=None, max_rows=160):
    archive = tmp_path / 'source.zip'
    with ZipFile(archive, 'w') as z:
        for identifier, folder in enumerate(FOLDERS):
            content = io.StringIO(newline='')
            writer = csv.writer(content)
            writer.writerow(['f0', 'f1'])
            writer.writerows([[identifier * 1000 + j, identifier * 1000 + j * 0.25 + 1]
                              for j in range(count)])
            writer.writerows((additions or {}).get(folder, []))
            z.writestr(f'CSV/{folder}/{folder}.pcap.csv', content.getvalue())
    config = {
        'schema_version': 1,
        'source': {'archive_path': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                   'feature_names': ['f0', 'f1'], 'expected_valid_counts': dict.fromkeys(CLASSES, count)},
        'output': {'directory': str(tmp_path / 'output'), 'work_dir': str(tmp_path / 'work')},
        'pilot': {'max_rows': max_rows, 'chunk_rows': 7, 'seed': 42, 'num_clients': 3, 'dirichlet_alpha': 0.5},
        'model': {'hidden_dims': [8, 4]},
    }
    path = tmp_path / 'preparation.yaml'
    path.write_text(yaml.safe_dump(config))
    return path, config
