"""Tiny artificial source verifies lineage, auxiliary removal and exact quotas."""
import hashlib, importlib, json
from zipfile import ZipFile
import numpy as np
import pytest


def fixture(tmp_path):
    rows={'train':[(i,'a' if i<10 else 'b') for i in range(20)]+[(0,'a')],
          'validation':[(0,'a'),(30,'a'),(31,'b')],
          'test':[(1,'a'),(30,'a'),(40,'a'),(41,'b')]}
    zpath=tmp_path/'source.zip'
    with ZipFile(zpath,'w') as z:
        for role,items in rows.items():z.writestr(f'Dataset/{role}.csv','f,label\n'+''.join(f'{x},{y}\n' for x,y in items))
    return {'archive_path':str(zpath),'archive_sha256':hashlib.sha256(zpath.read_bytes()).hexdigest(),
            'feature_names':['f'],'class_names':['a','b'],'expected_rows':{r:len(v) for r,v in rows.items()},'chunk_rows':3}


def run(c,out,work):
    return importlib.import_module('support.data.research_source').prepare_source(c,out,work,8,1,42)


def test_exact_source_priority_auxiliary_and_proportions(tmp_path):
    c=fixture(tmp_path);out=tmp_path/'out';r=run(c,out,tmp_path)
    assert r['selected_rows']==8
    assert r['eligible_rows']['validation']==2 and r['eligible_rows']['test']==2
    assert np.load(out/'validation_features.npy')[:,0].tolist()==[30.,31.]
    assert np.load(out/'test_features.npy')[:,0].tolist()==[40.,41.]
    train=np.load(out/'train_features.npy')[:,0];aux=np.load(out/'auxiliary_features.npy')[:,0]
    assert not set(train)&set(aux)
    assert len(aux)==2
    assert np.bincount(np.load(out/'train_labels.npy'),minlength=2).tolist()==r['quotas']
    ords=np.load(out/'train_ordinals.npy');assert ords.tolist()==sorted(ords.tolist())
    assert json.loads((out/'selection.json').read_text())==r
    with pytest.raises(FileExistsError):run(c,out,tmp_path)


def test_reproducible_different_chunk_size(tmp_path):
    c=fixture(tmp_path);a=tmp_path/'a';b=tmp_path/'b';run(c,a,tmp_path)
    c['chunk_rows']=1;run(c,b,tmp_path)
    for name in ['train_features','train_ordinals','auxiliary_features','auxiliary_ordinals']:
        assert np.array_equal(np.load(a/f'{name}.npy'),np.load(b/f'{name}.npy'))


def test_source_hash_failure_no_completion_marker(tmp_path):
    c=fixture(tmp_path);c['archive_sha256']='0'*64
    with pytest.raises(ValueError):run(c,tmp_path/'out',tmp_path)
    assert not (tmp_path/'out/selection.json').exists()
