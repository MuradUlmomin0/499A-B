"""Independent testing-only checks of source-aligned export and fingerprints."""
import importlib
import pytest
from support.tests.test_research_export import fixture
from support.data.research_export import export_research


def test_source_alignment_and_disjoint_role_verification(tmp_path):
    raw,c,s=fixture(tmp_path);out=tmp_path/'out';export_research(raw,c,s,out)
    result=importlib.import_module('support.research_verification').verify_prepared(raw,out)
    assert result['source_alignment_verified'] and result['all_role_groups_disjoint']
    assert result['roles']['validation']==2 and not result['test_scored']


def test_modified_export_rejected(tmp_path):
    raw,c,s=fixture(tmp_path);out=tmp_path/'out';export_research(raw,c,s,out)
    (out/'train.ids.json').write_text('{}')
    with pytest.raises(ValueError,match='hash'):
        importlib.import_module('support.research_verification').verify_prepared(raw,out)
