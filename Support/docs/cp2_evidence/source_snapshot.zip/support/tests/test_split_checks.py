"""Synthetic ID declarations only; no dataset preparation or model training."""
from dataclasses import replace
import json

import pytest

from support.data.split_checks import check_disjoint_splits, file_sha256, load_split_evidence


@pytest.fixture
def evidence_factory(tmp_path):
    def make(name, *, records=None, groups=None, namespace='fixture-v1'):
        data = tmp_path / f'{name}.npz'
        data.write_bytes(name.encode())
        value = {'schema_version': 1, 'source_namespace': namespace,
                 'data_sha256': file_sha256(data), 'record_ids': records or [f'{name}-0', f'{name}-1'],
                 'group_ids': groups}
        path = tmp_path / f'{name}.ids.json'
        path.write_text(json.dumps(value))
        return path, data, value
    return make


def read(fixture):
    path, data, _ = fixture
    return load_split_evidence(path, data_path=data, sample_count=2)


def test_disjoint_declarations_and_fingerprints(evidence_factory):
    a, b = read(evidence_factory('a')), read(evidence_factory('b'))
    result = check_disjoint_splits({'train': a, 'validation': b}, policy='record')
    assert result['partition_counts'] == {'train': 2, 'validation': 2}
    assert result['declared_record_ids_disjoint'] is True
    assert result['declared_group_ids_disjoint'] is None
    assert result['provenance_verified'] is False
    assert a.sidecar_sha256 == file_sha256(a.sidecar_path)


def test_record_overlap_including_external_test_audit(evidence_factory):
    a = read(evidence_factory('a'))
    b = read(evidence_factory('b', records=['a-1', 'b-1']))
    with pytest.raises(ValueError, match='record overlap'):
        check_disjoint_splits({'train': a, 'test': b}, policy='record')


def test_group_policy_is_explicit_and_allows_repeats_within_partition(evidence_factory):
    a = read(evidence_factory('a', groups=['device-a'] * 2))
    b = read(evidence_factory('b', groups=['device-b'] * 2))
    assert check_disjoint_splits({'a': a, 'b': b}, policy='group')['declared_group_ids_disjoint'] is True
    shared = replace(b, group_ids=('device-a', 'device-b'))
    with pytest.raises(ValueError, match='group overlap'):
        check_disjoint_splits({'a': a, 'b': shared}, policy='group')
    assert check_disjoint_splits({'a': a, 'b': shared}, policy='record')['policy'] == 'record'


def test_missing_groups_and_different_namespaces_fail(evidence_factory):
    a, b = read(evidence_factory('a')), read(evidence_factory('b', namespace='other'))
    with pytest.raises(ValueError, match='source_namespace'):
        check_disjoint_splits({'a': a, 'b': b}, policy='record')
    with pytest.raises(ValueError, match='requires group IDs'):
        check_disjoint_splits({'a': a, 'b': replace(b, source_namespace=a.source_namespace)}, policy='group')


@pytest.mark.parametrize('field,value', [
    ('schema_version', True), ('schema_version', 2), ('source_namespace', ''),
    ('data_sha256', '0' * 64), ('record_ids', ['same', 'same']),
    ('record_ids', ['a']), ('record_ids', [0, 'b']), ('group_ids', ['a']),
    ('group_ids', [True, 'b']), ('extra', 1),
])
def test_invalid_sidecars(evidence_factory, field, value):
    path, data, description = evidence_factory('a')
    description[field] = value
    path.write_text(json.dumps(description))
    with pytest.raises(ValueError):
        load_split_evidence(path, data_path=data, sample_count=2)


def test_required_fields_duplicates_and_changed_data(evidence_factory):
    path, data, value = evidence_factory('a')
    path.write_text('{"schema_version":1,"schema_version":1}')
    with pytest.raises(ValueError, match='Duplicate'):
        load_split_evidence(path, data_path=data, sample_count=2)
    path.write_text(json.dumps({k: v for k, v in value.items() if k != 'group_ids'}))
    with pytest.raises(ValueError, match='fields'):
        load_split_evidence(path, data_path=data, sample_count=2)
    path.write_text(json.dumps(value))
    data.write_bytes(b'changed')
    with pytest.raises(ValueError, match='fingerprint'):
        load_split_evidence(path, data_path=data, sample_count=2)


@pytest.mark.parametrize('count', [0, -1, True, 2.0])
def test_bad_sample_count(evidence_factory, count):
    path, data, _ = evidence_factory('a')
    with pytest.raises(ValueError, match='sample_count'):
        load_split_evidence(path, data_path=data, sample_count=count)


def test_invalid_partition_collections(evidence_factory):
    a = read(evidence_factory('a'))
    for values, policy in [({'a': a}, 'record'), ({'a': a, 'b': a}, 'guessed'), ({'a': a, 'b': None}, 'record')]:
        with pytest.raises((ValueError, TypeError)):
            check_disjoint_splits(values, policy=policy)
