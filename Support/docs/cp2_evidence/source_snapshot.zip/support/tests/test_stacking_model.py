"""Notebook architecture compatibility; fixed artificial weights, no training."""
import importlib
import torch
import pytest


def api():
    return importlib.import_module('support.models.stacking')


def test_notebook_composition_and_fixed_output():
    # Catches wrong concatenation dimensions or residual/output wiring.
    cls = api().PyTorchStackingClassifier
    m = cls(3, 2).eval()
    with torch.no_grad():
        for p in m.parameters(): p.zero_()
        m.meta_model.output_layer.bias.copy_(torch.tensor([2., -1.]))
    assert torch.equal(m(torch.ones(4, 3)), torch.tensor([[2., -1.]]).repeat(4, 1))
    assert m.meta_model.input_layer[0].in_features == 6
    assert not m.base_model3.estimators[0].projection.weight.requires_grad


def test_checkpoint_roundtrip_integer_buffers_and_rng(tmp_path):
    mod = api()
    with torch.random.fork_rng():
        m = mod.PyTorchStackingClassifier(3, 2)
    m.base_model2.network[1].num_batches_tracked.fill_(7)
    p = tmp_path/'weights.pth'
    torch.save(m.state_dict(), p)
    rng = torch.get_rng_state().clone()
    loaded = mod.load_stacking_checkpoint(p, 3, 2)
    assert torch.equal(rng, torch.get_rng_state())
    assert not loaded.training
    assert loaded.base_model2.network[1].num_batches_tracked.item() == 7
    assert all(torch.equal(v, loaded.state_dict()[k]) for k,v in m.state_dict().items())


@pytest.mark.parametrize('damage', ['nan', 'missing', 'shape', 'negative_counter', 'counter_dtype'])
def test_bad_checkpoint_rejected(tmp_path, damage):
    mod = api()
    m = mod.PyTorchStackingClassifier(3, 2)
    state = m.state_dict()
    key = 'meta_model.output_layer.weight'
    if damage == 'nan': state[key][0,0] = float('nan')
    if damage == 'missing': del state[key]
    if damage == 'shape': state[key] = torch.zeros(3,3)
    counter = 'base_model2.network.1.num_batches_tracked'
    if damage == 'negative_counter': state[counter].fill_(-1)
    if damage == 'counter_dtype': state[counter] = torch.tensor(1.)
    p=tmp_path/'weights.pth'; torch.save(state,p)
    with pytest.raises(ValueError): mod.load_stacking_checkpoint(p,3,2)


def test_input_and_dimension_checks():
    mod = api()
    with pytest.raises(ValueError): mod.PyTorchStackingClassifier(0,2)
    with pytest.raises(ValueError): mod.PyTorchStackingClassifier(3,1)
    with pytest.raises(ValueError): mod.PyTorchStackingClassifier(3,2)(torch.zeros(2,4))
