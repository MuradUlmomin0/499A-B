"""Catch held-out leakage, non-IID allocation loss and incompatible exports."""
import json
import numpy as np
import pytest
from support.tests.preparation_fixtures import make_inputs


def sample_inputs(tmp_path):
    from support.data.pilot_sampling import audit_and_sample
    _, config = make_inputs(tmp_path, count=40, max_rows=240)
    work = tmp_path / 'scratch'; work.mkdir()
    sample, _ = audit_and_sample(config, work, lambda v: None)
    return sample, config


def test_partition_plan_is_disjoint_complete_and_repeatable(tmp_path):
    from support.data.pilot_export import partition_indices
    sample, config = sample_inputs(tmp_path)
    first = partition_indices(sample['labels'], config)
    second = partition_indices(sample['labels'], config)
    all_indices = np.concatenate(list(first.values()))
    assert sorted(all_indices.tolist()) == list(range(240))
    assert len(first) == 6  # Three clients, validation, auxiliary, test.
    assert all(np.array_equal(first[k], second[k]) for k in first)
    for role in ['validation', 'auxiliary', 'test']:
        assert len(first[role]) == 24
        assert set(sample['labels'][first[role]]) == set(range(8))


def test_fitted_statistics_use_training_values_only(tmp_path):
    from support.data.pilot_export import fit_preprocessing
    features = np.array([[1., 4.], [3., 8.], [1000., -1000.]], dtype=np.float32)
    stats = fit_preprocessing(features, np.array([0, 1]), ['a', 'b'], chunk_rows=1)
    assert stats['mean'] == [2., 6.] and stats['scale'] == [1., 2.]
    features[2] = [1e20, 1e20]
    assert fit_preprocessing(features, np.array([0, 1]), ['a', 'b'], chunk_rows=2) == stats


def test_all_roles_reload_with_contract_group_and_lineage_checks(tmp_path):
    from support.data.pilot_export import export_pilot
    from support.data.federated_bundle import load_federated_bundle
    from support.data.prepared import load_prepared_data
    from support.data.split_checks import load_split_evidence, check_disjoint_splits
    sample, config = sample_inputs(tmp_path)
    output = tmp_path / 'export'; output.mkdir()
    report = export_pilot(sample, config, output)
    bundle = load_federated_bundle(output / 'federated_bundle.json')
    assert bundle.testing_only and bundle.contract.input_dim == 2 and bundle.contract.num_classes == 8
    evidence = {}
    for name, part in report['partitions'].items():
        data = load_prepared_data(output / part['manifest'], expected_role=part['role'], expected_contract=bundle.contract)
        assert len(data.dataset) == part['rows']
        evidence[name] = load_split_evidence(output/part['evidence'], data_path=data.manifest.data_path, sample_count=part['rows'])
    assert check_disjoint_splits(evidence, policy='group')['declared_group_ids_disjoint']
    lineage = [json.loads(x) for x in (output / 'lineage.jsonl').read_text().splitlines()]
    assert len(lineage) == 240 and len({r['record_id'] for r in lineage}) == 240
    assert all(r['subtype'] and r['member'] and r['raw_feature_group'] for r in lineage)
    assert sum(p['rows'] for p in report['partitions'].values()) == 240
    preprocessing = json.loads((output / 'preprocessing.json').read_text())
    assert preprocessing['fit_sample_count'] == 168
    assert report['provenance_verified'] is False and report['simulated_clients'] is True


def test_cross_role_float32_collision_is_rejected(tmp_path):
    from support.data.pilot_export import export_pilot, partition_indices
    sample, config = sample_inputs(tmp_path)
    parts = partition_indices(sample['labels'], config)
    a, b = parts['validation'][0], parts['test'][0]
    sample['features'][b] = sample['features'][a]
    output = tmp_path/'export'; output.mkdir()
    with pytest.raises(ValueError, match='collision'):
        export_pilot(sample, config, output)
    assert not (output/'run_summary.json').exists()


def test_class_too_small_for_four_roles_is_rejected(tmp_path):
    from support.data.pilot_export import partition_indices
    _, config = make_inputs(tmp_path)
    with pytest.raises(ValueError): partition_indices(np.arange(8), config)
