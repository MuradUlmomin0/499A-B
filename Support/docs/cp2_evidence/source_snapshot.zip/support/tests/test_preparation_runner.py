"""Exercise real preparation and CLI with optimization explicitly forbidden."""
import json
import sys
from pathlib import Path
import numpy as np
import pytest
import torch
import yaml
from support.tests.preparation_fixtures import make_inputs


@pytest.fixture(autouse=True)
def forbid_training(monkeypatch):
    def forbidden(*args, **kwargs): raise AssertionError('Training forbidden during preparation')
    monkeypatch.setattr(torch.optim.Optimizer, '__init__', forbidden)
    monkeypatch.setattr(torch.Tensor, 'backward', forbidden)


def test_complete_preparation_preserves_source_and_marks_diagnostic(tmp_path):
    from support.prepare_runner import run_preparation
    from support.data.federated_bundle import load_federated_bundle
    path, config = make_inputs(tmp_path)
    before = Path(config['source']['archive_path']).read_bytes()
    out = run_preparation(path)
    summary = json.loads((out/'run_summary.json').read_text())
    assert summary['status'] == 'completed' and summary['testing_only'] is True
    assert summary['training_performed'] is False and summary['rows_exported'] == 160
    assert load_federated_bundle(out/'federated_bundle.json').testing_only
    assert Path(config['source']['archive_path']).read_bytes() == before
    assert not list(Path(config['output']['work_dir']).iterdir())
    with pytest.raises(FileExistsError): run_preparation(path)
    assert Path(config['source']['archive_path']).read_bytes() == before


def test_source_hash_mismatch_precedes_output_creation(tmp_path):
    from support.prepare_runner import run_preparation
    path, config = make_inputs(tmp_path)
    config['source']['sha256'] = '0'*64
    path.write_text(yaml.safe_dump(config))
    with pytest.raises(ValueError, match='SHA'):
        run_preparation(path)
    assert not Path(config['output']['directory']).exists()
    assert not Path(config['output']['work_dir']).exists()


def test_export_failure_has_diagnostics_without_completion(tmp_path, monkeypatch):
    import support.prepare_runner as runner
    path, config = make_inputs(tmp_path)
    def fail(*args): raise OSError('export failed')
    monkeypatch.setattr(runner, 'export_pilot', fail)
    with pytest.raises(OSError): runner.run_preparation(path)
    out = Path(config['output']['directory'])
    assert (out/'failure.json').exists() and not (out/'run_summary.json').exists()
    assert not list(Path(config['output']['work_dir']).iterdir())


def test_insufficient_scratch_disk_fails_before_output(tmp_path, monkeypatch):
    import support.prepare_runner as runner
    path, config = make_inputs(tmp_path)
    monkeypatch.setattr(runner.shutil, 'disk_usage', lambda p: type('Disk', (), {'free': 1})())
    with pytest.raises(ValueError, match='disk'): runner.run_preparation(path)
    assert not Path(config['output']['directory']).exists()


def test_cli_runs_preparation_without_optimizer(tmp_path, monkeypatch, capsys):
    import main
    path, config = make_inputs(tmp_path)
    monkeypatch.setattr(sys, 'argv', ['main.py', '--prepare-data', '--config', str(path)])
    main.main()
    assert 'Data preparation completed' in capsys.readouterr().out
    assert (Path(config['output']['directory'])/'run_summary.json').exists()


@pytest.mark.parametrize('arguments', [['--prepare-data'], ['--prepare-data', '--federated'], ['--prepare-data', '--prepared']])
def test_preparation_cli_requires_explicit_exclusive_config(monkeypatch, arguments):
    import main
    monkeypatch.setattr(sys, 'argv', ['main.py', *arguments])
    with pytest.raises(SystemExit) as error: main.main()
    assert error.value.code == 2
