"""Small testing-only runner and six-condition config generation."""
import importlib,json
from pathlib import Path
import pytest
import yaml
from support.utils.training_config import load_training_config


def test_configs_six_cases_validation_only(tmp_path):
    api=importlib.import_module('support.research_runner')
    settings={'partition_and_training_seeds':[42,43,44],'rounds':20,'participation_rate':1.,
        'optimizer':'adam','learning_rate':.001,'local_epochs':1,'batch_size':128}
    paths=api.make_configs(tmp_path/'prepared',settings,tmp_path/'configs',tmp_path/'results')
    assert len(paths)==6
    for p in paths:
        c=load_training_config(p)
        assert c['federated']['rounds']==20 and c['initialization']['mode']=='random'
        assert 'test' not in c['dataset'] and 'auxiliary' not in c['dataset']
    with pytest.raises(FileExistsError):api.make_configs(tmp_path/'prepared',settings,tmp_path/'configs',tmp_path/'results')


def test_actual_tiny_run_and_reload_verification(tmp_path):
    # Use the tested exporter fixture; artificial dataset metrics stay testing-only.
    from support.tests.test_research_export import fixture
    from support.data.research_export import export_research
    raw,c,s=fixture(tmp_path);prepared=tmp_path/'prepared';export_research(raw,c,s,prepared)
    settings={**s,'rounds':2,'participation_rate':1.,'optimizer':'adam','learning_rate':.001,'local_epochs':1,'batch_size':2}
    api=importlib.import_module('support.research_runner')
    paths=api.make_configs(prepared,settings,tmp_path/'configs',tmp_path/'results')
    path=api.run_one(paths[0]);v=json.loads((path/'verification.json').read_text())
    assert v['reloaded_validation_exact'] and v['aggregation_verified'] and v['history_verified']
    assert v['testing_only'] and not v['test_scored']
    assert len(list((path).glob('validation_per_class.csv')))==1


def test_matrix_requires_preflight_before_launch(tmp_path):
    api=importlib.import_module('support.research_runner')
    with pytest.raises(ValueError,match='preflight'):
        api.run_matrix(tmp_path/'configs',tmp_path/'matrix')


def test_incomplete_export_rejected_before_training(tmp_path):
    from support.tests.test_research_export import fixture
    from support.data.research_export import export_research
    raw,c,s=fixture(tmp_path);prepared=tmp_path/'prepared';export_research(raw,c,s,prepared)
    settings={**s,'rounds':2,'participation_rate':1.,'optimizer':'adam','learning_rate':.001,'local_epochs':1,'batch_size':2}
    api=importlib.import_module('support.research_runner');paths=api.make_configs(prepared,settings,tmp_path/'configs',tmp_path/'results')
    (prepared/'preparation_report.json').unlink()
    with pytest.raises(ValueError,match='completed preparation'):api.run_one(paths[0])
    assert not (tmp_path/'results').exists()
