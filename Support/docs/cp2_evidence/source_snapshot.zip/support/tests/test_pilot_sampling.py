"""Catch duplicates leaking through a sample and unbounded source retention."""
from pathlib import Path
import hashlib
import numpy as np
import pytest
from support.tests.preparation_fixtures import make_inputs, CLASSES, FOLDERS


def run_sample(config, path):
    from support.data.pilot_sampling import audit_and_sample
    path.mkdir()
    return audit_and_sample(config, path, lambda value: None)


def test_global_duplicate_and_conflicting_labels_remove_all_ambiguous_groups(tmp_path):
    _, config = make_inputs(tmp_path, additions={FOLDERS[0]: [[0, 1], [1000, 1001]]}, max_rows=500)
    config['source']['expected_valid_counts']['Benign'] += 2
    sample, report = run_sample(config, tmp_path / 'scratch')
    assert report['valid_rows'] == 194
    assert report['unique_feature_groups'] == 192
    assert report['duplicate_excess_rows'] == 2
    assert report['conflicting_groups'] == 1 and report['conflicting_rows'] == 2
    assert len(sample['features']) == 191
    assert len(set(bytes(x) for x in sample['hashes'])) == 191
    assert not np.any(np.all(sample['features'] == [1000, 1001], axis=1))
    assert report['peak_retained_groups'] <= 194
    assert sample['features'].dtype == np.float32


def test_same_seed_and_different_chunks_preserve_groups_and_lineage(tmp_path):
    _, config = make_inputs(tmp_path)
    state = np.random.get_state()
    first, _ = run_sample(config, tmp_path / 'one')
    config['pilot']['chunk_rows'] = 11
    second, _ = run_sample(config, tmp_path / 'two')
    for key in ['features', 'labels', 'hashes', 'file_indices', 'row_ordinals', 'subtypes']:
        assert np.array_equal(first[key], second[key]), key
    assert np.array_equal(state[1], np.random.get_state()[1])
    assert len(first['features']) == 160


def test_conflicting_group_from_later_source_is_not_missed(tmp_path):
    one = tmp_path / 'a'; one.mkdir()
    _, config = make_inputs(one, max_rows=64)
    first, _ = run_sample(config, one / 'scratch')
    retained = first['features'][first['labels'] == 0][0].tolist()
    two = tmp_path / 'b'; two.mkdir()
    _, changed = make_inputs(two, additions={FOLDERS[1]: [retained]}, max_rows=64)
    changed['source']['expected_valid_counts']['DDoS'] += 1
    sample, report = run_sample(changed, two / 'scratch')
    assert report['conflicting_groups'] == 1
    assert not np.any(np.all(sample['features'] == retained, axis=1))


def test_actual_counts_must_match_pinned_profile(tmp_path):
    _, config = make_inputs(tmp_path)
    config['source']['expected_valid_counts']['Benign'] += 1
    with pytest.raises(ValueError, match='counts'):
        run_sample(config, tmp_path / 'scratch')


def test_failed_external_sort_is_not_accepted(tmp_path, monkeypatch):
    import subprocess
    from support.data import pilot_sampling
    _, config = make_inputs(tmp_path)
    monkeypatch.setattr(pilot_sampling.subprocess, 'run', lambda *a, **k: subprocess.CompletedProcess(a, 1, '', 'forced failure'))
    with pytest.raises(RuntimeError, match='sort'):
        run_sample(config, tmp_path / 'scratch')


def test_insufficient_conflict_free_class_fails_instead_of_refilling(tmp_path):
    conflict = [[j, j * .25 + 1] for j in range(24)]
    _, config = make_inputs(tmp_path, additions={FOLDERS[1]: conflict})
    config['source']['expected_valid_counts']['DDoS'] += 24
    with pytest.raises(ValueError, match='eligible'):
        run_sample(config, tmp_path / 'scratch')


def test_external_sort_spills_large_input_under_its_memory_ceiling(tmp_path):
    from support.data.pilot_sampling import _external_sort
    source, destination = tmp_path/'large.tsv', tmp_path/'sorted.tsv'
    with source.open('xb', buffering=1024*1024) as stream:
        for offset in range(0, 3000000, 50000):
            stream.write(''.join(f'{hashlib.sha256(value.to_bytes(8, "little")).hexdigest()}\t{value % 8}\n'
                                 for value in range(offset, offset+50000)).encode())
    _external_sort(source, destination, tmp_path)
    assert destination.stat().st_size == source.stat().st_size
    with destination.open('rb') as stream:
        previous = b''
        count = 0
        for line in stream:
            assert line >= previous
            previous = line
            count += 1
    assert count == 3000000
