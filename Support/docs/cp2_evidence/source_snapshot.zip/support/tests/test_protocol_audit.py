"""Hand-counted original-role priority checks; artificial CSVs are test-only."""
import hashlib
import importlib
import io
import json
from zipfile import ZipFile

import pytest


def source(tmp_path, conflict=False):
    rows = {'train': [(1, 'a'), (1, 'a'), (2, 'b')],
            'validation': [(1, 'a'), (3, 'a'), (3, 'a'), (4, 'b')],
            'test': [(1, 'a'), (3, 'a'), (5, 'b'), (5, 'b')]}
    if conflict:
        rows['test'].append((1, 'b'))
    archive = tmp_path/'source.zip'
    with ZipFile(archive, 'w') as z:
        for role, values in rows.items():
            z.writestr(f'Dataset/{role}.csv', 'f,label\n'+''.join(f'{x},{y}\n' for x,y in values))
    return {'archive_path': str(archive),
            'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'feature_names': ['f'], 'class_names': ['a','b'], 'chunk_rows': 2,
            'expected_rows': {role: len(values) for role,values in rows.items()}}


def run(config, tmp_path, name='out'):
    return importlib.import_module('support.data.protocol_audit').audit_protocol_support(
        config, tmp_path/name, tmp_path)


def test_priority_removes_later_roles_preserving_multiplicity(tmp_path):
    c=source(tmp_path); report=run(c,tmp_path)
    assert report['eligible_rows']=={'train':[2,1], 'validation':[2,1], 'test':[0,2]}
    assert report['eligible_groups']=={'train':[1,1], 'validation':[1,1], 'test':[0,1]}
    assert report['excluded_rows']=={'train':[0,0], 'validation':[1,0], 'test':[2,0]}
    assert report['original_rows']=={'train':[2,1], 'validation':[3,1], 'test':[2,2]}
    assert report['unique_groups']==5
    assert report['original_groups']=={'train':[1,1], 'validation':[2,1], 'test':[2,1]}
    for role in ['train','validation','test']:
        assert report['original_rows'][role]==[a+b for a,b in zip(
            report['eligible_rows'][role],report['excluded_rows'][role])]
    assert sum(sum(v) for v in report['eligible_groups'].values())==report['unique_groups']
    assert report['test_scored'] is False
    assert report['auxiliary_reserved'] is False
    assert json.loads((tmp_path/'out/support.json').read_text())==report
    assert (tmp_path/'out/support_by_class.csv').is_file()
    assert hashlib.sha256(open(c['archive_path'],'rb').read()).hexdigest()==c['archive_sha256']
    assert not list(tmp_path.glob('protocol_support_*'))


def test_mixed_labels_stop_without_eligible_report(tmp_path):
    c=source(tmp_path,conflict=True)
    with pytest.raises(ValueError,match='Conflicting labels'):
        run(c,tmp_path)
    assert not (tmp_path/'out/support.json').exists()


@pytest.mark.parametrize('damage',['hash','rows','schema','classes'])
def test_wrong_source_fails_closed(tmp_path,damage):
    c=source(tmp_path)
    if damage=='hash':c['archive_sha256']='0'*64
    if damage=='rows':c['expected_rows']['train']+=1
    if damage=='schema':c['feature_names']=['other']
    if damage=='classes':c['class_names']=['a','unknown']
    with pytest.raises(ValueError):run(c,tmp_path)
    assert not (tmp_path/'out/support.json').exists()


def test_chunking_does_not_change_support_and_outputs_cannot_overwrite(tmp_path):
    c=source(tmp_path); a=run(c,tmp_path,'one')
    c['chunk_rows']=3; b=run(c,tmp_path,'two')
    assert a==b
    with pytest.raises(FileExistsError):run(c,tmp_path,'one')


def replace_member(config, member, contents):
    with ZipFile(config['archive_path']) as z:
        parts={name:z.read(name) for name in z.namelist()}
    parts[member]=contents
    with ZipFile(config['archive_path'],'w') as z:
        for name,value in parts.items():z.writestr(name,value)
    config['archive_sha256']=hashlib.sha256(open(config['archive_path'],'rb').read()).hexdigest()


def test_float32_collisions_and_signed_zero_share_groups(tmp_path):
    c=source(tmp_path)
    replace_member(c,'Dataset/train.csv',b'f,label\n0.0,a\n-0.0,a\n16777216,b\n16777217,b\n')
    c['expected_rows']['train']=4
    a=run(c,tmp_path)
    assert a['original_rows']['train']==[2,2]
    assert a['original_groups']['train']==[1,1]


@pytest.mark.parametrize('values',[
    b'f,label\nnan,a\n1,a\n2,b\n',
    b'f,label\ninf,a\n1,a\n2,b\n',
    b'f,label\n1e300,a\n1,a\n2,b\n',
    b'f,label\n,a\n1,a\n2,b\n',
    b'f,label\n16777216,a\n16777217,b\n2,b\n'])
def test_invalid_inputs_and_float32_label_conflicts_stop(tmp_path,values):
    c=source(tmp_path);replace_member(c,'Dataset/train.csv',values)
    with pytest.raises(ValueError):run(c,tmp_path)
    assert not (tmp_path/'out/support.json').exists()
    assert not list(tmp_path.glob('protocol_support_*'))


def test_test_membership_cannot_change_earlier_role_eligibility(tmp_path):
    c=source(tmp_path);a=run(c,tmp_path,'one')
    replace_member(c,'Dataset/test.csv',b'f,label\n2,b\n4,b\n6,a\n6,a\n')
    b=run(c,tmp_path,'two')
    for field in ['original_rows','original_groups','eligible_rows','eligible_groups','excluded_rows']:
        for role in ['train','validation']:assert a[field][role]==b[field][role]


@pytest.mark.parametrize('damage',['sort_failure','wrong_total','changed_source'])
def test_failed_audit_publishes_no_report_and_cleans_scratch(tmp_path,monkeypatch,damage):
    c=source(tmp_path);api=importlib.import_module('support.data.protocol_audit')
    if damage=='sort_failure':
        def fail(*args):raise RuntimeError('sort failed')
        monkeypatch.setattr(api,'_sort',fail)
    elif damage=='wrong_total':
        original=api._sort
        def shorten(source,destination,directory):
            original(source,destination,directory)
            destination.write_text('')
        monkeypatch.setattr(api,'_sort',shorten)
    else:
        calls=iter([c['archive_sha256'],'0'*64])
        monkeypatch.setattr(api,'source_hash',lambda path:next(calls))
    with pytest.raises((ValueError,RuntimeError)):run(c,tmp_path)
    assert not (tmp_path/'out').exists()
    assert not list(tmp_path.glob('protocol_support_*'))


@pytest.mark.parametrize('lines',[
    'x\t0\t000\n',
    'f'*64+'\t0\t000\n'+'a'*64+'\t0\t000\n',
    'a'*64+'\t3\t000\n',
    'a'*64+'\t0\t002\n'])
def test_reducer_rejects_malformed_or_unsorted_records(lines):
    api=importlib.import_module('support.data.protocol_audit')
    with pytest.raises(ValueError):api.summarize_sorted(io.StringIO(lines),['a','b'])
