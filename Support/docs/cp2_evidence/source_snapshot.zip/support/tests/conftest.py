import pytest
from pathlib import Path
from support.utils.config import load_config


@pytest.fixture
def config():
    return load_config(Path(__file__).parents[1] / 'configs/fedavg_dummy_test.yaml')


@pytest.fixture
def federated_inputs(tmp_path):
    """Build explicit synthetic C inputs; never fit preprocessing or a model."""
    import json
    import numpy as np
    from support.data.contract import ModelDataContract
    from support.data.split_checks import file_sha256

    def make(*, counts=(2, 6), input_dim=2, num_classes=2, policy='record', testing_only=True):
        folder = tmp_path / 'federated_inputs'
        folder.mkdir(exist_ok=True)
        contract = ModelDataContract('mlp', input_dim, num_classes, (input_dim,),
                                    tuple(f'f{i}' for i in range(input_dim)),
                                    tuple(f'c{i}' for i in range(num_classes)), None)
        parts = {}
        for index, (identifier, count) in enumerate([*(('a' if i == 0 else f'b{i}', n) for i, n in enumerate(counts)), ('validation', 3)]):
            role = 'validation' if identifier == 'validation' else 'train'
            data_path = folder / f'{identifier}.npz'
            features = np.arange(count * input_dim, dtype=np.float32).reshape(count, input_dim) / 10 + index
            np.savez(data_path, features=features, labels=np.arange(count, dtype=np.int64) % num_classes,
                     feature_names=np.array(contract.feature_names), class_names=np.array(contract.class_names))
            manifest = folder / f'{identifier}.json'
            manifest.write_text(json.dumps({
                'schema_version': 1, 'dataset_name': 'synthetic-c-fixture', 'partition_name': identifier,
                'role': role, 'client_id': None if role == 'validation' else identifier,
                'data_format': 'npz', 'data_path': data_path.name, 'preprocessing_path': None,
                'contract': contract.to_dict(), 'testing_only': testing_only,
            }))
            sidecar = folder / f'{identifier}.ids.json'
            sidecar.write_text(json.dumps({
                'schema_version': 1, 'source_namespace': 'synthetic-c-fixture-v1',
                'data_sha256': file_sha256(data_path),
                'record_ids': [f'{identifier}-{row}' for row in range(count)],
                'group_ids': [f'group-{identifier}'] * count,
            }))
            parts[identifier] = {'manifest': manifest, 'data': data_path, 'evidence': sidecar}
        bundle = folder / 'bundle.json'
        bundle.write_text(json.dumps({
            'schema_version': 1, 'bundle_name': 'synthetic-c-fixture', 'contract': contract.to_dict(),
            'split_policy': policy,
            'clients': [{'client_id': identifier, 'manifest_path': item['manifest'].name,
                         'evidence_path': item['evidence'].name}
                        for identifier, item in parts.items() if identifier != 'validation'],
            'validation': {'manifest_path': parts['validation']['manifest'].name,
                           'evidence_path': parts['validation']['evidence'].name},
        }))
        return {'bundle': bundle, 'contract': contract, 'partitions': parts}
    return make


@pytest.fixture
def federated_config(tmp_path, federated_inputs):
    """Return a YAML/input factory for synthetic orchestration tests."""
    import yaml
    def make(**kwargs):
        inputs = federated_inputs(**kwargs)
        path = tmp_path / 'federated_config.yaml'
        path.write_text(yaml.safe_dump({
            'schema_version': 1,
            'experiment': {'name': 'synthetic_fedavg', 'seed': 42, 'device': 'cpu',
                           'deterministic': True, 'output_dir': 'training_runs'},
            'dataset': {'bundle_path': str(inputs['bundle'])},
            'initialization': {'mode': 'random', 'artifact_path': None},
            'federated': {'aggregation': 'fedavg', 'rounds': 2, 'participation_rate': 1.0},
            'training': {'optimizer': 'sgd', 'learning_rate': 0.01, 'local_epochs': 1, 'batch_size': 2},
            'selection': {'policy': 'final_round'},
        }))
        return path, inputs
    return make
