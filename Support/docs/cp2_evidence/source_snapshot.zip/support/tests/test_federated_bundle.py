"""Prepared bundle checks with temporary synthetic files; no optimization."""
import json

import pytest

from support.data.federated_bundle import load_federated_bundle


def change(path, mutate):
    value = json.loads(path.read_text())
    mutate(value)
    path.write_text(json.dumps(value))


@pytest.mark.parametrize('policy', ['record', 'group'])
def test_complete_bundle_checks_sources_counts_and_modes(federated_inputs, policy):
    inputs = federated_inputs(policy=policy)
    before = {p: p.read_bytes() for p in inputs['bundle'].parent.iterdir()}
    bundle = load_federated_bundle(inputs['bundle'])
    assert [p.client_id for p in bundle.clients] == ['a', 'b1']
    assert [len(p.data.dataset) for p in bundle.clients] == [2, 6]
    assert bundle.validation.client_id is None
    assert bundle.validation.data.manifest.role == 'validation'
    assert bundle.contract == inputs['contract'] and bundle.testing_only is True
    assert bundle.split_report['policy'] == policy
    metadata = bundle.source_metadata()
    assert metadata['validation']['sample_count'] == 3
    assert metadata['bundle_sha256'] == bundle.sha256
    assert all('record_ids' not in part for part in [*metadata['clients'], metadata['validation']])
    assert '"a-0"' not in json.dumps(metadata)
    assert all(p.read_bytes() == value for p, value in before.items())


@pytest.mark.parametrize('problem', ['duplicate_client', 'extra_test', 'version', 'role', 'client_id',
                                    'contract', 'overlap', 'group_overlap', 'fingerprint', 'missing_evidence'])
def test_bad_bundle_inputs_are_rejected(federated_inputs, problem):
    inputs = federated_inputs(policy='group')
    path, parts = inputs['bundle'], inputs['partitions']
    if problem == 'duplicate_client':
        change(path, lambda d: d['clients'].append(dict(d['clients'][0])))
    elif problem == 'extra_test':
        change(path, lambda d: d.update(test='never_read.json'))
    elif problem == 'version':
        change(path, lambda d: d.update(schema_version=True))
    elif problem == 'role':
        change(parts['validation']['manifest'], lambda d: d.update(role='test'))
    elif problem == 'client_id':
        change(parts['a']['manifest'], lambda d: d.update(client_id='another'))
    elif problem == 'contract':
        change(parts['a']['manifest'], lambda d: d['contract']['feature_names'].reverse())
    elif problem == 'overlap':
        change(parts['validation']['evidence'], lambda d: d['record_ids'].__setitem__(0, 'a-0'))
    elif problem == 'group_overlap':
        change(parts['validation']['evidence'], lambda d: d['group_ids'].__setitem__(0, 'group-a'))
    elif problem == 'fingerprint':
        change(parts['a']['evidence'], lambda d: d.update(data_sha256='0' * 64))
    else:
        parts['a']['evidence'].unlink()
    with pytest.raises((ValueError, FileNotFoundError)):
        load_federated_bundle(path)


def test_relative_paths_and_canonical_client_order(federated_inputs, monkeypatch, tmp_path):
    inputs = federated_inputs()
    change(inputs['bundle'], lambda d: d['clients'].reverse())
    elsewhere = tmp_path / 'elsewhere'
    elsewhere.mkdir()
    monkeypatch.chdir(elsewhere)
    result = load_federated_bundle(inputs['bundle'])
    assert [p.client_id for p in result.clients] == ['a', 'b1']


def test_source_changes_during_loading_are_rejected(federated_inputs, monkeypatch):
    import support.data.federated_bundle as module
    inputs = federated_inputs()
    original = module.load_prepared_data
    def altered(path, **kwargs):
        value = original(path, **kwargs)
        with value.manifest.data_path.open('ab') as stream:
            stream.write(b'changed')
        return value
    monkeypatch.setattr(module, 'load_prepared_data', altered)
    with pytest.raises(ValueError, match='fingerprint|changed'):
        load_federated_bundle(inputs['bundle'])


def test_declared_testing_sources_cannot_be_downgraded(federated_inputs):
    inputs = federated_inputs(testing_only=False)
    change(inputs['partitions']['validation']['manifest'], lambda d: d.update(testing_only=True))
    assert load_federated_bundle(inputs['bundle']).testing_only is True
