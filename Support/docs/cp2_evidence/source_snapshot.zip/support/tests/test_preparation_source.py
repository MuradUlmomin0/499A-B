"""Catch source-lineage mistakes and unsafe settings before allocation."""
import io
import json
from pathlib import Path
from zipfile import ZipFile
import numpy as np
import pytest
import yaml
from support.tests.preparation_fixtures import make_inputs, CLASSES, FOLDERS


def test_short_nonfinite_and_overflow_keep_original_ordinals(tmp_path):
    from support.data.ciciot2023 import stream_chunks
    path, config = make_inputs(tmp_path, additions={FOLDERS[0]: [[float('inf'), 1], [2], [1e100, 3], [-0.0, 7]]})
    stats, quarantine = {}, io.StringIO()
    chunks = list(stream_chunks(config, quarantine, stats))
    assert stats['rows'] == 196 and stats['invalid_rows'] == 3
    assert stats['valid_counts']['Benign'] == 25
    bad = [json.loads(line) for line in quarantine.getvalue().splitlines()]
    assert [x['row_ordinal'] for x in bad] == [24, 25, 26]
    kept = [chunk for chunk in chunks if chunk['label'] == 0]
    assert np.concatenate([x['row_ordinals'] for x in kept]).tolist() == [*range(24), 27]
    assert not np.signbit(kept[-1]['features'][-1, 0])
    assert all(x['features'].dtype == np.float32 and np.isfinite(x['features']).all() for x in chunks)


@pytest.mark.parametrize('name,header', [('Unrecognized', 'f0,f1'), ('Benign_Final', 'f1,f0')])
def test_unknown_folder_or_swapped_header_is_rejected(tmp_path, name, header):
    from support.data.ciciot2023 import stream_chunks
    _, config = make_inputs(tmp_path)
    with ZipFile(config['source']['archive_path'], 'a') as z:
        z.writestr(f'CSV/{name}/bad.csv', header + '\n1,2\n')
    with pytest.raises(ValueError):
        list(stream_chunks(config, io.StringIO(), {}))


def test_configuration_paths_and_caller_data_are_independent(tmp_path):
    from support.utils.preparation_config import load_preparation_config
    path, config = make_inputs(tmp_path)
    config['source']['archive_path'] = 'source.zip'
    config['output'] = {'directory': 'output', 'work_dir': 'work'}
    path.write_text(yaml.safe_dump(config))
    loaded = load_preparation_config(path)
    assert loaded['source']['archive_path'] == str(tmp_path / 'source.zip')
    assert loaded['output']['directory'] == str(tmp_path / 'output')
    assert config['output']['directory'] == 'output'


@pytest.mark.parametrize('section,key,value', [
    ('pilot', 'max_rows', 500001), ('pilot', 'chunk_rows', 25001),
    ('pilot', 'max_rows', True), ('pilot', 'seed', -1), ('pilot', 'num_clients', 1),
    ('pilot', 'dirichlet_alpha', float('nan')), ('source', 'sha256', 'unknown'),
    ('source', 'expected_valid_counts', {'Benign': 20}),
    ('output', 'work_dir', ''), ('model', 'hidden_dims', [0]),
])
def test_unsafe_or_ambiguous_settings_fail(tmp_path, section, key, value):
    from support.utils.preparation_config import load_preparation_config
    path, config = make_inputs(tmp_path)
    config[section][key] = value
    path.write_text(yaml.safe_dump(config))
    with pytest.raises(ValueError): load_preparation_config(path)


def test_duplicate_yaml_and_nested_work_directory_rejected(tmp_path):
    from support.utils.preparation_config import load_preparation_config
    path, config = make_inputs(tmp_path)
    path.write_text(path.read_text() + '\nschema_version: 1\n')
    with pytest.raises(ValueError): load_preparation_config(path)
    config['output']['work_dir'] = str(tmp_path / 'output' / 'scratch')
    path.write_text(yaml.safe_dump(config))
    with pytest.raises(ValueError): load_preparation_config(path)

@pytest.mark.parametrize('section,key,value', [('source', 'feature_names', [f'f{i}' for i in range(10000)]), ('model', 'hidden_dims', [10**9])])
def test_estimated_feature_or_model_memory_is_bounded(tmp_path, section, key, value):
    from support.utils.preparation_config import load_preparation_config
    path, config = make_inputs(tmp_path, max_rows=500000)
    config[section][key] = value
    path.write_text(yaml.safe_dump(config))
    with pytest.raises(ValueError): load_preparation_config(path)


def test_unexpected_text_aborts_with_source_context(tmp_path):
    from support.data.ciciot2023 import stream_chunks
    _, config = make_inputs(tmp_path, additions={FOLDERS[0]: [['unexpected-text', 2]]})
    with pytest.raises(ValueError, match='CSV/Benign_Final/'):
        list(stream_chunks(config, io.StringIO(), {}))
