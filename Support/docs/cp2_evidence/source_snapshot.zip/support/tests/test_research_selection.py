"""Testing-only inputs for CP1 proportional quotas and group allocation."""
import importlib
import numpy as np
import pytest


def api(): return importlib.import_module('support.data.research_selection')


def test_largest_remainder_exact_and_tie_order():
    assert api().proportional_quotas([5,3,2],7).tolist()==[4,2,1]
    assert api().proportional_quotas([1,1,1],2).tolist()==[1,1,0]
    with pytest.raises(ValueError): api().proportional_quotas([1,2],4)


@pytest.mark.parametrize('condition',['iid','dirichlet'])
def test_group_assignment_repeatable_and_disjoint(condition):
    groups=[f'{i:064x}' for i in range(600) for _ in range(i%3+1)]
    labels=np.array([int(g,16)%3 for g in groups])
    a=api().allocate_groups(groups,labels,3,42,condition,.5)
    b=api().allocate_groups(groups,labels,3,42,condition,.5)
    assert np.array_equal(a,b)
    assert set(a)=={0,1,2}
    for g in set(groups): assert len(set(a[np.array(groups)==g]))==1
    assert not np.array_equal(a,api().allocate_groups(groups,labels,3,43,condition,.5))


def test_mixed_group_labels_and_empty_clients_fail():
    with pytest.raises(ValueError,match='label'): api().allocate_groups(['a','a'],np.array([0,1]),2,42,'iid',.5)
    with pytest.raises(ValueError,match='empty'): api().allocate_groups(['a'],np.array([0]),2,42,'iid',.5)


def test_iid_uses_class_row_counts_not_group_counts():
    groups=['a']*10+['b']*2+['c']*2+['d']*2
    a=api().allocate_groups(groups,np.zeros(len(groups),dtype=int),2,42,'iid',.5)
    assert a.shape==(16,)
    assert abs(np.bincount(a,minlength=2)[0]-np.bincount(a,minlength=2)[1])<=10
