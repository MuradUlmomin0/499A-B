"""Hand-counted split overlaps and diagnostic sampling; no real source required."""
import hashlib
import importlib
import zipfile
import numpy as np
import pytest


def api():return importlib.import_module('support.data.latest_audit')


def inputs(tmp_path):
    archive=tmp_path/'data.zip'
    # Train: [1,1] twice, [2,2] once, [3,3] with conflicting labels.
    rows={'train':[(1,1,'a'),(1,1,'a'),(2,2,'b'),(3,3,'a'),(3,3,'b')],
          'validation':[(1,1,'a'),(4,4,'a'),(5,5,'b')],
          'test':[(2,2,'b'),(4,4,'a'),(6,6,'b')]}
    with zipfile.ZipFile(archive,'w') as z:
        for role,values in rows.items():
            text='f0,f1,label\n'+''.join(f'{a}.0,{b}.0,{label}\n' for a,b,label in values)
            z.writestr(f'Dataset/{role}.csv',text)
    return {'archive_path':str(archive),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
            'feature_names':['f0','f1'],'class_names':['a','b'],
            'expected_rows':{k:len(v) for k,v in rows.items()},'seed':42,'chunk_rows':2,
            'train_per_class':100,'validation_per_class':100,'num_clients':2,'hidden_dims':[4]},rows


def test_hand_counted_overlap_and_no_test_dependent_selection(tmp_path):
    c,_=inputs(tmp_path);out=tmp_path/'out';out.mkdir();work=tmp_path/'work';work.mkdir()
    audit,s=api().audit_latest(c,out,work)
    assert audit['rows']=={'train':5,'validation':3,'test':3}
    assert audit['unique_groups']==6
    assert audit['unique_groups_by_role']=={'train':3,'validation':3,'test':3}
    assert audit['duplicate_excess_by_role']=={'train':2,'validation':0,'test':0}
    assert audit['overlap_groups']=={'train_validation':1,'train_test':1,'validation_test':1}
    assert audit['mixed_label_groups']==1
    assert len(s['train']['labels'])==5
    assert s['validation']['ordinals'].tolist()==[1,2]
    assert audit['validation_candidates_removed_for_training_overlap']==1
    assert audit['test_used_for_selection'] is False
    # [4,4] also occurs in test, but must stay: test cannot decide the pilot.
    assert [4.,4.] in s['validation']['features'].tolist()
    assert not list(work.iterdir())


def test_sampling_same_source_seed_and_different_chunks_match(tmp_path):
    c,_=inputs(tmp_path);c['train_per_class']=2
    result=[]
    for i,size in enumerate([1,3]):
        c['chunk_rows']=size;o=tmp_path/f'out{i}';o.mkdir();w=tmp_path/f'work{i}';w.mkdir()
        a,s=api().audit_latest(c,o,w);result.append(s)
    for role in ['train','validation']:
        assert np.array_equal(result[0][role]['ordinals'],result[1][role]['ordinals'])
        assert np.array_equal(result[0][role]['features'],result[1][role]['features'])


@pytest.mark.parametrize('damage',['hash','rows','feature_order','labels'])
def test_wrong_source_or_schema_fails(tmp_path,damage):
    c,_=inputs(tmp_path)
    if damage=='hash':c['archive_sha256']='0'*64
    if damage=='rows':c['expected_rows']['train']+=1
    if damage=='feature_order':c['feature_names'].reverse()
    if damage=='labels':c['class_names']=['a','unknown']
    o=tmp_path/'o';o.mkdir();w=tmp_path/'w';w.mkdir()
    with pytest.raises(ValueError):api().audit_latest(c,o,w)


def test_empty_eligible_validation_keeps_completed_overlap_report(tmp_path):
    c,_=inputs(tmp_path)
    with zipfile.ZipFile(c['archive_path']) as z:
        parts={name:z.read(name) for name in z.namelist()}
    parts['Dataset/validation.csv']=b'f0,f1,label\n1.0,1.0,a\n2.0,2.0,b\n'
    with zipfile.ZipFile(c['archive_path'],'w') as z:
        for name,value in parts.items():z.writestr(name,value)
    c['expected_rows']['validation']=2
    c['archive_sha256']=hashlib.sha256(open(c['archive_path'],'rb').read()).hexdigest()
    o=tmp_path/'out';o.mkdir();w=tmp_path/'work';w.mkdir()
    with pytest.raises(ValueError,match='validation'):
        api().audit_latest(c,o,w)
    import json
    audit=json.loads((o/'split_audit.json').read_text())
    assert audit['rows']['validation']==2
    assert audit['overlap_groups']['train_validation']==2
    assert audit['selected_class_counts']['validation']==[0,0]
