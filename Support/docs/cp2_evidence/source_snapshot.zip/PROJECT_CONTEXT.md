# PRIVATE SHIELD — CSE499B Research Project Context

## 1. Project Title

PRIVATE SHIELD:
Trust-Aware and Class-Aware Federated Intrusion Detection
for Heterogeneous IoT Networks

This is an undergraduate CSE thesis/research project.

The implementation must be treated as a research codebase,
not as a normal software demo.

---

## 2. Main Research Problem

Federated Learning allows multiple IoT clients to collaboratively
train an intrusion-detection model without sharing raw traffic data.

However, two problems occur simultaneously:

1. IoT clients naturally have highly non-IID data.
   A client may look statistically unusual simply because it contains
   rare attack classes.

2. A malicious client may poison the federated model while attempting
   to keep its model update similar to legitimate clients.

This creates an important ambiguity:

"Is an unusual client malicious, or is it a legitimate client carrying
valuable minority-class knowledge?"

Our project investigates whether combining:

A. temporal/update-space trust evidence
   inspired by SecureDyn-FL

and

B. class-specific model contribution evidence
   inspired by FedMADE

can produce better federated aggregation than using either signal alone.

---

## 3. Core Research Question

Can a federated IoT IDS use both:

- how a client's model update behaves over time, and
- which attack-class knowledge the client contributes

to protect minority-class detection from poisoning while avoiding
false rejection of legitimate non-IID clients?

---

## 4. Main Hypothesis

A client should not be considered trustworthy or malicious based only
on parameter/update similarity.

A legitimate client containing rare attack knowledge may naturally
produce unusual updates.

Similarly, an attacker may attempt to remain statistically close to
benign clients while selectively damaging a minority attack class.

Therefore a multi-view trust mechanism combining:

Temporal Trust + Class Utility

may be more effective than:

- FedAvg alone
- FedMADE alone
- temporal/update-space trust alone

---

## 5. Important Research Direction

The intended later-stage attack is a:

Stealth Minority-Targeted Poisoning Attack

The malicious client should attempt to:

1. reduce performance on a selected minority attack class;
2. keep overall/global accuracy relatively normal;
3. avoid producing obviously anomalous model updates.

Conceptually:

"Stealth in parameter space, damage in class space."

Do NOT implement this attack yet unless explicitly requested.

---

## 6. Research Baselines

Eventually the common experiment should compare:

1. FedAvg
2. FedMADE
3. SecureDyn-inspired temporal trust aggregation
4. Proposed temporal-trust + class-aware aggregation

All comparisons must eventually use the same:

- dataset
- client partitions
- model architecture
- train/test split
- communication rounds
- random seeds
- local epochs
- attack configuration

when scientifically appropriate.

---

## 7. Datasets

### Primary dataset

CICIoT2023

This will be the main dataset for:

- FedAvg
- FedMADE
- class imbalance
- minority-class experiments
- final proposed method

Final broad classes are expected to include:

- Benign
- DDoS
- DoS
- Mirai
- Recon
- Spoofing
- Web-based
- Brute Force

CICIoT2023 preprocessing is NOT implemented yet.

Do not invent final client partitions before the real dataset
and victim-device mapping are inspected.

### SecureDyn reproduction dataset

N-BaIoT

This will later be used to reproduce or validate important
SecureDyn-style mechanisms.

### Possible external validation

A newer IoT/IIoT dataset may later be used for generalization tests.

---

## 8. Current Project State

The research implementation is being restarted from the beginning.

Two old Python scripts exist:

legacy/fedmade_old.py
legacy/master_securedyn_old.py

These scripts were basic CSE499A prototypes.

They use synthetic/randomly generated data.

Their numerical outputs are NOT valid research results.

They may only be used to understand previous implementation ideas.

Do not build the new architecture by blindly extending these files.

---

## 9. Important Rule About Synthetic Data

Synthetic/dummy data MAY be used for:

- unit testing
- debugging
- checking aggregation logic
- checking shapes
- testing client/server communication
- testing attack interfaces
- validating mathematical functions

Synthetic data MUST NOT be used for:

- thesis results
- research conclusions
- comparison tables
- claims that one method outperforms another

All final results must come from real datasets.

---

## 10. Current Development Strategy

For now, dataset preprocessing may be handled separately.

The immediate task is to build a dataset-independent research
framework that can later accept CICIoT2023.

The framework must not assume a hardcoded feature count or class count.

Use configurable:

input_dim
num_classes

throughout the implementation.

---

## 11. Required Repository Structure

Use approximately:

private_shield/
|
├── configs/
|
├── data/
│   ├── raw/
│   ├── interim/
│   └── processed/
|
├── docs/
|
├── experiments/
|
├── legacy/
│   ├── fedmade_old.py
│   └── master_securedyn_old.py
|
├── notebooks/
|
├── papers/
│   ├── FedMADE_Paper.pdf
│   └── SecureDyn_FL_Paper.pdf
|
├── results/
│   ├── checkpoints/
│   ├── logs/
│   ├── metrics/
│   └── plots/
|
├── src/
│   ├── attacks/
│   ├── data/
│   ├── defenses/
│   │   ├── fedmade/
│   │   ├── securedyn/
│   │   └── proposed/
│   ├── evaluation/
│   ├── federated/
│   ├── models/
│   └── utils/
|
├── tests/
|
├── README.md
├── requirements.txt
└── main.py

Do not create unnecessary files or overly complex abstractions.

---

## 12. Architecture Requirements

### Federated Client

A reusable FederatedClient should eventually support:

- receiving global parameters
- local training
- local evaluation
- returning model/update information
- returning client sample count
- optional malicious behavior

### Federated Server

A reusable FederatedServer should eventually support:

- client selection
- global model distribution
- collecting client models/updates
- aggregation strategy selection
- evaluation
- checkpoints
- experiment logging

Aggregation algorithms should be modular.

For example:

FedAvgAggregator
FedMADEAggregator
TemporalTrustAggregator
ProposedAggregator

---

## 13. FedAvg Requirement

Implement proper sample-size-weighted FedAvg:

w_global =
sum_i (n_i / sum_j n_j) * w_i

Do NOT implement simple unweighted averaging unless explicitly used
as a separate experiment.

FedAvg will be the reference baseline for the rest of the project.

---

## 14. FedMADE Requirements

The previous prototype is NOT a faithful FedMADE implementation.

The correct implementation must eventually include:

1. local models;
2. server auxiliary validation data;
3. Class Probability Matrix (CPM);
4. one probability vector PER TRUE CLASS;
5. DBSCAN clustering of client CPM representations;
6. Cluster Class Probability Matrices (CCPM);
7. dynamic aggregation-weight optimization;
8. conversion from cluster weights to client weights;
9. weighted model aggregation.

For C classes:

CPM shape should be:

C x C

Example:

               Predicted
             C0   C1   C2

True C0     .90  .06  .04
True C1     .07  .86  .07
True C2     .03  .12  .85

Do not reduce the CPM to one average probability vector.

The FedMADE paper should be treated as the source of truth
when implementing the algorithm.

---

## 15. SecureDyn-Inspired Requirements

We are NOT initially reproducing all of SecureDyn-FL.

Initial focus:

- model update extraction
- update history
- temporal behavior
- dimensionality reduction if required
- Gaussian Mixture Model
- Mahalanobis-distance-based anomaly evidence
- trust/anomaly scores

Later optional components include:

- personalization
- encryption
- pruning
- quantization

Do not implement encryption yet unless explicitly requested.

The SecureDyn-FL paper should be treated as the source of truth
when reproducing its mechanisms.

---

## 16. Client Update Definition

The framework should be able to calculate:

Delta_w_i_t = w_i_t - w_global_t

where:

Delta_w_i_t = local update of client i in round t.

Do not permanently flatten/destructively alter model state dictionaries.

Provide utilities for:

- extracting updates
- flattening updates
- restoring/handling structured parameters where necessary

---

## 17. Temporal History

Maintain round-by-round client history.

Conceptually:

client_0:
    round_1
    round_2
    round_3

client_1:
    round_1
    round_2
    round_3

History should later support temporal anomaly detection.

---

## 18. Poisoning Framework

Attacks must be modular.

Suggested structure:

src/attacks/
    base_attack.py
    label_flip.py
    sign_flip.py
    gaussian_attack.py
    scaling_attack.py
    model_replacement.py

A clean attack interface should support either:

data poisoning

or

model/update poisoning.

Do not implement research conclusions around these attacks yet.

---

## 19. Proposed Method

Do NOT prematurely invent a final aggregation equation.

Only create the software interface.

Conceptually:

Client Update
      |
  +---+---+
  |       |
Temporal  Class
Trust     Utility
  |       |
  +---+---+
      |
    Fusion
      |
Aggregation Weight

Possible APIs may include:

temporal_score
class_utility
fusion_score
aggregation_weight

But exact mathematics will be decided after real-data baseline experiments.

---

## 20. Evaluation Metrics

Implement reusable evaluation functions for:

Machine-learning metrics:

- accuracy
- balanced accuracy
- macro precision
- macro recall
- macro F1
- weighted F1
- per-class precision
- per-class recall
- per-class F1
- confusion matrix

Security/FL metrics should later support:

- malicious-client detection rate
- false-positive rate
- benign false-rejection rate
- attack success/degradation
- target-class degradation
- convergence
- round duration
- aggregation duration

Overall accuracy alone is NOT sufficient.

Minority-class metrics are central to this project.

---

## 21. Experiment Logging

Every research run must be reproducible.

Create an experiment directory such as:

results/experiment_name/

containing approximately:

config.yaml
round_metrics.csv
client_metrics.csv
aggregation_weights.csv
trust_scores.csv
final_metrics.json
checkpoint.pt

Log enough information to reproduce the experiment.

Never overwrite previous experiments silently.

---

## 22. Configuration

Avoid hardcoded experiment settings.

Use YAML configuration files.

Example:

experiment:
  name: fedavg_dummy_test
  seed: 42

model:
  type: mlp
  input_dim: 20
  num_classes: 3

federated:
  num_clients: 5
  rounds: 3
  participation_rate: 1.0

training:
  local_epochs: 2
  batch_size: 32
  optimizer: adam
  learning_rate: 0.001

attack:
  enabled: false

dataset:
  type: dummy

Later CICIoT2023 configs will replace the dummy dataset.

---

## 23. Reproducibility

Implement a central seed function covering:

- Python random
- NumPy
- PyTorch
- PyTorch CUDA when available

Experiments should record:

- seed
- Python version
- PyTorch version
- device
- important configuration
- timestamp

If possible also record Git commit hash.

---

## 24. Testing Philosophy

The project must include unit tests.

Important tests include:

- FedAvg weighted averaging is mathematically correct
- aggregation weights sum approximately to 1
- CPM dimensions are C x C
- CPM values are valid probabilities
- deterministic client selection with fixed seed
- zero malicious fraction attacks no clients
- model update extraction is correct
- flattening update dimensions are consistent
- metrics return expected values

Small synthetic tensors are appropriate for these tests.

---

## 25. Development Rules

Follow these rules strictly.

1. Do not invent research results.
2. Do not claim reproduction success until real-data experiments are run.
3. Do not hardcode CICIoT2023 feature counts into generic modules.
4. Do not use global test data during training.
5. Do not apply preprocessing using information from the test set.
6. Do not apply SMOTE to validation/test data.
7. Do not silently change paper algorithms.
8. If simplifying a paper implementation, clearly document the difference.
9. Keep methods modular so identical experimental conditions can be used.
10. Prefer correctness and reproducibility over unnecessary complexity.
11. Write readable research code rather than highly abstract enterprise code.
12. Add comments explaining research logic, not obvious Python syntax.
13. Do not prematurely optimize performance.
14. Do not implement the proposed research method before the baseline infrastructure is reliable.

---

## 26. Immediate Development Milestone

The current milestone is:

MILESTONE A:
DATASET-INDEPENDENT FEDERATED RESEARCH FRAMEWORK

The milestone should contain:

- clean repository structure
- reproducibility utilities
- configurable MLP model
- FederatedClient
- FederatedServer
- proper FedAvg
- experiment configuration
- experiment logging
- evaluation metrics
- tiny dummy dataset ONLY for tests
- unit tests

FedMADE and SecureDyn mechanisms should be added after
the basic FL framework is verified.

Real CICIoT2023 preprocessing will be integrated later.

---

## 27. Current Priority

Do not attempt to implement everything at once.

First inspect the repository.

Then present:

1. what currently exists;
2. what is reusable;
3. what should be replaced;
4. proposed repository structure;
5. implementation plan for Milestone A.

WAIT FOR APPROVAL before making major architectural changes
unless specifically instructed otherwise.

After approval, implement Milestone A incrementally and run tests
after each major component.